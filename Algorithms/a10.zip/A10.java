/* A10.java - Driver code for this assignment
 *
 *  @version CS 321 - Fall 2018 - A10
 *
 *  @author Christian Wendlandt
 *
 */

import java.util.*;
import java.io.*;

class A10
{
    static int size;        // number of edges on one side of the square
    static int minTurns;    // minimum required number of turns in the solution
    static int turnPenalty; // penalty for each extra turn over the minimum

    /* define your static variables below (NO instance variables allowed) */

    static int[][] leftEdges, rightEdges;
    static HashMap<String, Integer> optimalScores = new HashMap<>();
    static String solutionPath;
    static int solutionValue;
    static int optimalTurns;

    /* load problem definition from the given file into applicable static
     * variables.
     * This method does not send anything to the console. It must catch applicable
     * exceptions and output meaningful error messages.
     */
    static void loadProblem(String fileName)
    {
        try
        {
            Scanner scan = new Scanner(new File(fileName));

            minTurns = scan.nextInt();
            turnPenalty = scan.nextInt();
            size = scan.nextInt();

            leftEdges = new int[size + 1][size];
            rightEdges = new int[size][size + 1];

            for(int i = 0; i <= size; i++)
                for(int j = 0; j < size; j++)
                    rightEdges[j][i] = scan.nextInt();
            for(int i = 0; i < size; i++)
                for(int j = 0; j <= size; j++)
                    leftEdges[j][i] = scan.nextInt();

            scan.close();
        }
        catch(FileNotFoundException ex)
        {
            System.out.println("Couldn't find file \"" + fileName + "\".");
        }
        catch(InputMismatchException ex)
        {
            System.out.println('"' + fileName + "\" has an input that isn't an integer.");
        }
        catch(NoSuchElementException ex)
        {
            System.out.println('"' + fileName + "\" has too few input integers.");
        }
    }// loadProblem method

    /* solve the problem (previously defined using the loadProblem method) using
     * dynamic programming. Both the optimal value and an optimal solution must
     * be computed and stored in/retrievable from static variables, using the
     * following two methods.
     * This method does not send anything to the console.
     */
    static void solveProblem()
    {
        Stack<String> todoList = new Stack<>();
        String destNode;
        String sourceNode;
        String destPath;
        int destScore;
        int destTurnCounter;
        int row;
        int column;
        int penalty;
        int turn;
        int score;

        destNode = encode(size, size, 0, "F");
        optimalScores.put(destNode, 0);
        todoList.push(destNode);
        while(!todoList.isEmpty())
        {
            destNode = todoList.pop();
            destScore = optimalScores.get(destNode);
            destPath = getPath(destNode);
            row = getRow(destNode);
            column = getColumn(destNode);
            destTurnCounter = getTurn(destNode);
            
            penalty = 0;
            turn = 0;
            if(row != 0)//backtrack right
            {
                if(destPath.charAt(0) == 'R')
                {
                    turn = 1;
                    if(destTurnCounter >= minTurns)
                        penalty = turnPenalty;
                }
                sourceNode = encode(column, row - 1, destTurnCounter + turn, "L");
                score = destScore + leftEdges[column][row - 1] - penalty;
                if(optimalScores.containsKey(sourceNode))
                {
                    if(score > optimalScores.get(sourceNode))
                    {
                        optimalScores.put(sourceNode, score);
                        todoList.push(sourceNode);
                    }
                }
                else
                {
                    optimalScores.put(sourceNode, score);
                    todoList.push(sourceNode);
                }
            }
            
            penalty = 0;
            turn = 0;
            if(column != 0)//backtrack left
            {
                if(destPath.charAt(0) == 'L')
                {
                    turn = 1;
                    if(destTurnCounter >= minTurns)
                        penalty = turnPenalty;
                }
                sourceNode = encode(column - 1, row, destTurnCounter + turn, "R");
                score = destScore + rightEdges[column - 1][row] - penalty;
                if(optimalScores.containsKey(sourceNode))
                {
                    if(score > optimalScores.get(sourceNode))
                    {
                        optimalScores.put(sourceNode, score);
                        todoList.push(sourceNode);
                    }
                }
                else
                {
                    optimalScores.put(sourceNode, score);
                    todoList.push(sourceNode);
                }
            }
        }
    }// solveProblem method

    /* return the value of an optimal solution obtained with the solveProblem
     * method.
     * This method does not send anything to the console.
     * You can assume that I will always call this method right before calling
     * the getOptimalSolution method below.
     */
    static int getOptimalValue()
    {
        int optimalValue = 0;
        int value;
        
        for(int i = minTurns; i <= 2 * size; i++)
        {   
            if(optimalScores.containsKey(encode(0, 0, i, "L")))
            {
                value = optimalScores.get(encode(0, 0, i, "L"));
                if(value > optimalValue)
                {
                    optimalValue = value;
                    solutionPath = "L";
                    optimalTurns = i;
                }
            }
        }
        for(int i = minTurns; i <= 2 * size; i++)
        {   
            if(optimalScores.containsKey(encode(0, 0, i, "R")))
            {
                value = optimalScores.get(encode(0, 0, i, "R"));
                if(value > optimalValue)
                {
                    optimalValue = value;
                    solutionPath = "R";
                    optimalTurns = i;
                }
            }
        }
        
        solutionValue = optimalValue;
        return optimalValue;
    }// getOptimalValue method

    /* return an optimal solution (e.g., "LRRLLLRR") obtained with the
     * solveProblem method.
     * This method does not send anything to the console.
     * You can assume that I will always call getOptimalValue right before calling
     * this method.
     */
    static String getOptimalSolution()
    {
        String direction = solutionPath;
        int value = solutionValue;
        int turns = optimalTurns;
        StringBuilder optimalPath = new StringBuilder();
        int column = 0;
        int row = 0;
        int guess1;
        int guess2;
        
        while(column < size || row < size)
        {
            optimalPath.append(direction);
            if(direction.equals("L"))
            {
                if(optimalScores.containsKey(encode(column, row + 1, turns, "L")))
                    guess1 = optimalScores.get(encode(column, row + 1, turns, "L"));
                else
                    guess1 = 0;
                if(optimalScores.containsKey(encode(column, row + 1, turns - 1, "R")))
                    guess2 = optimalScores.get(encode(column, row + 1, turns - 1, "R"));
                else
                    guess2 = 0;
                if(guess1 < guess2)
                {
                    turns--;
                    direction = "R";
                }
                row++;
            }
            else if(direction.equals("R"))
            {
                if(optimalScores.containsKey(encode(column + 1, row, turns - 1, "L")))
                    guess1 = optimalScores.get(encode(column + 1, row, turns - 1, "L"));
                else
                    guess1 = 0;
                if(optimalScores.containsKey(encode(column + 1, row, turns, "R")))
                    guess2 = optimalScores.get(encode(column + 1, row, turns, "R"));
                else
                    guess2 = 0;
                if(guess1 > guess2)
                {
                    turns--;
                    direction = "L";
                }
                column++;
            }
        }
        
        return optimalPath.toString();
    }// getOptimalValue method

    /* Implement any helper method(s) that you need (if any) below
     * All methods in this class MUST be static.
     */

    public static String encode(int i, int j, int turns, String path)
    {
        StringBuilder string = new StringBuilder();

        string.append(i);
        string.append('-');
        string.append(j);
        string.append('-');
        string.append(turns);
        string.append('-');
        string.append(path);

        return string.toString();
    }
    
    public static int getColumn(String encoding)
    {
        return Integer.parseInt(encoding.split("-")[0]);
    }
    
    public static int getRow(String encoding)
    {
        return Integer.parseInt(encoding.split("-")[1]);
    }
    
    public static int getTurn(String encoding)
    {
        return Integer.parseInt(encoding.split("-")[2]);
    }
    
    public static String getPath(String encoding)
    {
        return encoding.substring(encoding.lastIndexOf('-') + 1);
    }

    public static int mostTurnsLeft(int i, int j)
    {
        int dist = 2 * Math.min(i,j);
        
        if(i == j && (i != 0 || j != 0))
            dist--;
        
        return dist;
    }

    /* Do not modify this method in your submission
     */
    public static void main(String[] args)
    {
        String fileName = args[0];

        loadProblem(fileName);
        solveProblem();
        int val = getOptimalValue();
        System.out.println( getOptimalSolution() + " " + val );
    }// main method

}// A10 class
