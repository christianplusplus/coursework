/* A8.java - Driver code for this assignment
 *
 *  @version CS 321 - Fall 2018 - A8
 *
 *  @author 1st Christian Wendlandt
 *
 *  @author 2nd Justin Haberman
 *
 */

import java.util.Random;
import java.util.Arrays;

class A8 {

    static final int MIN_N = (int) Math.pow(2,10);  /* minimum array size */
    static final int MAX_N = (int) Math.pow(2,30);  /* maximum array size */

    /* Perform the three experiments for part 3; the first argument must be used
     * in the call to Rand.shuffleArray() and the second argument must be used
     * to select the algorithm to test.
     *
     * For part 3, each experiment must run the selected algorithm once for all
     * input sizes ranging from MIN_N to MAX_N. For each run, your code must
     * output the size of the input array and the running time in seconds, in
     * a format that makes it easy to paste the output into Excel. Ideally,
     * we would perform several runs for each input size and average the running
     * time. However, to save you time, we'll limit ourselves to one run per size.
     *
     * For each run:
     *  1. Create an array of the given size (with Utils.createSortedArray).
     *  2. Shuffle the array fully (to create a random input).
     *  3. Run the selected algorithm on this input.
     *  4. Send the output to the console (not to a file).
     *  5. Double the array size (in preparation for the next run).
     *
     * Each experiment will stop when the JVM runs out of memory (but do use the
     * command-line arguments described in the main method below in order to
     * override the small default values used by the JVM) or when one single run
     * (for a given input size) takes more than 5 minutes.
     *
     */
    static void part3(int seed, int algo_num) {
        int size = MIN_N;
        int[] array;
        double runtime = 0;

        while(size <= MAX_N)
        {
            array = Utils.createSortedArray(size);
            Rand.shuffleArray(array, seed, size);

            switch(algo_num)
            {
                case 1:
                runtime = Sort.algo1(array);
                break;
                case 2:
                runtime = Sort.algo2(array);
                break;
                case 3:
                runtime = Sort.algo3(array);
            }

            System.out.printf("%d,%f\n", size, runtime);
            size *= 2;
        }
    }// part3 method

    /* Perform the three experiments for part 4; the argument must be used
     * to select the algorithm to test.
     *
     * For part 4, each experiment must run the selected algorithm once for all
     * input sizes ranging from MIN_N to MAX_N. For each run, your code must
     * output the size of the input array and the running time in seconds, in
     * a format that makes it easy to paste the output into Excel. Ideally,
     * we would perform several runs for each input size and average the running
     * time. However, to save you time, we'll limit ourselves to one run per size.
     *
     * For each run:
     *  1. Create an array of the given size (with Utils.createSortedArray).
     *  2. Run the selected algorithm on this input.
     *  3. Send the output to the console (not to a file).
     *  4. Double the array size (in preparation for the next run).
     *
     * Each experiment will stop when the JVM runs out of memory (but do use the
     * command-line arguments described in the main method below in order to
     * override the small default values used by the JVM) or when one single run
     * (for a given input size) takes more than 5 minutes.
     *
     */
    static void part4(int algo_num) {
        int size = MIN_N;
        int[] array;
        double runtime = 0;

        while(size <= MAX_N)
        {
            array = Utils.createSortedArray(size);

            switch(algo_num)
            {
                case 1:
                runtime = Sort.algo1(array);
                break;
                case 2:
                runtime = Sort.algo2(array);
                break;
                case 3:
                runtime = Sort.algo3(array);
            }

            System.out.printf("%d,%f\n", size, runtime);
            size *= 2;
        }
    }// part4 method

    /* Perform the three experiments for part 5; the argument must be used
     * to select the algorithm to test.
     *
     * For part 5, each experiment must run the selected algorithm once for all
     * input sizes ranging from MIN_N to MAX_N. For each run, your code must
     * output the size of the input array and the running time in seconds, in
     * a format that makes it easy to paste the output into Excel. Ideally,
     * we would perform several runs for each input size and average the running
     * time. However, to save you time, we'll limit ourselves to one run per size.
     *
     * For each run:
     *  1. Create an array of the given size (with Utils.createReverseSortedArray).
     *  2. Run the selected algorithm on this input.
     *  3. Send the output to the console (not to a file).
     *  4. Double the array size (in preparation for the next run).
     *
     * Each experiment will stop when the JVM runs out of memory (but do use the
     * command-line arguments described in the main method below in order to
     * override the small default values used by the JVM) or when one single run
     * (for a given input size) takes more than 5 minutes.
     *
     */
    static void part5(int algo_num) {
        int size = MIN_N;
        int[] array;
        double runtime = 0;

        while(size <= MAX_N)
        {
            array = Utils.createReverseSortedArray(size);

            switch(algo_num)
            {
                case 1:
                runtime = Sort.algo1(array);
                break;
                case 2:
                runtime = Sort.algo2(array);
                break;
                case 3:
                runtime = Sort.algo3(array);
            }

            System.out.printf("%d,%f\n", size, runtime);
            size *= 2;
        }
    }// part5 method

    /* Perform the three experiments for part 6; the argument must be used
     * to select the algorithm to test.
     *
     * For part 6, each experiment must run the selected algorithm once for all
     * input sizes ranging from MIN_N to MAX_N. For each run, your code must
     * output the size of the input array and the running time in seconds, in
     * a format that makes it easy to paste the output into Excel. Ideally,
     * we would perform several runs for each input size and average the running
     * time. However, to save you time, we'll limit ourselves to one run per size.
     *
     * For each run:
     *  1. Create an array of the given size (w/ Utils.createEqualElementsArray).
     *  2. Run the selected algorithm on this input.
     *  3. Send the output to the console (not to a file).
     *  4. Double the array size (in preparation for the next run).
     *
     * Each experiment will stop when the JVM runs out of memory (but do use the
     * command-line arguments described in the main method below in order to
     * override the small default values used by the JVM) or when one single run
     * (for a given input size) takes more than 5 minutes.
     *
     */
    static void part6(int algo_num) {
        int size = MIN_N;
        int[] array;
        double runtime = 0;

        while(size <= MAX_N)
        {
            array = Utils.createEqualElementsArray(size);

            switch(algo_num)
            {
                case 1:
                runtime = Sort.algo1(array);
                break;
                case 2:
                runtime = Sort.algo2(array);
                break;
                case 3:
                runtime = Sort.algo3(array);
            }

            System.out.printf("%d,%f\n", size, runtime);
            size *= 2;
        }
    }// part6 method

    /* Perform the three experiments for part 7; the first argument must be used
     * in each call Rand.shuffleArray(); the second argument must be used
     * to select the algorithm to test.
     *
     * For part 7, each experiment must run the selected algorithm once for all
     * values of n ranging from 0 to 5000. For each run, your code must
     * run on a sorted array of size 2^20 with increasing amount of randomness.
     * You must output the value of n and the running time in seconds, in
     * a format that makes it easy to paste the output into Excel. Ideally,
     * we would perform several runs for each input size and average the running
     * time. However, to save you time, we'll limit ourselves to one run per size.
     *
     * For each run:
     *  1. Create an array of size 2^20 (with Utils.createSortedArray).
     *  2. Shuffle the array using the current value of n.
     *  3. Run the selected algorithm on THIS input.
     *  4. Send the output to the console (not to a file).
     *  5. Increment the value of n by 100 (in preparation for the next run).
     *
     * Each experiment will run to completion.
     *
     */
    static void part7(int seed, int algo_num) {
        int size = (int)Math.pow(2, 20);
        int[] array;
        double runtime = 0;

        for(int i = 0; i <= 5000; i += 100)
        {
            array = Utils.createSortedArray(size);
            Rand.shuffleArray(array, seed, i);

            switch(algo_num)
            {
                case 1:
                runtime = Sort.algo1(array);
                break;
                case 2:
                runtime = Sort.algo2(array);
                break;
                case 3:
                runtime = Sort.algo3(array);
            }

            System.out.printf("%d,%f\n", i, runtime);
        }
    }// part7 method

    /*********************************/
    /* There is no coding for part 8 */
    /*********************************/

    /* Create and return the shortest possible array of integers that causes
     * Arrays.sort(int[]) to (partly) execute a one-pivot quicksort algorithm.
     * 
     * The algorithm uses 5 variables: e1 - e5. It checks if any of these are
     * equal to their neighbors. If even one pair is equal, the if/else will 
     * go to the else where it uses one pivot quicksort. The method I chose was
     * to simply populate the array up to e2 - 1 and then make e2 == e1, then 
     * populating the rest of the array. The Minimum size is set to 47 because
     * the algorithm will use insertionsort for anything less than that.
     */
    static int[] part9() {
        int[] a = null;
        int QUICKSORT_MIN = 47;
        int QUICKSORT_MAX = 286;
        a = new int[QUICKSORT_MIN];
        Random rand = new Random();

        int seventh = (QUICKSORT_MIN >> 3) + (QUICKSORT_MIN >> 6) + 1;

        int e3 = (0 + QUICKSORT_MIN - 1) >>> 1; 
        int e2 = e3 - seventh;
        int e1 = e2 - seventh;
        int e4 = e3 + seventh;
        int e5 = e4 + seventh;

        for(int i = 0; i < e2; i++){
            a[i] = rand.nextInt(e1);
        }
        a[e2] = a[e1];
        for(int i = e2 + 1; i < QUICKSORT_MIN - 1; i++){
            a[i] = rand.nextInt(50) + 1; 
        }

        return a;
    }// part9 method

    /* Do not modify this method
     */
    public static void main(String[] args) {

        /* usage:  java -Xms2000m -Xss2000m A8 <experiment_identifier>
        Note: the two -X command-line options are there to specify the amount
        of memory that the JVM should allocate to the heap and stack
         */

        if (args[0].equals("p3a1")) { part3(0,1); }
        if (args[0].equals("p3a2")) { part3(0,2); }
        if (args[0].equals("p3a3")) { part3(0,3); }

        if (args[0].equals("p4a1")) { part4(1); }
        if (args[0].equals("p4a2")) { part4(2); }
        if (args[0].equals("p4a3")) { part4(3); }

        if (args[0].equals("p5a1")) { part5(1); }
        if (args[0].equals("p5a2")) { part5(2); }
        if (args[0].equals("p5a3")) { part5(3); }

        if (args[0].equals("p6a1")) { part6(1); }
        if (args[0].equals("p6a2")) { part6(2); }
        if (args[0].equals("p6a3")) { part6(3); }

        if (args[0].equals("p7a1")) { part7(0,1); }
        if (args[0].equals("p7a2")) { part7(0,2); }
        if (args[0].equals("p7a3")) { part7(0,3); }

        if (args[0].equals("p9"))   { part9(); }

    }// main method

}// A8 class
