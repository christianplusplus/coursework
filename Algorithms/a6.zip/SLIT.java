/* SLIT.java - Two solutions to the SLIT problem
 *
 *  @version CS 321 - Fall 2018 - A6
 *
 *  @author Christian Wendlandt
 *
 *  @bug The brute-force algorithm does work fully.
 *
 *  @bug The faster algorithm does work fully.
 *
 */

class SLIT
{
    /* given a matrix and a slit window, return T - R where:
    + the slit window is a sub-matrix of the input matrix defined by:
    - the row index r of its top-left corner
    - the column index c of its top-left corner
    - its width (i.e., number of columns)
    - a height of 2 rows (always)
    + T is the number of occurrences of 'T' in the slit window
    + R is the number of occurrences of the rest of the bases (i.e., 'A',
    'C', and 'G') in the slit window

    For example, if the input matrix is:

    TTTACTCT     and r = 5 then T = 1 and the method returns -6
    CTTTTTGG         c = 3      R = 7
    AGTTATCT         w = 4
    TAATTTTT
    TTTCCTCT
    GTTCAGTA
    TTTCACGG
    TGCTTTTT
     */
    static int count(char[][] mat, int r, int c, int w)
    {
        int T = 0;
        for(int i = 0; i < w; i++)
        {
            if(mat[r][c+i] == 'T')
                T++;
            else
                T--;
            if(mat[r+1][c+i] == 'T')
                T++;
            else
                T--;
        }

        return T;
    }// count method

    /* your implementation of the brute-force algorithm whose pseudocode is
    given in the handout
     */
    static int algorithm1(char[][] mat, int n)
    {
        int slit = 0;
        for(int row = 0; row <= n - 2; row++)
            for(int col = 0; col <= n - 1; col++)
                for(int w = 1; w <= n - col; w++)
                    slit = Math.max(slit, count(mat, row, col, w));

        return slit;
    }// algorithm1 method

    /* your implementation of the second algorithm, which you must design
     */
    static int algorithm2(char[][] m, int n)
    {
        int slit = 0;
        for(int row = 0; row <= n - 2; row++)
            slit = Math.max(slit, bestSlitInRow(m, row, 0, n - 1));

        return slit;
    }// algorithm2 method

    static int bestSlitInRow(char[][] m, int row, int l, int r)
    {
        int mid, maxl, maxr, maxSumL, maxSumR, sum;

        if(l == r)
            return getPairValue(m, row, l);

        mid = (l + r) / 2;
        maxl = bestSlitInRow(m, row, l, mid);
        maxr = bestSlitInRow(m, row, mid + 1, r);

        maxSumL = sum = 0;
        for(int i = mid; i >= l; i--)
        {
            sum += getPairValue(m, row, i);
            if(sum > maxSumL)
                maxSumL = sum;
        }

        maxSumR = sum = 0;
        for(int i = mid + 1; i <= r; i++)
        {
            sum += getPairValue(m, row, i);
            if(sum > maxSumR)
                maxSumR = sum;
        }

        return Math.max(Math.max(maxl, maxr), maxSumL + maxSumR);
    }

    static int getPairValue(char[][] m, int row, int col)
    {
        if(m[row][col] == 'T')
        {
            if(m[row + 1][col] == 'T')
                return 2;
            return 0;
        }
        if(m[row + 1][col] == 'T')
            return 0;
        return -2;
    }
}// SLIT class
