/**
 * Class for a triangle given the lengths of its three sides.
 * 
 * @author (Christian Wendlandt)
 * @version (11/10/16)
 */
public class Triangle
{
    //Instance Variables
    private double sideLengthA, sideLengthB, sideLengthC;
    //Instance Methods
    //Constructor
    public Triangle(double a, double b, double c)
    {
        sideLengthA = a;
        sideLengthB = b;
        sideLengthC = c;
    }
    //Accessors
    public double getSideLengthA()
    {
        return sideLengthA;
    }
    public double getSideLengthB()
    {
        return sideLengthB;
    }
    public double getSideLengthC()
    {
        return sideLengthC;
    }
    //Mutators
    public void setSideLengthA(double a)
    {
        sideLengthA = a;
    }
    public void setSideLengthB(double b)
    {
        sideLengthB = b;
    }
    public void setSideLengthC(double c)
    {
        sideLengthC = c;
    }
    
    public double parimeter()
    {
        return sideLengthA + sideLengthB + sideLengthC;
    }
    
    public double area()
    {
        double p = (sideLengthA + sideLengthB + sideLengthC) / 2;
        return Math.sqrt(p * (p - sideLengthA) * (p - sideLengthB) * (p - sideLengthC));
    }
    
    public boolean isRightAngled()
    {
        if(sideLengthA >= sideLengthB && sideLengthA >= sideLengthC)
            return (sideLengthA * sideLengthA) == (sideLengthB * sideLengthB + sideLengthC * sideLengthC);
        else if(sideLengthB >= sideLengthA && sideLengthB >= sideLengthC)
            return (sideLengthB * sideLengthB) == (sideLengthA * sideLengthA + sideLengthC * sideLengthC);
        else
            return (sideLengthC * sideLengthC) == (sideLengthA * sideLengthA + sideLengthB * sideLengthB);
    }
    
    public String toString()
    {
        String str = "Triangle with side lengths " + sideLengthA + ", " + sideLengthB + ", and " + sideLengthC + ".";
        return str;
    }
}
