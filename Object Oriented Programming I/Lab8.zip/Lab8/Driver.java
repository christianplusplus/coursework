/**
 * Driver for triangle objects.
 * 
 * @author (Christian Wendlandt)
 * @version (11/10/16)
 */
public class Driver
{
    public static void main(String[] args)
    {
        //Declarations
        Triangle t1 = new Triangle(5, 4, 3);
        //Outputs
        System.out.println("Side A is: " + t1.getSideLengthA() + ".");
        System.out.println("Side B is: " + t1.getSideLengthB() + ".");
        System.out.println("Side C is: " + t1.getSideLengthC() + ".");
        System.out.println("The parimeter is: " + t1.parimeter() + ".");
        System.out.println("The area is: " + t1.area() + ".");
        System.out.println("Triangle is right angled: " + t1.isRightAngled() + ".");
        System.out.println(t1);
        t1.setSideLengthA(12);
        t1.setSideLengthB(16);
        t1.setSideLengthC(20);
        System.out.println(t1);
    }
}
