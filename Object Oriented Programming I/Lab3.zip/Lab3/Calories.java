/**
 * Calculates a given persons BRM rating and converts the calories into chocolate bars.
 * 
 * @author (Christian Wendlandt) 
 * @version (9/22/16)
 * 
 * Plan
 * Calculate a person's BRM in chocolate bars.
 *      Inputes
 *          Request Info
 *          weight in pounds
 *          height in inches
 *          age in years
 *      Process
 *          Calculate BRM for men and women.
 *          Convert BRM for men and women into chocolate bars.
 *      Output
 *          Give number of chocolate bars for men and women.
 *      Assumptions
 *          Choclate bars cotain 230 calories
 */
import java.util.Scanner;
public class Calories
{
    public static void main(String[] args)
    {
        //Declarations
        Scanner scan = new Scanner(System.in);
        double weight, height, age, brmForMan, brmForWoman, chocolateBarsForMan, chocolateBarsForWoman;
        //Inputs
        System.out.print("Enter weight in pounds:");
        weight = scan.nextDouble();
        System.out.print("Enter height in inches:");
        height = scan.nextDouble();
        System.out.print("Enter age in years:");
        age = scan.nextDouble();
        //Process
        brmForMan = 66 + 6.3 * weight + 12.9 * height - 6.8 * age;
        brmForWoman = 655 + 4.3 * weight + 4.7 * height - 4.7 * age;
        chocolateBarsForMan = brmForMan / 230;
        chocolateBarsForWoman = brmForWoman / 230;
        //Outputs
        System.out.println("If this person is a Woman, their BRM in chocolate bars is " + chocolateBarsForWoman + ".");
        System.out.println("If this person is a Man, their BRM in chocolate bars is " + chocolateBarsForMan + ".");
    }
}
