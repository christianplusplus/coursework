/**
 * Takes a simple expression and returns a description of the expression and its result.
 * 
 * @author (Christian Wendlandt) 
 * @version (10/20/16)
 * 
 * Description
 *     This class is an "English Language" calculator that works for addition, subtraction, multiplication, division, and exponentiation.
 * Inputs
 *     The user is prompted for an expression, which must be in the form <operand><space><operator><space><operand>.
 * Outputs
 *     Given an expression, the program gives a description of the operation in words along with the result.
 * Assumptions
 *     We assume that the user will use the correct format, that the operands given will be doubles, and that the operator will either
 *     be +, -, *, /, or ^.
 * Steps
 *     1. Prompt the user for an input.
 *     2. Read the operands and operators in the user's response.
 *     3. Check if the user is trying to divide by zero.
 *         a. If so, respond with an error message.
 *         b. If not, continue.
 *     4. Calculate a result based on the user's operands and operator.
 *     5. Print the user's request in words along with its result.
 */
import java.util.Scanner;
public class Calculator
{
    public static void main(String[] args)
    {
        //Declarations
        Scanner scan = new Scanner(System.in);
        double num1, num2;
        double result = 0;
        String operator;
        String stringOperator = "";
        //Input
        System.out.println("Calculator v1.0; Enter an expression");
        System.out.print(">>");
        num1 = scan.nextDouble();
        operator = scan.next();
        num2 = scan.nextDouble();
        //Process
        if(operator.equals("/") && num2 == 0)
        {
            //Output Error
            System.out.println("Division by zero is not allowed");
        }
        else
        {
            switch(operator)
            {
                case "+":
                    result = num1 + num2;
                    stringOperator = " plus ";
                    break;
                case "-":
                    result = num1 - num2;
                    stringOperator = " minus ";
                    break;
                case "*":
                    result = num1 * num2;
                    stringOperator = " multiplied by ";
                    break;
                case "/":
                    result = num1 / num2;
                    stringOperator = " divided by ";
                    break;
                case "^":
                    result = Math.pow(num1,num2);
                    stringOperator = " to the power ";
                    break;
            }
            //Output
            System.out.println(num1 + stringOperator + num2 + " is " + result);
        }
    }
}