/**
 * Converts a full name into a set of initials.
 * 
 * @author (Christian Wendlandt) 
 * @version (10/29/16)
 */
import java.util.Scanner;
public class NameInitials
{
    public static void main(String[] args)
    {
        //Declarations
        Scanner scan = new Scanner(System.in);
        String fullName, initials, letter;
        int space;
        //Input
        System.out.println("Enter a full name.");
        System.out.print(">>");
        fullName = scan.nextLine();
        //Process
        letter = fullName.substring(0,1);
        initials = letter.toUpperCase() + ".";
        space = fullName.indexOf(" ");
        fullName = fullName.substring(space + 1);
        
        letter = fullName.substring(0,1);
        initials += letter.toUpperCase() + ".";
        space = fullName.indexOf(" ");
        fullName = fullName.substring(space + 1);
        
        letter = fullName.substring(0,1);
        initials += letter.toUpperCase() + ".";
        //Output
        System.out.println(initials);
    }
}