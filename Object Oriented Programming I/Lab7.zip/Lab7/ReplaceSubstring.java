/**
 * Searches a string for a substring and replaces it.
 * 
 * @author (Christian Wendlandt) 
 * @version (10/29/16)
 */
import java.util.Scanner;
public class ReplaceSubstring
{
    public static void main(String[] args)
    {
        //Declarations
        Scanner scan = new Scanner(System.in);
        String main, search, replacement;
        String newMain = "";
        int searchIndex = 0;
        //Input
        System.out.println("Enter the main string.");
        System.out.print(">>");
        main = scan.nextLine();
        
        System.out.println("Enter the search string.");
        System.out.print(">>");
        search = scan.nextLine();
        
        System.out.println("Enter the replacement string.");
        System.out.print(">>");
        replacement = scan.nextLine();
        //Process
        searchIndex = main.indexOf(search);
        while(searchIndex != -1)
        {
            newMain += main.substring(0,searchIndex) + replacement;
            main = main.substring(searchIndex + search.length());
            searchIndex = main.indexOf(search);
        }
        newMain += main;
        //Output
        System.out.println(newMain);
    }
}