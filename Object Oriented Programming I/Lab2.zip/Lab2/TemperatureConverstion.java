/**
 * Converts temperatures from degrees fahrenheit to degrees celsius.
 * 
 * @author (Christian Wendlandt) 
 * @version (9/15/16)
 * 
 * Algorithmic Process:
 * Prompt user to enter the temperature in Fahrenheit.
 * Input temperature.
 * fahrenheit <== temperature.
 * celsius <== (fahrenheit - 32) *5 /9.
 * Print celsius.
 */
import java.util.Scanner;
public class TemperatureConverstion
{
    public static void main(String[] args)
    {
        //Declarations
        Scanner scan = new Scanner(System.in);
        double fahrenheit, celsius;
        //Input
        System.out.println("What is the temperature in Fahrenheit?");
        fahrenheit = scan.nextDouble();
        //Process
        celsius = (fahrenheit - 32) * 5 / 9;
        //Output
        System.out.print("The temperature is curretly ");
        System.out.print(celsius);
        System.out.print(" degrees Celsius.");
    }
}