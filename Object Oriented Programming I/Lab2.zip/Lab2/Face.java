/**
 * Creates an ASCII face
 * 
 * @author (Christian Wendlandt) 
 * @version (9/15/16)
 */
public class Face
{
    public static void main(String[] args)
    {
        //Hair
        System.out.println("  /////");
        //Brow
        System.out.println(" | _ _ |");
        //Eyes
        System.out.println(" | o o |");
        //Ears and Nose
        System.out.println("(|  ^  |)");
        //Mouth
        System.out.println(" | <_> |");
        //Collar
        System.out.println(" -------");
    }
}