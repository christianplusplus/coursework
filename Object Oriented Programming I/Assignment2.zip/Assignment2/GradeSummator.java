/**
 * Produces a summary of a given set of grades.
 * 
 * @author (Christian Wendlandt)
 * @version (11/01/16)
 */
import java.util.Scanner;
public class GradeSummator
{
    public static void main(String[] args)
    {
        //Declarations
        Scanner scan = new Scanner(System.in);
        int index, grade, gradeCount;
        double average;
        int aCount = 0;
        int bCount = 0;
        int cCount = 0;
        int dCount = 0;
        int fCount = 0;
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        int sum = 0;
        //Input
        gradeCount = scan.nextInt();
        if(gradeCount > 0)
        {
            for(int i = 1; i <= gradeCount; i++)
            {
                grade = scan.nextInt();
                //Process
                if(grade < min)
                    min = grade;
                if(grade > max)
                    max = grade;
                sum += grade;
                if(grade >= 91)
                    aCount++;
                else if(grade >= 83)
                    bCount++;
                else if(grade >= 75)
                    cCount++;
                else if(grade >= 67)
                    dCount++;
                else
                    fCount++;
            }
            average = (double) sum / gradeCount;
            //Output
            System.out.println("Grade Summary:");
            System.out.println("A's: " + aCount);
            System.out.println("B's: " + bCount);
            System.out.println("C's: " + cCount);
            System.out.println("D's: " + dCount);
            System.out.println("F's: " + fCount);
            System.out.println("Minimum Score: " + min);
            System.out.println("Maximum Score: " + max);
            System.out.printf("Average Score: %.2f\n", average);
        }
        else
        {
            System.out.println("Grade Summary:");
            System.out.println("A's: 0");
            System.out.println("B's: 0");
            System.out.println("C's: 0");
            System.out.println("D's: 0");
            System.out.println("F's: 0");
            System.out.println("Minimum Score: N/A");
            System.out.println("Maximum Score: N/A");
            System.out.println("Average Score: N/A");
        }
    }
}