/**
 * This class holds various methods for use on arrays.
 * 
 * @author (Christian Wendlandt) 
 * @version (12/1/16)
 */
public class ArrayMethods
{
    public static boolean checkArraySums(int[] arrayOne, int[] arrayTwo)
    {
        int sumOne = 0;
        int sumTwo = 0;
        for(int i : arrayOne)
            sumOne += i;
        for(int i : arrayTwo)
            sumTwo += i;
        return sumOne == sumTwo;
    }
    public static int countArrayElements(int[] array, int number)
    {
        int count = 0;
        for(int i : array)
            if(number == i)
                count++;
        return count;
    }
}