/**
 * Driver for testing the ArrayMethods class.
 * 
 * @author (Christian Wendlandt) 
 * @version (12/1/16)
 */
public class Driver
{
    public static void main(String[] args)
    {
        int[] arrayOne = {1,2,3,2,2};
        int[] arrayTwo = {9,1};
        int number = 2;
        System.out.println(ArrayMethods.checkArraySums(arrayOne, arrayTwo));
        System.out.println(ArrayMethods.countArrayElements(arrayOne, number));
    }
}