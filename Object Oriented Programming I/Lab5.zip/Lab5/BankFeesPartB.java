/**
 * Calculates the service fee of a bank given the number of checks written in a month.
 * We assumes that the number of checks is a whole number.
 * 
 * Christian Wendlandt
 * version date: 10/13/16
 */
import java.util.Scanner;
public class BankFeesPartB
{
    public static void main(String[] args)
    {
        //Declarations
        Scanner scan = new Scanner(System.in);
        int numberOfChecks;
        double serviceFee;
        //Input
        System.out.println("Enter how many checks have you written this month.");
        numberOfChecks = scan.nextInt();
        //Process
        switch(numberOfChecks / 20){
            case 0:
                serviceFee = 10 + .1 * numberOfChecks;
                break;
            case 1:
                serviceFee = 10 + .08 * numberOfChecks;
                break;
            case 2:
                serviceFee = 10 + .06 * numberOfChecks;
                break;
            default:
                serviceFee = 10 + .04 * numberOfChecks;
        }
        //Output
        System.out.println("Your service fee for this month is $" + serviceFee + ".");
    }
}