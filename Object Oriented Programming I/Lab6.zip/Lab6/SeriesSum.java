/**
 * Computes the sum of a unique series.
 * 
 * @author (Christian Wendlandt) 
 * @version (10/20/16)
 */
import java.util.Scanner;
public class SeriesSum
{
    public static void main(String[] args)
    {
        //Declarations
        Scanner scan = new Scanner(System.in);
        int n;
        double sum = 0;
        //Input
        System.out.println("Enter for how many terms you wish to calculate the sum of the series:");
        n = scan.nextInt();
        //Process
        if(n < 0)
        {
            //Output Error
            System.out.println("Number of terms must be >= 0.");
        }
        else
        {
            switch(n)
            {
                case 0:
                    sum = 0;
                    break;
                case 1:
                    sum = 1;
                    break;
                case 2:
                    sum = 1.5;
                    break;
                default:
                sum = 1.5;
                for(int i = 3; i <= n; i++)
                {
                    sum += (double) 1 / ((i - 1) * (i - 1));
                }
            }
            //Output
            System.out.println("The sum is " + sum + ".");
        }
    }
}