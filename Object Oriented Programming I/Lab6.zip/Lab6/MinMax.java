/**
 * Computes the minimum and maximum of a series of numbers.
 * 
 * @author (Christian Wendlandt) 
 * @version (10/20/16)
 */
import java.util.Scanner;
public class MinMax
{
    public static void main(String[] args)
    {
        //Declarations
        Scanner scan = new Scanner(System.in);
        int setLength;
        double number;
        double min = Double.MAX_VALUE;
        double max = Double.MIN_VALUE;
        //Input
        System.out.println("Enter the size of your set:");
        setLength = scan.nextInt();
        //Process
        if(setLength < 1)
        {
            System.out.println("You must have at least one number.");
        }
        else
        {
            System.out.println("Enter " + setLength + " numbers.");
            for(int i = 1; i <= setLength ; i++)
            {
                number = scan.nextDouble();
                if(number < min)
                    min = number;
                if(number > max)
                    max = number;
            }
            //Output
            System.out.println("Your smallest number is " + min + ".");
            System.out.println("Your largest number is " + max + ".");
        }
    }
}