/**
 * Class for a mind reader game.
 * 
 * @author (Christian Wendlandt)
 * @version (11/10/16)
 */
import java.util.Random;
public class MindReader
{
    //Instance Variables
    private int maxTurns, correctGuesses, incorrectGuesses;
    private int currTurns = 1;
    private String lastGuess;
    private boolean isLastGuessRight;
    Random rand = new Random();
    //Instance Methods
    //Constructor
    public MindReader(int n)
    {
        maxTurns = n;
    }
    
    public boolean isGameOver()
    {
        return currTurns > maxTurns;
    }
    //Accessors
    public int getCorrectGuesses()
    {
        return correctGuesses;
    }
    public int getIncorrectGuesses()
    {
        return incorrectGuesses;
    }
    
    public void updateScore(String str)
    {
        if(str.toUpperCase().equals(lastGuess))
        {
            correctGuesses++;
            isLastGuessRight = true;
        }
        else
        {
            incorrectGuesses++;
            isLastGuessRight = false;
        }
        currTurns++;
    }
    
    public boolean guessedRight()
    {
        return isLastGuessRight;
    }
    
    public void makeNextGuess()
    {
        if(rand.nextInt(2) == 1)
            lastGuess = "H";
        else
            lastGuess = "T";
    }
}
