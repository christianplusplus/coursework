/**
 * Driver for a mind reader game.
 * 
 * @author (Christian Wendlandt)
 * @version (11/10/16)
 */
import java.util.Scanner;
public class Driver
{
    public static void main(String[] args)
    {
        //Declarations
        Scanner scan = new Scanner(System.in);
        //Input
        System.out.println("How many times do you want to play this game?");
        MindReader computer = new MindReader(scan.nextInt());
        //Process
        System.out.println("You: " + computer.getIncorrectGuesses() + " Computer: " + computer.getCorrectGuesses());
        while(!computer.isGameOver())
        {
            System.out.println("Choose H or T:");
            computer.makeNextGuess();
            computer.updateScore(scan.next());
            if(computer.guessedRight())
            {
                System.out.println("Computer guessed correctly");
            }
            else
            {
                System.out.println("Computer guessed wrongly");
            }
            System.out.println("You: " + computer.getIncorrectGuesses() + " Computer: " + computer.getCorrectGuesses());
        }
        //Output
        if(computer.getIncorrectGuesses() > computer.getCorrectGuesses())
            System.out.println("Game over; you won " + computer.getIncorrectGuesses() + " to " + computer.getCorrectGuesses());
        if(computer.getIncorrectGuesses() == computer.getCorrectGuesses())
            System.out.println("Game over; you tied " + computer.getIncorrectGuesses() + " to " + computer.getCorrectGuesses());
        if(computer.getIncorrectGuesses() < computer.getCorrectGuesses())
            System.out.println("Game over; you lost " + computer.getIncorrectGuesses() + " to " + computer.getCorrectGuesses());
    }
}