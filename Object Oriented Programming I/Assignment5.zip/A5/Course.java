/**
 * Class for Course objects.
 * 
 * @author (Christian Wendlandt) 
 * @version (12/7/16)
 */
public class Course
{
    private String name, number;
    private int enrollment, maxEnrollment;
    private Student[] roster;
    
    public Course(String cNumber, String cName, int maximumEnrollment)
    {
        name = cName;
        number = cNumber;
        maxEnrollment = maximumEnrollment;
        roster = new Student[maxEnrollment];
    }
    
    public String getName()
    {
        return name;
    }
    public String getNumber()
    {
        return number;
    }
    
    public boolean add(Student student)
    {
        if(enrollment == maxEnrollment)
            return false;
        for(int i = 0; i < enrollment; i++)
        {
            if(roster[i].equals(student))
                return false;
        }
        roster[enrollment] = student;
        enrollment++;
        return true;
    }
    
    public boolean isFull()
    {
        return roster[maxEnrollment - 1] != null;
    }
    
    public void printRoster()
    {
        if(enrollment == 0)
            System.out.println("Error! No one is enrolled in this course.");
        else
            for(Student student : roster)
                if(student != null)
                    System.out.printf("%-5s %-10s %-10s %-10s\n",
                        student.getStudentID(),
                        student.getName().getFirst(),
                        student.getName().getMiddle(),
                        student.getName().getLast());
    }
}