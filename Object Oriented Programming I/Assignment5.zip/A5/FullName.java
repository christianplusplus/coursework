
/**
 * A class that captures the fullName of a person.
 * 
 * @author George Thomas
 * @version (12/05/2016)
 */
public class FullName
{
    private String first, middle, last;
    
    public FullName(String f, String m, String l)
    {
       first = f;
       middle = m;
       last = l;
    }

    //Accessors
    public String getFirst()
    {
        return first;
    }

    public String getMiddle()
    {
        return middle;
    }
    
    public String getLast()
    {
        return last;
    }
    
    //Mutators
    public void setFirst(String f)
    {
        first = f;
    }

    public void setMiddle(String m)
    {
        middle = m;
    }
    
    public void setLast(String l)
    {
        last = l;
    }
    
   public String toString()
   {
       return first +" " + middle + " " + last;
   }
   
   public boolean equals (Object obj)
   {
       if (obj instanceof FullName)
       {
           FullName f = (FullName)obj;
           return (first.equals(f.getFirst()) && middle.equals(f.getMiddle())
                && last.equals(f.getLast()));
       }
       return false;
   }
}
