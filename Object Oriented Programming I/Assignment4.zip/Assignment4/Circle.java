/**
 * A class which instantiates circles with given radius and center using a Point2D object.
 * 
 * @author (Christian Wendlandt) 
 * @version (11/27/16)
 */
public class Circle
{
    private int radius;
    private Point2D center;
    
    public Circle(int radius, Point2D center)
    {
        this.radius = radius;
        this.center = center;
    }
    
    public int getRadius()
    {
        return radius;
    }
    public Point2D getCenter()
    {
        return center;
    }
    
    public void setRadius(int radius)
    {
        this.radius = radius;
    }
    public void setCenter(Point2D center)
    {
        this.center = center;
    }
    
    public String toString()
    {
        return "radius = " + radius + ", center = " + center.toString() + ".";
    }
    
    public boolean equals(Object o)
    {
        if(o instanceof Circle)
        {
            Circle circle = (Circle)o;
            if(radius == circle.getRadius() && center.equals(circle.getCenter()))
                return true;
        }
        return false;
    }
    
    public double computeArea()
    {
        return Math.PI * radius * radius;
    }
    
    public double computeCircumference()
    {
        return 2 * Math.PI * radius;
    }
    
    public boolean intersects(Circle other)
    {
        return distance(center, other.getCenter()) <= radius + other.getRadius() && 
            distance(center, other.getCenter()) >= Math.abs(radius - other.getRadius());
    }
    
    public double distance(Point2D a, Point2D b)
    {
        return Math.sqrt(Math.pow(a.getX() - b.getX(), 2) + Math.pow(a.getY() - b.getY(), 2));
    }
}