public class CircleDriver
{
   public static void main(String [] args)
   {
       Circle c1,c2,c3,c4,c5;
       c1=new Circle(3, new Point2D(3,3));
       c2=new Circle(1, new Point2D(0,0));
       c3=new Circle(2, new Point2D(2,1));
       
       System.out.println("c1:"+c1);
       System.out.println("c2:"+c2);
       System.out.println("c3:"+c3);
       
       System.out.printf("Area of c1 = %6.2f\n", c1.computeArea());
       System.out.printf("Circumference of c2 = %6.2f\n", c2.computeCircumference());//There was a typo here. Was calling computeArea.
       System.out.println("c1 intersects with c2? :"+c1.intersects(c2));
       System.out.println("c1 intersects with c3? :"+c1.intersects(c3));//Typo here too. Was using the wrong parameter.
       Point2D p = new Point2D(-1,-1);
       c2.setCenter(p);
       c1.setRadius(5);
       //Added these next two lines for clarity.
       System.out.println("c1:"+c1);
       System.out.println("c2:"+c2);
       System.out.println("c1 intersects with c2? :"+c1.intersects(c2));
       System.out.println("c1 equal to c2? :"+c1.equals(c2));
       //Some of my own tests.
       c4=new Circle(2, new Point2D(0,0));
       c5=new Circle(3, new Point2D(0,0));
       System.out.println("c4:"+c4);
       System.out.println("c5:"+c5);
       System.out.println("c4 intersects with c5? :"+c4.intersects(c5));
       System.out.println("c4 equal to c5? :"+c4.equals(c5));
       System.out.println("c5 equal to c5? :"+c5.equals(c5));
   }
}