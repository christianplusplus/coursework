/**
 * Find the volume of a sphere given its radius.
 * 
 * @author (Christian Wendlandt) 
 * @version (9/29/16)
 */
import java.util.Scanner;
public class CircleRadiusToVolume
{
    public static void main(String[] args)
    {
        //Declarations
        Scanner scan = new Scanner(System.in);
        double radius, volume;
        //Input
        System.out.print("Enter the Radius: ");
        radius = scan.nextDouble();
        //Process
        volume = (double) 4 / 3 * Math.PI * Math.pow(radius,3);
        //Output
        System.out.println("Volume: " + volume);
    }
}