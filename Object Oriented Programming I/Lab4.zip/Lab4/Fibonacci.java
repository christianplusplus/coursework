/**
 * Determines the nth Fibonacci number given n.
 * 
 * @author (Christian Wendlandt) 
 * @version (9/29/16)
 */
import java.util.Scanner;
public class Fibonacci
{
    public static void main(String[] args)
    {
        //Declarations
        Scanner scan = new Scanner(System.in);
        int n, fibNumber;
        final double SQRT5 = Math.sqrt(5);
        //Input
        System.out.print("Which Fibonacci number do you want to know: ");
        n = scan.nextInt();
        //Process
        fibNumber = (int)(1 / SQRT5 * (Math.pow((1 + SQRT5) / 2,n) - Math.pow((1 - SQRT5) / 2,n)));
        //Output
        System.out.println("Your Fibonacci number is: " + fibNumber);
    }
}