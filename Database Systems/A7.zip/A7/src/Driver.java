/**
 * @author Christian Wendlandt
 * @version 2018.5.3
 */

import java.sql.*;
import java.io.FileInputStream;
import java.util.Properties;

public class Driver
{
    public static void main(String[] args)
    {
        Connection conn = null;
        Properties config;
        String db;
        String user;
        String pw;
        String driver;
        String url;
        
        try
        {
            config = loadProperties("src/config.properties");
            db = config.getProperty("database");
            user = config.getProperty("username");
            pw = config.getProperty("password");
            driver = config.getProperty("driver");
            url = config.getProperty("url") + db;
            
            registerDriver(driver);
            
            System.out.println("Attempting connection...");
            conn = DriverManager.getConnection(url, user, pw);
            System.out.println("Connection successfully made.");
            DB.connectDB(conn);
            (new Login()).setVisible(true);
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
            try
            {
                conn.close();
                System.out.println("Connection closed.");
            }
            catch(Exception ex2){}
            System.exit(1);
        }
        catch(Exception ex)
        {
            System.out.println(ex);
            try
            {
                conn.close();
                System.out.println("Connection closed.");
            }
            catch(Exception ex2){}
            System.exit(1);
        }
    }
    
    private static void registerDriver(String driver) throws Exception
    {
        Class.forName(driver);
    }
    
    private static Properties loadProperties(String filename) throws Exception
    {
        Properties config = new Properties();
        
        try
        {
            FileInputStream file = new FileInputStream(filename);
            config.load(file);
            file.close();
            return config;
        }
        catch(Exception e)
        {
            throw new Exception("An error occurred while trying to load config.properties.");
        }
    }
    
    public static int getHash(String password)
    {
        int hash = 7;
        for (int i = 0; i < password.length(); i++)
            hash = hash*31 + password.charAt(i);
        return hash;
    }
}
