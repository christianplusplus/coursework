/**
 * Connects, queries, and prints responses from a mySQL database.
 *
 * @author Christian Wendlandt
 * @version 2018.5.3
 */

import java.sql.*;
import java.util.ArrayList;

public class DB
{
    private static Connection conn;
    
    public static void connectDB(Connection conn)
    {
        DB.conn = conn;
    }
    
    public static ResultSet findPerson(String firstName, String middleName, String lastName)
    {
        PreparedStatement statement;
        String query;
        
        query = "SELECT * " +
                "FROM Person " +
                "WHERE " +
                "1 = 1" + //this just makes concatination easier
                (firstName.isEmpty() ? "" : " AND firstName = '" + firstName + "'") +
                (middleName.isEmpty() ? "" : " AND middleName = '" + middleName + "'") +
                (lastName.isEmpty() ? "" : " AND lastName = '" + lastName + "'");
        try
        {
            statement = conn.prepareStatement(query);
            return statement.executeQuery();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    public static ResultSet findPerson(String pid)
    {
        PreparedStatement statement;
        String query;
        
        query = "SELECT * " +
                "FROM Person " +
                "WHERE " +
                "pid = " + pid;
        try
        {
            statement = conn.prepareStatement(query);
            return statement.executeQuery();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    
    public static ResultSet findAncestors(String pid, int generations)
    {
        PreparedStatement statement;
        String query;
        
        query = "SELECT * " +
                "FROM Person " +
                "WHERE pid IN ";
        for(int i = 1; i < generations; i++)
            query += "(" +
                    "SELECT pid1 " +
                    "FROM Association " +
                    "WHERE pid2 IN ";
        query += "(" +
                "SELECT pid1 " +
                "FROM Association " +
                "WHERE Association.pid2 = " + pid + " " +
                "AND Association.assocType = 'PARENT'" + 
                ")";
        for(int i = 1; i < generations; i++)
            query += "AND Association.assocType = 'PARENT'" +
                    ")";
        try
        {
            statement = conn.prepareStatement(query);
            return statement.executeQuery();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    
    public static ResultSet findDescendents(String pid, int generations)
    {
        PreparedStatement statement;
        String query;
        
        query = "SELECT * " +
                "FROM Person " +
                "WHERE pid IN ";
        for(int i = 1; i < generations; i++)
            query += "(" +
                    "SELECT pid2 " +
                    "FROM Association " +
                    "WHERE pid1 IN ";
        query += "(" +
                "SELECT pid2 " +
                "FROM Association " +
                "WHERE Association.pid1 = " + pid + " " +
                "AND Association.assocType = 'PARENT'" + 
                ")";
        for(int i = 1; i < generations; i++)
            query += "AND Association.assocType = 'PARENT'" +
                    ")";
        try
        {
            statement = conn.prepareStatement(query);
            return statement.executeQuery();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    
    public static ResultSet findSyblings(String pid)
    {
        PreparedStatement statement;
        String query;
        
        query = "SELECT * " +
                "FROM Person " +
                "WHERE pid IN " +
                "(" +
                "SELECT pid2 " +
                "FROM Association " +
                "WHERE pid1 IN " +
                "(" +
                "SELECT pid1 " +
                "FROM Association " +
                "WHERE Association.pid2 = " + pid + " " +
                "AND Association.assocType = 'PARENT'" + 
                ")" +
                "AND Association.assocType = 'PARENT'" +
                "AND pid2 != " + pid +
                ")";
        try
        {
            statement = conn.prepareStatement(query);
            return statement.executeQuery();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    
    public static ResultSet findSpouse(String pid)
    {
        PreparedStatement statement;
        String query;
        
        query = "SELECT * " +
                "FROM Person " +
                "WHERE pid IN " +
                "(" +
                "SELECT pid2 " +
                "FROM Association " +
                "WHERE pid1 = " + pid + " " +
                "AND Association.assocType = 'SPOUSE'" +
                ")";
        try
        {
            statement = conn.prepareStatement(query);
            return statement.executeQuery();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    
    public static ResultSet findEvents(String pid)
    {
        PreparedStatement statement;
        String query;
        
        query = "SELECT * " +
                "FROM Event " +
                "WHERE eid IN " +
                "(" +
                "SELECT eid " +
                "FROM Present " +
                "WHERE pid = " + pid +
                ")";
        try
        {
            statement = conn.prepareStatement(query);
            return statement.executeQuery();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    
    public static ResultSet findByBio(String text)
    {
        PreparedStatement statement;
        String query;
        
        query = "SELECT * " +
                "FROM Person " +
                "WHERE bio LIKE '%%" + text + "%%'";
        try
        {
            statement = conn.prepareStatement(query);
            return statement.executeQuery();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    
    public static ResultSet findEventByDate(String date)
    {
        PreparedStatement statement;
        String query;
        
        query = "SELECT * " +
                "FROM Event " +
                "WHERE date = '" + date + "'";
        try
        {
            statement = conn.prepareStatement(query);
            return statement.executeQuery();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    
    public static ResultSet getPerson(ArrayList<String> args)
    {
        PreparedStatement statement;
        String query;
        
        query = "SELECT * " +
                "FROM Person " +
                "WHERE " +
                "1 = 1" + //this just makes concatination easier
                (args.get(0).isEmpty() ? "" : " AND pid = '" + args.get(0) + "'") +
                (args.get(1).isEmpty() ? "" : " AND firstName = '" + args.get(1) + "'") +
                (args.get(2).isEmpty() ? "" : " AND middleName = '" + args.get(2) + "'") +
                (args.get(3).isEmpty() ? "" : " AND lastName = '" + args.get(3) + "'") +
                (args.get(4).isEmpty() ? "" : " AND dob = '" + args.get(4) + "'") +
                (args.get(5).isEmpty() ? "" : " AND dod = '" + args.get(5) + "'") +
                (args.get(6).isEmpty() ? "" : " AND gender = '" + args.get(6) + "'") +
                (args.get(7).isEmpty() ? "" : " AND bio = '" + args.get(7) + "'") +
                (args.get(8).isEmpty() ? "" : " AND country = '" + args.get(8) + "'") +
                (args.get(9).isEmpty() ? "" : " AND state = '" + args.get(9) + "'") +
                (args.get(10).isEmpty() ? "" : " AND city = '" + args.get(10) + "'") +
                (args.get(11).isEmpty() ? "" : " AND street = '" + args.get(11) + "'") +
                (args.get(12).isEmpty() ? "" : " AND buildNum = '" + args.get(12) + "'") +
                (args.get(13).isEmpty() ? "" : " AND aptNum = '" + args.get(13) + "'") +
                (args.get(14).isEmpty() ? "" : " AND postalCode = '" + args.get(14) + "'");
        try
        {
            statement = conn.prepareStatement(query);
            return statement.executeQuery();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    
    public static void deletePerson(ArrayList<String> args)
    {
        PreparedStatement statement;
        String query;
        
        query = "DELETE " +
                "FROM Person " +
                "WHERE " +
                "1 = 1" + //this just makes concatination easier
                (args.get(0).isEmpty() ? "" : " AND pid = '" + args.get(0) + "'") +
                (args.get(1).isEmpty() ? "" : " AND firstName = '" + args.get(1) + "'") +
                (args.get(2).isEmpty() ? "" : " AND middleName = '" + args.get(2) + "'") +
                (args.get(3).isEmpty() ? "" : " AND lastName = '" + args.get(3) + "'") +
                (args.get(4).isEmpty() ? "" : " AND dob = '" + args.get(4) + "'") +
                (args.get(5).isEmpty() ? "" : " AND dod = '" + args.get(5) + "'") +
                (args.get(6).isEmpty() ? "" : " AND gender = '" + args.get(6) + "'") +
                (args.get(7).isEmpty() ? "" : " AND bio = '" + args.get(7) + "'") +
                (args.get(8).isEmpty() ? "" : " AND country = '" + args.get(8) + "'") +
                (args.get(9).isEmpty() ? "" : " AND state = '" + args.get(9) + "'") +
                (args.get(10).isEmpty() ? "" : " AND city = '" + args.get(10) + "'") +
                (args.get(11).isEmpty() ? "" : " AND street = '" + args.get(11) + "'") +
                (args.get(12).isEmpty() ? "" : " AND buildNum = '" + args.get(12) + "'") +
                (args.get(13).isEmpty() ? "" : " AND aptNum = '" + args.get(13) + "'") +
                (args.get(14).isEmpty() ? "" : " AND postalCode = '" + args.get(14) + "'");
        try
        {
            statement = conn.prepareStatement(query);
            statement.executeUpdate();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
    }
    
    public static ResultSet getPrevNames(ArrayList<String> args)
    {
        PreparedStatement statement;
        String query;
        
        query = "SELECT * " +
                "FROM PrevNames " +
                "WHERE " +
                "1 = 1" + //this just makes concatination easier
                (args.get(0).isEmpty() ? "" : " AND pid = '" + args.get(0) + "'") +
                (args.get(1).isEmpty() ? "" : " AND firstName = '" + args.get(1) + "'") +
                (args.get(2).isEmpty() ? "" : " AND middleName = '" + args.get(2) + "'") +
                (args.get(3).isEmpty() ? "" : " AND lastName = '" + args.get(3) + "'") +
                (args.get(4).isEmpty() ? "" : " AND dateChanged = '" + args.get(4) + "'");
        try
        {
            statement = conn.prepareStatement(query);
            return statement.executeQuery();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    public static void deletePrevNames(ArrayList<String> args)
    {
        PreparedStatement statement;
        String query;
        
        query = "DELETE " +
                "FROM PrevNames " +
                "WHERE " +
                "1 = 1" + //this just makes concatination easier
                (args.get(0).isEmpty() ? "" : " AND pid = '" + args.get(0) + "'") +
                (args.get(1).isEmpty() ? "" : " AND firstName = '" + args.get(1) + "'") +
                (args.get(2).isEmpty() ? "" : " AND middleName = '" + args.get(2) + "'") +
                (args.get(3).isEmpty() ? "" : " AND lastName = '" + args.get(3) + "'") +
                (args.get(4).isEmpty() ? "" : " AND dateChanged = '" + args.get(4) + "'");
        try
        {
            statement = conn.prepareStatement(query);
            statement.executeUpdate();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
    }
    
    public static ResultSet getAssociation(ArrayList<String> args)
    {
        PreparedStatement statement;
        String query;
        
        query = "SELECT * " +
                "FROM Association " +
                "WHERE " +
                "1 = 1" + //this just makes concatination easier
                (args.get(0).isEmpty() ? "" : " AND pid1 = '" + args.get(0) + "'") +
                (args.get(1).isEmpty() ? "" : " AND pid2 = '" + args.get(1) + "'") +
                (args.get(2).isEmpty() ? "" : " AND assocType = '" + args.get(2) + "'");
        try
        {
            statement = conn.prepareStatement(query);
            return statement.executeQuery();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    public static void deleteAssociation(ArrayList<String> args)
    {
        PreparedStatement statement;
        String query;
        
        query = "DELETE " +
                "FROM Association " +
                "WHERE " +
                "1 = 1" + //this just makes concatination easier
                (args.get(0).isEmpty() ? "" : " AND pid1 = '" + args.get(0) + "'") +
                (args.get(1).isEmpty() ? "" : " AND pid2 = '" + args.get(1) + "'") +
                (args.get(2).isEmpty() ? "" : " AND assocType = '" + args.get(2) + "'");
        try
        {
            statement = conn.prepareStatement(query);
            statement.executeUpdate();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
    }
    
    public static ResultSet getEvent(ArrayList<String> args)
    {
        PreparedStatement statement;
        String query;
        
        query = "SELECT * " +
                "FROM Event " +
                "WHERE " +
                "1 = 1" + //this just makes concatination easier
                (args.get(0).isEmpty() ? "" : " AND eid = '" + args.get(0) + "'") +
                (args.get(1).isEmpty() ? "" : " AND title = '" + args.get(1) + "'") +
                (args.get(2).isEmpty() ? "" : " AND location = '" + args.get(2) + "'") +
                (args.get(3).isEmpty() ? "" : " AND date = '" + args.get(3) + "'") +
                (args.get(4).isEmpty() ? "" : " AND desciption = '" + args.get(4) + "'");
        try
        {
            statement = conn.prepareStatement(query);
            return statement.executeQuery();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    public static void deleteEvent(ArrayList<String> args)
    {
        PreparedStatement statement;
        String query;
        
        query = "DELETE " +
                "FROM Event " +
                "WHERE " +
                "1 = 1" + //this just makes concatination easier
                (args.get(0).isEmpty() ? "" : " AND eid = '" + args.get(0) + "'") +
                (args.get(1).isEmpty() ? "" : " AND title = '" + args.get(1) + "'") +
                (args.get(2).isEmpty() ? "" : " AND location = '" + args.get(2) + "'") +
                (args.get(3).isEmpty() ? "" : " AND date = '" + args.get(3) + "'") +
                (args.get(4).isEmpty() ? "" : " AND desciption = '" + args.get(4) + "'");
        try
        {
            statement = conn.prepareStatement(query);
            statement.executeUpdate();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
    }
    
    public static ResultSet getPresent(ArrayList<String> args)
    {
        PreparedStatement statement;
        String query;
        
        query = "SELECT * " +
                "FROM Present " +
                "WHERE " +
                "1 = 1" + //this just makes concatination easier
                (args.get(0).isEmpty() ? "" : " AND eid = '" + args.get(0) + "'") +
                (args.get(1).isEmpty() ? "" : " AND pid = '" + args.get(1) + "'");
        try
        {
            statement = conn.prepareStatement(query);
            return statement.executeQuery();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    public static void deletePresent(ArrayList<String> args)
    {
        PreparedStatement statement;
        String query;
        
        query = "DELETE " +
                "FROM Present " +
                "WHERE " +
                "1 = 1" + //this just makes concatination easier
                (args.get(0).isEmpty() ? "" : " AND eid = '" + args.get(0) + "'") +
                (args.get(1).isEmpty() ? "" : " AND pid = '" + args.get(1) + "'");
        try
        {
            statement = conn.prepareStatement(query);
            statement.executeUpdate();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
    }
    
    public static void insert(String table, ArrayList<String> args)
    {
        PreparedStatement statement;
        String query;
        
        query = "INSERT " +
                "INTO " + table + " " +
                "VALUES (";
        for(String arg : args)
        {
            if(arg.isEmpty())
                query += "NULL,";
            else
            {
                query += "'" + arg + "'" + ',';
            }
        }
        query = query.substring(0, query.length() - 1);
        query += ')';
        try
        {
            statement = conn.prepareStatement(query);
            statement.executeUpdate();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
    }
    
    public static ResultSet getUsers()
    {
        PreparedStatement statement;
        String query;
        
        query = "SELECT * FROM User";
        try
        {
            statement = conn.prepareStatement(query);
            return statement.executeQuery();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    public static ResultSet getAuthorizedUsers()
    {
        PreparedStatement statement;
        String query;
        
        query = "SELECT * FROM AuthorizedUser";
        try
        {
            statement = conn.prepareStatement(query);
            return statement.executeQuery();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    public static ResultSet getAdmins()
    {
        PreparedStatement statement;
        String query;
        
        query = "SELECT * FROM Admin";
        try
        {
            statement = conn.prepareStatement(query);
            return statement.executeQuery();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return null;
    }
    
    public static void deleteUser(String user)
    {
        PreparedStatement statement;
        String query1;
        String query2;
        String query3;
        
        query1 = "DELETE " +
                "FROM Admin " +
                "WHERE " +
                "username = '" + user + "'";
        query2 = "DELETE " +
                "FROM AuthorizedUser " +
                "WHERE " +
                "username = '" + user + "'";
        query3 = "DELETE " +
                "FROM User " +
                "WHERE " +
                "username = '" + user + "'";
        try
        {
            statement = conn.prepareStatement(query1);
            statement.executeUpdate();
            statement = conn.prepareStatement(query2);
            statement.executeUpdate();
            statement = conn.prepareStatement(query3);
            statement.executeUpdate();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
    }
    
    public static boolean authenticateUser(String username, int password)
    {
        PreparedStatement statement;
        String query;
        ResultSet answer;
        
        query = "SELECT * " +
                "FROM User " +
                "WHERE username = '" + username + "' " +
                "AND passHash = " + password;
        try
        {
            statement = conn.prepareStatement(query);
            answer = statement.executeQuery();
            return answer.isBeforeFirst();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return false;
    }
    public static boolean authenticateAuthorizedUser(String username)
    {
        PreparedStatement statement;
        String query;
        ResultSet answer;
        
        query = "SELECT * " +
                "FROM AuthorizedUser " +
                "WHERE username = '" + username + "'";
        try
        {
            statement = conn.prepareStatement(query);
            answer = statement.executeQuery();
            return answer.isBeforeFirst();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return false;
    }
    public static boolean authenticateAdmin(String username)
    {
        PreparedStatement statement;
        String query;
        ResultSet answer;
        
        query = "SELECT * " +
                "FROM Admin " +
                "WHERE username = '" + username + "'";
        try
        {
            statement = conn.prepareStatement(query);
            answer = statement.executeQuery();
            return answer.isBeforeFirst();
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
        }
        return false;
    }
}