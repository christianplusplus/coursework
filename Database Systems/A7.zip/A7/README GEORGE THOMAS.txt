To run the application, you need to create a tunnel to the webdev server.
The PUTTY configurations are:
>Connections
	>SSH
		>Tunnls
			Source Port: 3306
			Destination: webdev.cs.uwosh.edu:3306
The config file is set to log into my webdev database.
(I'm sure you already know all of this.)

To run the application, open the project directory and enter in the the command line:
	java -jar dist/A7.jar

That should get everything running.
There are five panels.
The first is the login.
You can go to the create account panel from there.
After you create an account it will go back to the login.
Depending on your account privileges, logging in will open 1, 2, or 3 new panels.
Be aware that they overlap and that closing any one of them will terminate the entire program.
For your convenience, an admin account is set up with "admin" for the username and "123456" for the password.
I've included the database sql build queries file incase you accidently delete my webdev database or if
you want to test it on your own.