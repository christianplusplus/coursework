import java.io.FileInputStream;
import java.util.*;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.AggregateIterable;

import static com.mongodb.client.model.Filters.*;
import static com.mongodb.client.model.Projections.*;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Filters;

public class Query
{
    private static Properties config;

    private static void loadProperties()
    {
        try
        {
            FileInputStream file = new FileInputStream("config.properties");
            config = new Properties();
            config.load(file);
            file.close();
        }
        catch(Exception e)
        {
            System.out.println("An error occurred while trying to load config.properties.");
        }
    }

    public static void main(String[] args)
    {
        MongoClient mongoClient = null;
        MongoCollection<Document> branch;
        MongoCollection<Document> customer;
        AggregateIterable<Document> output;
        AggregateIterable<Document> branches;
        AggregateIterable<Document> loans;
        AggregateIterable<Document> deposits;
        String mode = args[0];
        String parameter = args[1];
        
        loadProperties();
        try
        {
            mongoClient = getMongoClient();
            MongoDatabase mongoDB = mongoClient.getDatabase(config.getProperty("database"));
            branch = mongoDB.getCollection("Branch");
            customer = mongoDB.getCollection("Customer");
            
            switch(mode)
            {
                case "1":
                    output = branch.aggregate(
                                Arrays.asList(
                                    Aggregates.match(exists("loan")),
                                    Aggregates.unwind("$loan"),
                                    Aggregates.replaceRoot("$loan"),
                                    Aggregates.match(gt("amount", parameter))
                                )
                            );
                    TreeSet<String> set = new TreeSet<>();
                    for(Document entry : output)
                        set.add((String)entry.get("cname"));
                    for(String name : set)
                        System.out.println(name);
                    break;
                case "2":
                    output = branch.aggregate(
                                Arrays.asList(
                                    Aggregates.match(exists("loan")),
                                    Aggregates.unwind("$loan"),
                                    Aggregates.replaceRoot("$loan"),
                                    Aggregates.group("$cname", Accumulators.push("total", "$amount"), Accumulators.sum("count", 1)),
                                    Aggregates.match(gt("count", Integer.parseInt(parameter)))
                                )
                            );
                    for(Document entry : output)
                        System.out.printf("Customer: %s; Total Loans: $%,.2f\n", entry.get("_id"), getSum((ArrayList<String>)entry.get("total")));
                    break;
                case "3":
                    branches = branch.aggregate(
                                Arrays.asList(
                                    Aggregates.match(or(exists("loan"),exists("deposit")))
                                )
                            );
                    System.out.println(parameter + ": ");
                    for(Document branchDoc : branches)
                    {
                        deposits = branch.aggregate(
                                Arrays.asList(
                                    Aggregates.match(eq("bname", branchDoc.get("bname"))),
                                    Aggregates.match(exists("deposit")),
                                    Aggregates.unwind("$deposit"),
                                    Aggregates.replaceRoot("$deposit"),
                                    Aggregates.match(eq("cname", parameter))
                                )
                            );
                        for(Document entry : deposits)
                            System.out.printf("Deposit Account: $%,.2f at %s\n", Double.parseDouble((String)entry.get("balance")), branchDoc.get("bname"));
                        loans = branch.aggregate(
                                Arrays.asList(
                                    Aggregates.match(eq("bname", branchDoc.get("bname"))),
                                    Aggregates.match(exists("loan")),
                                    Aggregates.unwind("$loan"),
                                    Aggregates.replaceRoot("$loan"),
                                    Aggregates.match(eq("cname", parameter))
                                )
                            );
                        for(Document entry : loans)
                            System.out.printf("Loan Account: $%,.2f at %s\n", Double.parseDouble((String)entry.get("amount")), branchDoc.get("bname"));
                    }
                    break;
            }
        }
        catch(Exception e)
        {
            System.err.println(e.getMessage());
        }
        finally
        {
            if(mongoClient != null)
                mongoClient.close();
        }
    }
    
    private static double getSum(ArrayList<String> list)
    {
        double sum = 0;
        
        for(String amount : list)
            sum += Double.parseDouble(amount);
        return sum;
    }


    private static MongoClient getMongoClient() throws Exception
    {
        MongoClient client = null;
        try
        {
            ServerAddress address = new ServerAddress(
                    config.getProperty("server"), Integer.parseInt(config.getProperty("port")));

            MongoCredential credential = MongoCredential.createCredential(
                    config.getProperty("username"),
                    config.getProperty("authenticationDatabase"),
                    config.getProperty("password").toCharArray());
            client = new MongoClient(address, Arrays.asList(credential));
        }
        catch(Exception e)
        {
            System.out.println("An error occurred while creating the MongoClient.");
            throw e;
        }
        return client;
    }
}
