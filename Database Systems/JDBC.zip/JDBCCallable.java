import java.sql.*;
import java.util.Properties;
public class JDBCCallable{
    public static void main ( String [] args ){
        String connectionURL = Login.DRIVER + Login.DB;
        Connection conn = null ;
        try {
            Class.forName (Login.DRIVER_CLASS); 
            
            //Need this because user who created stored procedure is different from invoker
            Properties prop = new Properties();
            prop.setProperty("user",Login.USER);
            prop.setProperty("password",Login.PWD);
            prop.setProperty("noAccessToProcedureBodies","true");
            
            System .out.println ("Attempting connection to " + connectionURL );
            //Use different version that takes a Properties table
            conn = DriverManager.getConnection (connectionURL, prop);
            System.out.println ("Connection successful ");
            
            double price = 12.3;
            int greaterThan = 0; //1 gets greater than, 0 gets less than
            
            String storedProc = "{call countPizzas(?,?,?,?)}"; 
            
            //Very expensive statement, reuse for multiple calls
            CallableStatement callableStatement = conn.prepareCall(storedProc);
            
            callableStatement.clearParameters(); 
            
            callableStatement.setDouble(1, price);
            callableStatement.setInt(2, greaterThan);
            
            callableStatement.registerOutParameter(3, java.sql.Types.INTEGER);
            callableStatement.registerOutParameter(4, java.sql.Types.DOUBLE);
 
            // execute store procedure
            ResultSet results =  callableStatement.executeQuery();
            
            System .out.println ("Results:");
            while (results.next ()){
                String pizzeria = results.getString ("pizzeria");
                String pizza = results.getString ("pizza");
                price =   results.getDouble ("price");
                System.out. println ("Pizzeria = " + pizzeria + ", Pizza = " + pizza 
                        + ", price = " + price);
            }
            
            int  total = callableStatement.getInt(3);
            double bounds = callableStatement.getDouble(4);
            System.out. println ("Total rows = " + total + ", bounds = " + bounds);
            
            callableStatement.close ();
            conn.close ();
        }
        catch ( Exception e) { 
            System .out.println (" Error " + e );
        }
    }
}