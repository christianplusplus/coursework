import java.sql.*;

public class JDBCQuery{
    public static void main ( String [] args ){
        //define the driver to use
        String driver = Login.DRIVER_CLASS;
        
        //the database name
        String dbName =Login.DB;  
        String user = Login.USER;
        String pw = Login.PWD;
        
        // define the DB connection URL to use
        String connectionURL = Login.DRIVER+dbName; 
        Connection conn = null ;
        try{
            Class.forName (driver ); // register the JDBC driver
            System.out.println ("Attempting connection to " 
                                + connectionURL );
            conn = DriverManager.getConnection (connectionURL,user,pw );
            System.out.println ("Connection successful ");
            Statement stmt = conn.createStatement ();
            ResultSet results = stmt.executeQuery
                ("SELECT patron , age FROM Patron");
            System.out.println (" Results:");
            while ( results.next ()) {
                String name = results.getString ("patron");
                String manf = results.getString ("age");
                System.out. println 
                    (" Name = " + name + ", Age = " + manf );
            }
            stmt.close ();
            conn.close ();
        }
        catch ( Exception e) { 
            System .out.println (" Error " + e );
        }
    }
}