
/**
 * Class to hold hard coded DB constants
 */
public class Login
{
    //MySQL   
    public static final String USER = "thomasg";
    public static final String PWD = Login2.PWD; 
    public static final String DB = "thomasg";
    public static final String DRIVER = "jdbc:mysql://localhost:3306/";
    public static final String DRIVER_CLASS = "com.mysql.jdbc.Driver";

}
