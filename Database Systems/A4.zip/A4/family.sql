CREATE TABLE Person(
    pid BIGINT AUTO_INCREMENT,
    firstName VARCHAR(100) NOT NULL DEFAULT 'John_Doe',
    middleName VARCHAR(100),
    lastName VARCHAR(100),
    dob DATE,
    dod DATE,
    gender VARCHAR(20),
    bio VARCHAR(1024),
    country VARCHAR(50),
    state VARCHAR(50),
    city VARCHAR(50),
    street VARCHAR(50),
    buildNum INTEGER,
    aptNum INTEGER,
    postalCode INTEGER,
    CONSTRAINT PRIMARY KEY (pid)
)
;
CREATE TABLE PrevNames(
    pid BIGINT,
    firstName VARCHAR(100) NOT NULL,
    middleName VARCHAR(100),
    lastName VARCHAR(100),
    dateChanged DATE,
    CONSTRAINT PRIMARY KEY (pid),
    CONSTRAINT FOREIGN KEY (pid) REFERENCES Person (pid)
    	ON DELETE CASCADE ON UPDATE NO ACTION
)
;
CREATE TABLE Association(
    pid1 BIGINT,
    pid2 BIGINT,
    assocType VARCHAR(20),
    CONSTRAINT PRIMARY KEY (pid1, pid2, assocType),
    CONSTRAINT FOREIGN KEY (pid1) REFERENCES Person (pid)
    	ON DELETE CASCADE ON UPDATE NO ACTION,
    CONSTRAINT FOREIGN KEY (pid2) REFERENCES Person (pid)
    	ON DELETE CASCADE ON UPDATE NO ACTION
)
;
CREATE TABLE Event(
    eid INTEGER AUTO_INCREMENT,
    title VARCHAR(100) NOT NULL,
    location VARCHAR(100),
    date DATE,
    description VARCHAR(1024),
    CONSTRAINT PRIMARY KEY (eid)
)
;
CREATE TABLE Present(
    eid INTEGER,
    pid BIGINT,
    CONSTRAINT PRIMARY KEY (eid, pid),
    CONSTRAINT FOREIGN KEY (eid) REFERENCES Event (eid)
    	ON DELETE CASCADE ON UPDATE NO ACTION,
    CONSTRAINT FOREIGN KEY (pid) REFERENCES Person (pid)
    	ON DELETE CASCADE ON UPDATE NO ACTION
)
;
CREATE TABLE User(
    username VARCHAR(20),
    passHash INTEGER NOT NULL,
    firstName VARCHAR(100) NOT NULL,
    middleNameOrInitial VARCHAR(100),
    LastName VARCHAR(100) NOT NULL,
    email VARCHAR(365) NOT NULL UNIQUE,
    CONSTRAINT PRIMARY KEY (username)
)
;
CREATE TABLE AuthorizedUser(
    username VARCHAR(20),
    CONSTRAINT PRIMARY KEY (username),
    CONSTRAINT FOREIGN KEY (username) REFERENCES User (username)
    	ON DELETE CASCADE ON UPDATE CASCADE
)
;
CREATE TABLE Admin(
    username VARCHAR(20),
    CONSTRAINT PRIMARY KEY (username),
    CONSTRAINT FOREIGN KEY (username) REFERENCES AuthorizedUser (username)
    	ON DELETE CASCADE ON UPDATE CASCADE
)
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('1', 'William', NULL, 'Wells', '1901-8-9', '1989-4-5', 'male', 'veteran; farmer', '123', 'main st', 'oshkosh')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('2', 'Lucy', NULL, 'Lawrence', '1909-12-12', '1965-7-7', 'female', 'some notes here', '123', 'main st', 'oshkosh')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('3', 'Leroy', NULL, 'Wells', '1928-1-2', '2010-6-1', 'male', 'some notes here', '123', 'main st', 'oshkosh')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('4', 'Tonya', NULL, 'Evans', '1934-6-4', '2010-6-1', 'female', 'PHONE{920-111-2222}', '123', 'main st', 'oshkosh')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('5', 'Clyde ', NULL, 'Wells', '1937-12-11', '2010-6-1', 'male', 'teacher', '123', 'main st', 'oshkosh')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('6', 'Anne ', NULL, 'Allison', '1931-3-7', '2010-6-1', 'female', 'teacher', '123', 'main st', 'oshkosh')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('7', 'Ross', NULL, 'Evans', '1933-5-17', '2010-6-1', 'male', 'teacher', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('8', 'Nina', NULL, 'Adkins', '1941-11-1', '2010-6-1', 'female', 'some notes here', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('9', 'Oliver', NULL, 'Wells', '1952-5-5', '2010-6-1', 'male', 'farmer', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('10', 'Gerald', NULL, 'Wells', '1955-6-8', '2010-6-1', 'male', 'farmer', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('11', 'Emma', NULL, 'Rhodes', '1952-5-2', '2010-6-1', 'female', 'PHONE{414-222-1111}', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('12', 'Melody', NULL, 'Mccormick', '1965-8-9', '2010-6-1', 'female', 'PHONE{414-222-1111}', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('13', 'Marion', NULL, 'Wells', '1974-1-1', '2008-11-1 ', 'female', 'some notes here', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('14', 'Bruce', NULL, 'Wells', '1978-3-5', '2008-11-1 ', 'male', 'some notes here', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('15', 'William ', NULL, 'Wells', '1990-7-7', '2008-11-1 ', 'male', 'some notes here', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('16', 'Marshall', NULL, 'Wells', '1985-8-8', '2008-11-1 ', 'male', 'some notes here', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('17', 'Judy', NULL, 'May', '1970-1-1', '2008-11-1 ', 'female', 'some notes here', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('18', 'Noah', NULL, 'May', '1972-3-30', '2008-11-1 ', 'male', 'some notes here', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('19', 'Ronald', NULL, 'Wells', '1974-2-8', '2008-11-1 ', 'male', 'some notes here', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('20', 'April', NULL, 'Larson', '1973-6-30', '2008-11-1 ', 'female', 'some notes here', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('21', 'Ryan', NULL, 'Wells', '2010-6-1', '2008-11-1 ', 'male', 'some notes here', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('22', 'Victor', NULL, 'May', '1995-1-1', '2008-11-1 ', 'male', 'some notes here', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('23', 'Byron', NULL, 'May', '2002-4-18', '2008-11-1 ', 'male', 'some notes here', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('24', 'Edna', NULL, 'May', '2004-5-20', '2008-11-1 ', 'female', 'some notes here', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('25', 'Lucille', NULL, 'Webster', '1997-6-22', '2008-11-1 ', 'female', 'PHONE{123-456-7890}', '456', 'main st', 'milwaukee')
;
INSERT INTO Person (pid, firstName, middleName, lastName, dob, dod, gender, bio, buildNum, street, city)
VALUES('26', 'Tonya', NULL, 'Dexter', '1980-11-4', '2008-11-1 ', 'female', 'PHONE{123-456-7890}', '456', 'main st', 'milwaukee')
;
INSERT INTO Event (eid, title, location, date)
VALUES(0, 'The birth of William Wells.', 'oshkosh', '1901-8-9')
;
INSERT INTO Event (eid, title, location, date)
VALUES(1, 'The death of William Wells.', 'milwaukee', '1989-4-5')
;
INSERT INTO Event (eid, title, location, date)
VALUES(2, 'William Wells got married.', 'oshkosh', '1927-4-1')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('2', '1', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='2'
AND pid2='1'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(3, 'The birth of Lucy Lawrence.', 'oshkosh', '1909-12-12')
;
INSERT INTO Event (eid, title, location, date)
VALUES(4, 'The death of Lucy Lawrence.', 'oshkosh', '1965-7-7')
;
INSERT INTO Event (eid, title, location, date)
VALUES(5, 'Lucy Lawrence got married.', 'oshkosh', '1927-4-1')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('1', '2', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='1'
AND pid2='2'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(6, 'The birth of Leroy Wells.', 'oshkosh', '1928-1-2')
;
INSERT INTO Event (eid, title, location, date)
VALUES(7, 'The death of Leroy Wells.', 'oshkosh', '2010-6-1')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(1, '3', 'PARENT')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(2, '3', 'PARENT')
;
INSERT INTO Event (eid, title, location, date)
VALUES(8, 'Leroy Wells got married.', 'oshkosh', '1951-4-3')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('6', '3', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='6'
AND pid2='3'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(9, 'The birth of Tonya Evans.', 'oshkosh', '1934-6-4')
;
INSERT INTO Event (eid, title, location, date)
VALUES(10, 'The death of Tonya Evans.', 'oshkosh', '2010-6-1')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(1, '4', 'PARENT')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(2, '4', 'PARENT')
;
INSERT INTO Event (eid, title, location, date)
VALUES(11, 'Tonya Evans got married.', 'oshkosh', '1960-7-2')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('7', '4', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='7'
AND pid2='4'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(12, 'The birth of Clyde  Wells.', 'oshkosh', '1937-12-11')
;
INSERT INTO Event (eid, title, location, date)
VALUES(13, 'The death of Clyde  Wells.', 'oshkosh', '2010-6-1')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(1, '5', 'PARENT')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(2, '5', 'PARENT')
;
INSERT INTO Event (eid, title, location, date)
VALUES(14, 'Clyde  Wells got married.', 'neenah', '1969-3-9')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('8', '5', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='8'
AND pid2='5'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(15, 'The birth of Anne  Allison.', 'de pere', '1931-3-7')
;
INSERT INTO Event (eid, title, location, date)
VALUES(16, 'The death of Anne  Allison.', 'oshkosh', '2010-6-1')
;
INSERT INTO Event (eid, title, location, date)
VALUES(17, 'Anne  Allison got married.', 'oshkosh', '1951-4-3')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('3', '6', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='3'
AND pid2='6'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(18, 'The birth of Ross Evans.', 'milwaukee', '1933-5-17')
;
INSERT INTO Event (eid, title, location, date)
VALUES(19, 'The death of Ross Evans.', 'oshkosh', '2010-6-1')
;
INSERT INTO Event (eid, title, location, date)
VALUES(20, 'Ross Evans got married.', 'oshkosh', '1960-7-2')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('4', '7', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='4'
AND pid2='7'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(21, 'The birth of Nina Adkins.', 'neenah', '1941-11-1')
;
INSERT INTO Event (eid, title, location, date)
VALUES(22, 'The death of Nina Adkins.', 'oshkosh', '2010-6-1')
;
INSERT INTO Event (eid, title, location, date)
VALUES(23, 'Nina Adkins got married.', 'neenah', '1969-3-9')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('5', '8', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='5'
AND pid2='8'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(24, 'The birth of Oliver Wells.', 'oshkosh', '1952-5-5')
;
INSERT INTO Event (eid, title, location, date)
VALUES(25, 'The death of Oliver Wells.', 'oshkosh', '2010-6-1')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(3, '9', 'PARENT')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(6, '9', 'PARENT')
;
INSERT INTO Event (eid, title, location, date)
VALUES(26, 'Oliver Wells got married.', 'milwaukee', '1973-10-1')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('11', '9', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='11'
AND pid2='9'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(27, 'Oliver Wells got married.', 'milwaukee', '1989-6-7')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(' 12', '9', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1=' 12'
AND pid2='9'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(28, 'Oliver Wells got divorced.', 'milwaukee', '1980-4-1')
;
UPDATE Association
SET assocType='DIVORCED'
WHERE pid1=11
AND pid2='9'
AND assocType='SPOUSE'
;
INSERT INTO Event (eid, title, location, date)
VALUES(29, 'The birth of Gerald Wells.', 'oshkosh', '1955-6-8')
;
INSERT INTO Event (eid, title, location, date)
VALUES(30, 'The death of Gerald Wells.', 'oshkosh', '2010-6-1')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(3, '10', 'PARENT')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(6, '10', 'PARENT')
;
INSERT INTO Event (eid, title, location, date)
VALUES(31, 'The birth of Emma Rhodes.', 'oshkosh', '1952-5-2')
;
INSERT INTO Event (eid, title, location, date)
VALUES(32, 'The death of Emma Rhodes.', 'oshkosh', '2010-6-1')
;
INSERT INTO Event (eid, title, location, date)
VALUES(33, 'Emma Rhodes got married.', 'milwaukee', '1973-10-1')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('9', '11', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='9'
AND pid2='11'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(34, 'Emma Rhodes got divorced.', 'milwaukee', '1980-4-1')
;
UPDATE Association
SET assocType='DIVORCED'
WHERE pid1=9
AND pid2='11'
AND assocType='SPOUSE'
;
INSERT INTO Event (eid, title, location, date)
VALUES(35, 'The birth of Melody Mccormick.', 'milwaukee', '1965-8-9')
;
INSERT INTO Event (eid, title, location, date)
VALUES(36, 'The death of Melody Mccormick.', 'oshkosh', '2010-6-1')
;
INSERT INTO Event (eid, title, location, date)
VALUES(37, 'Melody Mccormick got married.', 'milwaukee', '1989-6-7')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('9', '12', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='9'
AND pid2='12'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(38, 'The birth of Marion Wells.', 'milwaukee', '1974-1-1')
;
INSERT INTO Event (eid, title, location, date)
VALUES(39, 'The death of Marion Wells.', 'Dallas TX', '2008-11-1 ')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(9, '13', 'PARENT')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(11, '13', 'PARENT')
;
INSERT INTO Event (eid, title, location, date)
VALUES(40, 'The birth of Bruce Wells.', 'milwaukee', '1978-3-5')
;
INSERT INTO Event (eid, title, location, date)
VALUES(41, 'The death of Bruce Wells.', 'Dallas TX', '2008-11-1 ')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(9, '14', 'PARENT')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(11, '14', 'PARENT')
;
INSERT INTO Event (eid, title, location, date)
VALUES(42, 'Bruce Wells got married.', 'chicago', '2010-6-1')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('26', '14', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='26'
AND pid2='14'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(43, 'The birth of William  Wells.', 'milwaukee', '1990-7-7')
;
INSERT INTO Event (eid, title, location, date)
VALUES(44, 'The death of William  Wells.', 'Dallas TX', '2008-11-1 ')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(9, '15', 'PARENT')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(12, '15', 'PARENT')
;
INSERT INTO Event (eid, title, location, date)
VALUES(45, 'The birth of Marshall Wells.', 'new york', '1985-8-8')
;
INSERT INTO Event (eid, title, location, date)
VALUES(46, 'The death of Marshall Wells.', 'Dallas TX', '2008-11-1 ')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(10, '16', 'PARENT')
;
INSERT INTO Event (eid, title, location, date)
VALUES(47, 'The birth of Judy May.', 'neenah', '1970-1-1')
;
INSERT INTO Event (eid, title, location, date)
VALUES(48, 'The death of Judy May.', 'Dallas TX', '2008-11-1 ')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(5, '17', 'PARENT')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(8, '17', 'PARENT')
;
INSERT INTO Event (eid, title, location, date)
VALUES(49, 'Judy May got married.', 'neenah', '1994-2-2')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('18', '17', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='18'
AND pid2='17'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(50, 'The birth of Noah May.', 'neenah', '1972-3-30')
;
INSERT INTO Event (eid, title, location, date)
VALUES(51, 'The death of Noah May.', 'Dallas TX', '2008-11-1 ')
;
INSERT INTO Event (eid, title, location, date)
VALUES(52, 'Noah May got married.', 'neenah', '1994-2-2')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('17', '18', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='17'
AND pid2='18'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(53, 'The birth of Ronald Wells.', 'neenah', '1974-2-8')
;
INSERT INTO Event (eid, title, location, date)
VALUES(54, 'The death of Ronald Wells.', 'Dallas TX', '2008-11-1 ')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(5, '19', 'PARENT')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(8, '19', 'PARENT')
;
INSERT INTO Event (eid, title, location, date)
VALUES(55, 'Ronald Wells got married.', 'sheboygan', '2009-5-5')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('20', '19', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='20'
AND pid2='19'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(56, 'The birth of April Larson.', 'madison', '1973-6-30')
;
INSERT INTO Event (eid, title, location, date)
VALUES(57, 'The death of April Larson.', 'Dallas TX', '2008-11-1 ')
;
INSERT INTO Event (eid, title, location, date)
VALUES(58, 'April Larson got married.', 'sheboygan', '2009-5-5')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('19', '20', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='19'
AND pid2='20'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(59, 'The birth of Ryan Wells.', 'neenah', '2010-6-1')
;
INSERT INTO Event (eid, title, location, date)
VALUES(60, 'The death of Ryan Wells.', 'Dallas TX', '2008-11-1 ')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(19, '21', 'PARENT')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(20, '21', 'PARENT')
;
INSERT INTO Event (eid, title, location, date)
VALUES(61, 'The birth of Victor May.', 'neenah', '1995-1-1')
;
INSERT INTO Event (eid, title, location, date)
VALUES(62, 'The death of Victor May.', 'Dallas TX', '2008-11-1 ')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(17, '22', 'PARENT')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(18, '22', 'PARENT')
;
INSERT INTO Event (eid, title, location, date)
VALUES(63, 'Victor May got married.', 'green bay', '2015-4-5')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('25', '22', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='25'
AND pid2='22'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(64, 'The birth of Byron May.', 'neenah', '2002-4-18')
;
INSERT INTO Event (eid, title, location, date)
VALUES(65, 'The death of Byron May.', 'Dallas TX', '2008-11-1 ')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(17, '23', 'PARENT')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(18, '23', 'PARENT')
;
INSERT INTO Event (eid, title, location, date)
VALUES(66, 'The birth of Edna May.', 'neenah', '2004-5-20')
;
INSERT INTO Event (eid, title, location, date)
VALUES(67, 'The death of Edna May.', 'Dallas TX', '2008-11-1 ')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(17, '24', 'PARENT')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES(18, '24', 'PARENT')
;
INSERT INTO Event (eid, title, location, date)
VALUES(68, 'The birth of Lucille Webster.', 'green bay', '1997-6-22')
;
INSERT INTO Event (eid, title, location, date)
VALUES(69, 'The death of Lucille Webster.', 'Dallas TX', '2008-11-1 ')
;
INSERT INTO Event (eid, title, location, date)
VALUES(70, 'Lucille Webster got married.', 'green bay', '2015-4-5')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('22', '25', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='22'
AND pid2='25'
AND assocType='DIVORCED'
;
INSERT INTO Event (eid, title, location, date)
VALUES(71, 'The birth of Tonya Dexter.', 'green bay', '1980-11-4')
;
INSERT INTO Event (eid, title, location, date)
VALUES(72, 'The death of Tonya Dexter.', 'Dallas TX', '2008-11-1 ')
;
INSERT INTO Event (eid, title, location, date)
VALUES(73, 'Tonya Dexter got married.', 'chicago', '2010-6-1')
;
INSERT INTO Association (pid1, pid2, assocType)
VALUES('14', '26', 'SPOUSE')
;
DELETE FROM Association
WHERE pid1='14'
AND pid2='26'
AND assocType='DIVORCED'
;
INSERT INTO Present (eid, pid)
VALUES(0, '1')
;
INSERT INTO Present (eid, pid)
VALUES(1, '1')
;
INSERT INTO Present (eid, pid)
VALUES(2, '2')
;
INSERT INTO Present (eid, pid)
VALUES(2, '1')
;
INSERT INTO Present (eid, pid)
VALUES(3, '2')
;
INSERT INTO Present (eid, pid)
VALUES(4, '2')
;
INSERT INTO Present (eid, pid)
VALUES(5, '1')
;
INSERT INTO Present (eid, pid)
VALUES(5, '2')
;
INSERT INTO Present (eid, pid)
VALUES(6, '3')
;
INSERT INTO Present (eid, pid)
VALUES(7, '3')
;
INSERT INTO Present (eid, pid)
VALUES(8, '6')
;
INSERT INTO Present (eid, pid)
VALUES(8, '3')
;
INSERT INTO Present (eid, pid)
VALUES(9, '4')
;
INSERT INTO Present (eid, pid)
VALUES(10, '4')
;
INSERT INTO Present (eid, pid)
VALUES(11, '7')
;
INSERT INTO Present (eid, pid)
VALUES(11, '4')
;
INSERT INTO Present (eid, pid)
VALUES(12, '5')
;
INSERT INTO Present (eid, pid)
VALUES(13, '5')
;
INSERT INTO Present (eid, pid)
VALUES(14, '8')
;
INSERT INTO Present (eid, pid)
VALUES(14, '5')
;
INSERT INTO Present (eid, pid)
VALUES(15, '6')
;
INSERT INTO Present (eid, pid)
VALUES(16, '6')
;
INSERT INTO Present (eid, pid)
VALUES(17, '3')
;
INSERT INTO Present (eid, pid)
VALUES(17, '6')
;
INSERT INTO Present (eid, pid)
VALUES(18, '7')
;
INSERT INTO Present (eid, pid)
VALUES(19, '7')
;
INSERT INTO Present (eid, pid)
VALUES(20, '4')
;
INSERT INTO Present (eid, pid)
VALUES(20, '7')
;
INSERT INTO Present (eid, pid)
VALUES(21, '8')
;
INSERT INTO Present (eid, pid)
VALUES(22, '8')
;
INSERT INTO Present (eid, pid)
VALUES(23, '5')
;
INSERT INTO Present (eid, pid)
VALUES(23, '8')
;
INSERT INTO Present (eid, pid)
VALUES(24, '9')
;
INSERT INTO Present (eid, pid)
VALUES(25, '9')
;
INSERT INTO Present (eid, pid)
VALUES(26, '11')
;
INSERT INTO Present (eid, pid)
VALUES(26, '9')
;
INSERT INTO Present (eid, pid)
VALUES(27, ' 12')
;
INSERT INTO Present (eid, pid)
VALUES(27, '9')
;
INSERT INTO Present (eid, pid)
VALUES(11, '9')
;
INSERT INTO Present (eid, pid)
VALUES(28, '9')
;
INSERT INTO Present (eid, pid)
VALUES(29, '10')
;
INSERT INTO Present (eid, pid)
VALUES(30, '10')
;
INSERT INTO Present (eid, pid)
VALUES(31, '11')
;
INSERT INTO Present (eid, pid)
VALUES(32, '11')
;
INSERT INTO Present (eid, pid)
VALUES(33, '9')
;
INSERT INTO Present (eid, pid)
VALUES(33, '11')
;
INSERT INTO Present (eid, pid)
VALUES(9, '11')
;
INSERT INTO Present (eid, pid)
VALUES(34, '11')
;
INSERT INTO Present (eid, pid)
VALUES(35, '12')
;
INSERT INTO Present (eid, pid)
VALUES(36, '12')
;
INSERT INTO Present (eid, pid)
VALUES(37, '9')
;
INSERT INTO Present (eid, pid)
VALUES(37, '12')
;
INSERT INTO Present (eid, pid)
VALUES(38, '13')
;
INSERT INTO Present (eid, pid)
VALUES(39, '13')
;
INSERT INTO Present (eid, pid)
VALUES(40, '14')
;
INSERT INTO Present (eid, pid)
VALUES(41, '14')
;
INSERT INTO Present (eid, pid)
VALUES(42, '26')
;
INSERT INTO Present (eid, pid)
VALUES(42, '14')
;
INSERT INTO Present (eid, pid)
VALUES(43, '15')
;
INSERT INTO Present (eid, pid)
VALUES(44, '15')
;
INSERT INTO Present (eid, pid)
VALUES(45, '16')
;
INSERT INTO Present (eid, pid)
VALUES(46, '16')
;
INSERT INTO Present (eid, pid)
VALUES(47, '17')
;
INSERT INTO Present (eid, pid)
VALUES(48, '17')
;
INSERT INTO Present (eid, pid)
VALUES(49, '18')
;
INSERT INTO Present (eid, pid)
VALUES(49, '17')
;
INSERT INTO Present (eid, pid)
VALUES(50, '18')
;
INSERT INTO Present (eid, pid)
VALUES(51, '18')
;
INSERT INTO Present (eid, pid)
VALUES(52, '17')
;
INSERT INTO Present (eid, pid)
VALUES(52, '18')
;
INSERT INTO Present (eid, pid)
VALUES(53, '19')
;
INSERT INTO Present (eid, pid)
VALUES(54, '19')
;
INSERT INTO Present (eid, pid)
VALUES(55, '20')
;
INSERT INTO Present (eid, pid)
VALUES(55, '19')
;
INSERT INTO Present (eid, pid)
VALUES(56, '20')
;
INSERT INTO Present (eid, pid)
VALUES(57, '20')
;
INSERT INTO Present (eid, pid)
VALUES(58, '19')
;
INSERT INTO Present (eid, pid)
VALUES(58, '20')
;
INSERT INTO Present (eid, pid)
VALUES(59, '21')
;
INSERT INTO Present (eid, pid)
VALUES(60, '21')
;
INSERT INTO Present (eid, pid)
VALUES(61, '22')
;
INSERT INTO Present (eid, pid)
VALUES(62, '22')
;
INSERT INTO Present (eid, pid)
VALUES(63, '25')
;
INSERT INTO Present (eid, pid)
VALUES(63, '22')
;
INSERT INTO Present (eid, pid)
VALUES(64, '23')
;
INSERT INTO Present (eid, pid)
VALUES(65, '23')
;
INSERT INTO Present (eid, pid)
VALUES(66, '24')
;
INSERT INTO Present (eid, pid)
VALUES(67, '24')
;
INSERT INTO Present (eid, pid)
VALUES(68, '25')
;
INSERT INTO Present (eid, pid)
VALUES(69, '25')
;
INSERT INTO Present (eid, pid)
VALUES(70, '22')
;
INSERT INTO Present (eid, pid)
VALUES(70, '25')
;
INSERT INTO Present (eid, pid)
VALUES(71, '26')
;
INSERT INTO Present (eid, pid)
VALUES(72, '26')
;
INSERT INTO Present (eid, pid)
VALUES(73, '14')
;
INSERT INTO Present (eid, pid)
VALUES(73, '26')
;
