@author Christian Wendlandt

These are the steps I used to create the database:
1. Copy tables.sql and call the copy family.sql.
2. Input family.csv into CSVReader and append the output to family.sql.

This process is automated by build.xml. With ant installed, all I had to do
is run "ant all" in the table builder directory.

CSVReader parses family.csv, divides up the data, and then puts it back
together in a format that matches my database. CSVReader is SPECIFIC to the
family.csv format.
