/**
 * Parses special CSV files into MySQL tables.
 * 
 * @author Christian Wendlandt 
 * @version 2018.4.11
 */

import java.io.*;
import java.util.*;

public class CSVReader
{
    public static void main(String[] args)
    {
        BufferedReader reader;
        int eid = 0;
        String line;
        String id;
        String firstName = "NULL";
        String middleName = "NULL";
        String lastName = "NULL";
        String fullName;
        String gender = "NULL";
        String address;
        String phone;
        String birth = "";
        String death = "";
        String adoption = "";
        String marriages;
        String divorces;
        String parent1;
        String parent2;
        String notes;
        String dob = "NULL";
        String placeOfBirth = "NULL";
        String dod = "NULL";
        String placeOfDeath = "NULL";
        String bio = "NULL";
        String add = "NULL";
        String placeOfAdoption = "NULL";
        String spouse = "NULL";
        String weddingDate = "NULL";
        String placeOfWedding = "NULL";
        String divorceDate = "NULL";
        String placeOfDivorce = "NULL";
        String[] localAddress;
        String buildNum = "NULL";
        String street = "NULL";
        String city = "NULL";
        String[] brokenDate;
        String[] entry;
        String insertStatement;
        ArrayList<String> referenceInserts = new ArrayList<>();
        ArrayList<String> referenceInserts2 = new ArrayList<>();
        
        reader = new BufferedReader(new InputStreamReader(System.in));
        try
        {
            line = reader.readLine();//dismisses the headers
            while((line = reader.readLine()) != null)
            {
                entry = line.split(",", -1);
                id = "'" + entry[0] + "'";
                if(!entry[1].isEmpty())
                    firstName = entry[1];
                if(!entry[2].isEmpty())
                    middleName = entry[2];
                if(!entry[3].isEmpty())
                    lastName = entry[3];
                gender = entry[4];
                address = entry[5];
                phone = entry[6];
                if(!entry[7].isEmpty())
                {
                    brokenDate = entry[7].split("/");
                    birth = brokenDate[2].substring(0, 4)+'-'+brokenDate[0]+'-'+brokenDate[1]+brokenDate[2].substring(4);
                }
                if(!entry[8].isEmpty())
                {
                    brokenDate = entry[8].split("/");
                    death = brokenDate[2].substring(0, 4)+'-'+brokenDate[0]+'-'+brokenDate[1]+brokenDate[2].substring(4);
                }
                if(!entry[9].isEmpty())
                {
                    brokenDate = entry[9].split("/");
                    adoption = brokenDate[2].substring(0, 4)+'-'+brokenDate[0]+'-'+brokenDate[1]+brokenDate[2].substring(4);
                }
                marriages = entry[10];
                divorces = entry[11];
                parent1 = entry[12];
                parent2 = entry[13];
                notes = entry[14];
                
                fullName = "";
                if(firstName.equals("NULL") && middleName.equals("NULL") &&
                        lastName.equals("NULL"))
                {
                    if(gender.equals("m"))
                        fullName = "John Doe";
                    else if(gender.equals("f"))
                        fullName = "Jane Doe";
                    else
                        fullName = "unkown";
                }
                else
                {
                    fullName += firstName.equals("NULL") ? "" : firstName;
                    fullName += middleName.equals("NULL") ? "" : ' ' + middleName;
                    fullName += lastName.equals("NULL") ? "" : ' ' + lastName;
                }
                
                if(!birth.isEmpty())
                {
                    if(birth.indexOf('(') == -1)
                        dob = "'" + birth + "'";
                    else
                    {
                        dob = "'" + birth.substring(0, birth.indexOf('(')) + "'";
                        placeOfBirth = "'" + birth.substring(birth.indexOf('(') + 1,
                                birth.indexOf(')')) + "'";
                    }
                }
                
                if(!death.isEmpty())
                {
                    if(death.indexOf('(') == -1)
                        dod = "'" + death + "'";
                    else
                    {
                        dod = "'" + death.substring(0, death.indexOf('(')) + "'";
                        placeOfDeath = "'" + death.substring(death.indexOf('(') + 1,
                                death.indexOf(')')) + "'";
                    }
                }
                    
                if(!gender.isEmpty())
                {
                    if(gender.equals("f"))
                        gender = "'female'";
                    else if(gender.equals("m"))
                        gender = "'male'";
                }
                
                if(phone.isEmpty())
                {
                    if(!notes.isEmpty())
                        bio = "'" + notes + "'";
                }
                else
                {
                    if(notes.isEmpty())
                        bio = "'PHONE{" + phone + "}'";
                    else
                        bio = "'PHONE{" + phone + "}\\n" + notes + "'";
                }
                
                if(!address.isEmpty())
                {
                    localAddress = address.split(" ");
                    buildNum = "'" + localAddress[0] + "'";
                    street = "";
                    for(int i = 1; i < localAddress.length - 1; i++)
                        street += localAddress[i] + ' ';
                    street = "'" + street.trim() + "'";
                    city = "'" + localAddress[localAddress.length - 1] + "'";
                }
                
                System.out.printf("INSERT INTO Person (pid, firstName, " +
                        "middleName, lastName, dob, dod, gender, bio, " +
                        "buildNum, street, city)\nVALUES(%s, %s, %s, %s, %s, " +
                        "%s, %s, %s, %s, %s, %s)\n;\n", id, firstName.equals("NULL") ? "NULL" : "'" + firstName + "'",
                        middleName.equals("NULL") ? "NULL" : "'" + middleName + "'", lastName.equals("NULL") ? "NULL" : "'" + lastName + "'", dob, dod, gender, bio, buildNum,
                        street, city);
                        
                if(!birth.isEmpty())
                {
                    referenceInserts.add(String.format("INSERT INTO Event (eid, title, location," +
                            " date)\nVALUES(%d, %s, %s, %s)\n;\n",eid, "'The birth of " +
                            fullName + ".'", placeOfBirth, dob));
                    referenceInserts2.add(String.format("INSERT INTO Present (eid, pid)" +
                        "\nVALUES(%d, %s)\n;\n", eid++, id));
                }
                            
                if(!death.isEmpty())
                {
                    referenceInserts.add(String.format("INSERT INTO Event (eid, title, location," +
                            " date)\nVALUES(%d, %s, %s, %s)\n;\n", eid, "'The death of " +
                            fullName + ".'", placeOfDeath, dod));
                    referenceInserts2.add(String.format("INSERT INTO Present (eid, pid)" +
                        "\nVALUES(%d, %s)\n;\n", eid++, id));
                }
                
                if(!adoption.isEmpty())
                {
                    if(adoption.indexOf('(') == -1)
                        add = adoption;
                    else
                    {
                        add = adoption.substring(0, adoption.indexOf('('));
                        placeOfAdoption = adoption.substring(adoption.indexOf('(') + 1,
                                adoption.indexOf(')'));
                    }
                    referenceInserts.add(String.format("INSERT INTO Event (eid, title, location," +
                            " date)\nVALUES(%d, %s, %s, %s)\n;\n",eid, "'The adoption of " +
                             fullName + ".'", placeOfAdoption, add));
                    referenceInserts2.add(String.format("INSERT INTO Present (eid, pid)" +
                        "\nVALUES(%d, %s)\n;\n", eid++, id));
                }
                            
                if(!parent1.isEmpty())
                    referenceInserts.add(String.format("INSERT INTO Association (pid1, pid2, " +
                    "assocType)\nVALUES(%s, %s, 'PARENT')\n;\n", parent1, id));
                
                if(!parent2.isEmpty())
                    referenceInserts.add(String.format("INSERT INTO Association (pid1, pid2, " +
                    "assocType)\nVALUES(%s, %s, 'PARENT')\n;\n", parent2, id));
                    
                for(String marriage : marriages.split(";"))
                {
                    if(!marriage.isEmpty())
                    {
                        spouse = "'" + marriage.substring(0, marriage.indexOf('-')) + "'";
                        if(marriage.indexOf('(') == -1)
                        {
                            weddingDate = marriage.substring(marriage.lastIndexOf('-') + 1);
                            brokenDate = weddingDate.split("/");
                            weddingDate = "'" + brokenDate[2]+'-'+brokenDate[0]+'-'+brokenDate[1] + "'";
                        }
                        else
                        {
                            weddingDate = marriage.substring(marriage.lastIndexOf('-') + 1,
                                    marriage.indexOf('('));
                            brokenDate = weddingDate.split("/");
                            weddingDate = "'" + brokenDate[2]+'-'+brokenDate[0]+'-'+brokenDate[1] + "'";
                            placeOfWedding = "'" + marriage.substring(marriage.indexOf('(') + 1,
                                    marriage.indexOf(')')) + "'";
                        }
                        referenceInserts.add(String.format("INSERT INTO Event (eid, title, location," +
                                " date)\nVALUES(%d, %s, %s, %s)\n;\n", eid , "'" +
                                fullName + " got married.'", placeOfWedding, weddingDate));
                        referenceInserts2.add(String.format("INSERT INTO Present (eid, pid)" +
                        "\nVALUES(%d, %s)\n;\n", eid, spouse));
                        referenceInserts2.add(String.format("INSERT INTO Present (eid, pid)" +
                        "\nVALUES(%d, %s)\n;\n", eid++, id));
                        referenceInserts.add(String.format("INSERT INTO Association (pid1, pid2, " +
                        "assocType)\nVALUES(%s, %s, 'SPOUSE')\n;\n", spouse, id));
                        referenceInserts.add(String.format("DELETE FROM Association\n" +
                        "WHERE pid1=%s\n" +
                        "AND pid2=%s\n" +
                        "AND assocType='DIVORCED'\n;\n", spouse, id));
                    }
                }
                
                for(String divorce : divorces.split(";"))
                {
                    if(!divorce.isEmpty())
                    {
                        spouse = divorce.substring(0, divorce.indexOf('-'));
                        if(divorce.indexOf('(') == -1)
                        {
                            divorceDate = divorce.substring(divorce.lastIndexOf('-') + 1);
                            brokenDate = divorceDate.split("/");
                            divorceDate = "'" + brokenDate[2]+'-'+brokenDate[0]+'-'+brokenDate[1] + "'";
                        }
                        else
                        {
                            divorceDate = divorce.substring(divorce.lastIndexOf('-') + 1,
                                    divorce.indexOf('('));
                            brokenDate = divorceDate.split("/");
                            divorceDate = "'" + brokenDate[2]+'-'+brokenDate[0]+'-'+brokenDate[1] + "'";
                            placeOfDivorce = "'" + divorce.substring(divorce.indexOf('(') + 1,
                                    divorce.indexOf(')')) + "'";
                        }
                        referenceInserts.add(String.format("INSERT INTO Event " +
                                "(eid, title, location, date)\nVALUES(%d, %s, %s, %s)" +
                                "\n;\n", eid, "'" + fullName + " got divorced.'",
                                placeOfDivorce, divorceDate));
                        referenceInserts2.add(String.format("INSERT INTO Present (eid, pid)" +
                        "\nVALUES(%s, %s)\n;\n", spouse, id));
                        referenceInserts2.add(String.format("INSERT INTO Present (eid, pid)" +
                        "\nVALUES(%d, %s)\n;\n", eid++, id));
                        referenceInserts.add(String.format("UPDATE Association\n" +
                        "SET assocType='DIVORCED'\n" +
                        "WHERE pid1=%s\n" +
                        "AND pid2=%s\n" +
                        "AND assocType='SPOUSE'\n;\n", spouse, id));
                    }
                }
            }
            for(String insert : referenceInserts)
                System.out.print(insert);
            for(String insert : referenceInserts2)
                System.out.print(insert);
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }
    }
}
