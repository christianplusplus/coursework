DROP TABLE Present;
DROP TABLE Event;
DROP TABLE Association;
DROP TABLE PrevNames;
DROP TABLE Person;
DROP TABLE Admin;
DROP TABLE AuthorizedUser;
DROP TABLE User;
