-- 01
SELECT 
    CONCAT(
        COALESCE(firstName, ''),
        ' ',
        COALESCE(middleName, ''),
        ' ',
        COALESCE(lastName, '')
    )
FROM Person
WHERE lastName = 'may'
;
-- 02
SELECT *
FROM Person
WHERE pid IN
    (
        SELECT pid1
        FROM Association
        WHERE Association.pid2 = 17
        AND Association.assocType = 'PARENT'
    )
;
-- 03
SELECT *
FROM Person
WHERE pid IN
    (
        SELECT pid2
        FROM Association
        WHERE Association.pid1 = 17
        AND Association.assocType = 'PARENT'
    )
;
-- 04
SELECT *
FROM Person
WHERE pid IN
    (
        SELECT pid2
        FROM Association
        WHERE pid1 IN
            (
                SELECT pid1
                FROM Association
                WHERE Association.pid2 = 17
                AND Association.assocType = 'PARENT'
            )
        AND Association.assocType = 'PARENT'
        AND pid2 != 17
    )
;
-- 05
SELECT *
FROM Person
WHERE pid IN
    (
        SELECT pid1
        FROM Association
        WHERE pid2 IN
            (
                SELECT pid1
                FROM Association
                WHERE Association.pid2 = 17
                AND Association.assocType = 'PARENT'
            )
        AND Association.assocType = 'PARENT'
    )
;
-- 06
SELECT *
FROM Person
WHERE pid IN
    (
        SELECT pid2
        FROM Association
        WHERE pid1 IN
            (
                SELECT pid2
                FROM Association
                WHERE Association.pid1 = 1
                AND Association.assocType = 'PARENT'
            )
        AND Association.assocType = 'PARENT'
    )
;
-- 07
SELECT *
FROM Person
WHERE pid IN
    (
        SELECT pid2
        FROM Association
        WHERE pid1 = 9
        AND Association.assocType = 'SPOUSE'
    )
;
-- 08
SELECT *
FROM Event
WHERE eid IN
    (
        SELECT eid
        FROM Present
        WHERE pid = 1
    )
;
-- 09
SELECT *
FROM Person
WHERE bio LIKE '%farmer%'
;
-- 10
SELECT *
FROM Event
WHERE date = '2010-6-1'
;
