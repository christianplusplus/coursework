/**
 * Connects, queries, and prints responses from a mySQL database.
 *
 * @author Christian Wendlandt
 * @version 2018.4.3
 */

import java.sql.*;
import java.io.FileInputStream;
import java.util.Properties;

public class Query
{
    public static void main(String[] args)
    {
        Properties config;
        Connection conn = null;
        PreparedStatement statement;
        ResultSet results1;
        ResultSet results2 = null;
        String db;
        String user;
        String pw;
        String driver;
        String url;
        int queryType = Integer.parseInt(args[0]);
        String variable = args[1];
        
        try
        {
            config = loadProperties("config.properties");
            db = config.getProperty("database");
            user = config.getProperty("username");
            pw = config.getProperty("password");
            driver = config.getProperty("driver");
            url = config.getProperty("url") + db;
            
            registerDriver(driver);
            
            System.out.println("Attempting connection...");
            conn = createConnection(url, user, pw);
            System.out.println("Connection successfully made.");
            
            statement = prepareStatement(queryType, variable, conn);
            results1 = statement.executeQuery();
            if(queryType == 3)
            {
                statement = prepareStatement(4, variable, conn);
                results2 = statement.executeQuery();
            }
            
            printResults(results1, results2, queryType);
        }
        catch(SQLException ex){System.out.println("SQL Error " + ex.getMessage());}
        catch(Exception ex){System.out.println("General Error " + ex.getMessage());}
        finally
        {
            try
            {
                conn.close();
                System.out.println("Connection closed.");
            }
            catch(Exception ex){}
        }
    }
    
    private static void registerDriver(String driver) throws Exception
    {
        Class.forName(driver);
    }
    
    private static Properties loadProperties(String filename) throws Exception
    {
        Properties config = new Properties();
        
        try
        {
            FileInputStream file = new FileInputStream(filename);
            config.load(file);
            file.close();
            return config;
        }
        catch(Exception e)
        {
            throw new Exception("An error occurred while trying to load config.properties.");
        }
    }
    
    private static Connection createConnection(String url, String user, String pw)
            throws SQLException, Exception
    {
        return DriverManager.getConnection(url,user,pw);
    }
    
    private static PreparedStatement prepareStatement(int queryType, String variable, Connection conn)
            throws SQLException
    {
        PreparedStatement statement;
        
        switch(queryType)
        {
            case 1:
                statement = conn.prepareStatement(
                        "SELECT DISTINCT cname FROM Loan " +
                        "WHERE amount > ? " +
                        "ORDER BY cname;");
                break;
            case 2:
                statement = conn.prepareStatement(
                        "SELECT cname, SUM(amount) FROM Loan " +
                        "GROUP BY cname " +
                        "HAVING COUNT(*) > ?;");
                break;
            case 3:
                statement = conn.prepareStatement(
                        "SELECT Customer.cname, bname, balance " +
                        "FROM Customer LEFT JOIN Deposit ON Customer.cname = Deposit.cname " +
                        "WHERE Customer.cname = ?;");
                break;
            case 4:
                statement = conn.prepareStatement(
                        "SELECT Customer.cname, bname, amount " +
                        "FROM Customer LEFT JOIN Loan ON Customer.cname = Loan.cname " +
                        "WHERE Customer.cname = ?;");
                break;
            default:
                throw new SQLException("Not a query that this program can handle.");
        }
        statement.clearParameters();
        statement.setString(1, variable);
        return statement;
    }
    
    private static void printResults(ResultSet results1, ResultSet results2, int queryType)
            throws SQLException
    {
        String branch;
        
        System.out.println();
        switch(queryType)
        {
            case 1:
                while(results1.next())
                    System.out.println(results1.getString("cname"));
                break;
            case 2:
                while(results1.next())
                    System.out.printf("%s has $%,.2f in Loans.\n", results1.getString("cname"),
                            results1.getDouble("SUM(amount)"));
                break;
            case 3:
                if(results1.next())
                {
                    System.out.println("Deposit accounts for " + results1.getString("cname") + ":");
                    branch = results1.getString("bname");
                    if(results1.wasNull())
                        System.out.println("No accounts found.");
                    else
                        System.out.printf("%s : $%,.2f\n", branch, results1.getDouble("balance"));
                }
                while(results1.next())
                    System.out.printf("%s : $%,.2f\n", results1.getString("bname"),
                            results1.getDouble("balance"));
                System.out.println();
                if(results2.next())
                {
                    System.out.println("Loan accounts for " + results2.getString("cname") + ":");
                    branch = results2.getString("bname");
                    if(results2.wasNull())
                        System.out.println("No accounts found.");
                    else
                        System.out.printf("%s : $%,.2f\n", branch, results2.getDouble("amount"));
                }
                while(results2.next())
                    System.out.printf("%s : $%,.2f\n", results2.getString("bname"),
                            results2.getDouble("amount"));
        }
        System.out.println();
    }
}