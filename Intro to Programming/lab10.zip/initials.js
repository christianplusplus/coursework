function makeInitials(){
	var name, firstInitial, middleInitial, lastInitial, output;
	name = document.getElementById('inputString').value;
	firstInitial = name.charAt(0);
	name = name.substring(name.search(' ')+1);
	middleInitial = name.charAt(0);
	name = name.substring(name.search(' ')+1);
	lastInitial = name.charAt(0);
	output = firstInitial.toUpperCase() +
		'.' +
		middleInitial.toUpperCase() +
		'.' +
		lastInitial.toUpperCase();
	document.getElementById('outputInitials').innerHTML = output;
}
function checkPalindrome(){
	var text, counter, status, output;
	text = document.getElementById('inputString').value;
	text = text.toLowerCase();
	counter = 0;
	status = true;
	while(counter < Math.floor(text.length/2)){
		status = status && text.charAt(counter) == text.charAt(text.length - 1 - counter)
		counter ++;
	}
	if(status){
		output = 'This is a Palindrome.';
	}
	else{
		output = 'This is not a Palindrome.';
	}
	document.getElementById('outputPalindrome').innerHTML = output;
}