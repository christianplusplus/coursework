var total=0, correct=0, guess;

function restart(){
	document.getElementById('new').disabled = false;
	document.getElementById('square').disabled = true;
	document.getElementById('triangle').disabled = true;
	document.getElementById('circle').disabled = true;
	document.getElementById('star').disabled = true;
	document.getElementById('answer').disabled = true;
}
function beginGuess(){
	document.getElementById('new').disabled = true;
	document.getElementById('square').disabled = false;
	document.getElementById('triangle').disabled = false;
	document.getElementById('circle').disabled = false;
	document.getElementById('star').disabled = false;
	document.getElementById('answer').disabled = true;
	document.getElementById('mysteryImg').src = 'images/mystery.gif';
	document.getElementById('output').innerHTML = 'Guess the correct shape.';
}
function checkSquare(){
	guess = 0;
	document.getElementById('answer').disabled = false;
	document.getElementById('output').innerHTML = 'You guessed square. Make a different guess or check your answer.';
}
function checkTriangle(){
	guess = 1;
	document.getElementById('answer').disabled = false;
	document.getElementById('output').innerHTML = 'You guessed triangle. Make a different guess or check your answer.';
}
function checkCircle(){
	guess = 2;
	document.getElementById('answer').disabled = false;
	document.getElementById('output').innerHTML = 'You guessed circle. Make a different guess or check your answer.';
}
function checkStar(){
	guess = 3;
	document.getElementById('answer').disabled = false;
	document.getElementById('output').innerHTML = 'You guessed star. Make a different guess or check your answer.';
}
function checkAnswer(){
	var answer, percent;
	answer = Math.floor(4 * Math.random());
	document.getElementById('mysteryImg').src = 'images/shape' + answer + '.gif';
	document.getElementById('output').innerHTML = 'Oops! Wrong answer.';
	if(guess == answer){
		document.getElementById('output').innerHTML = 'You guessed correctly! Good Job.';
		correct++;
	}
	total++;
	percent = Math.round(10000 * correct / total) / 100;
	document.getElementById('new').disabled = false;
	document.getElementById('square').disabled = true;
	document.getElementById('triangle').disabled = true;
	document.getElementById('circle').disabled = true;
	document.getElementById('star').disabled = true;
	document.getElementById('answer').disabled = true;
	document.getElementById('correctSpan').innerHTML = correct;
	document.getElementById('totalSpan').innerHTML = total;
	document.getElementById('percentSpan').innerHTML = percent;
}