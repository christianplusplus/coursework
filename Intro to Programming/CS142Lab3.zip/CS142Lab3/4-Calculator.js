function sum(){
	a=parseFloat(document.getElementById('inputA').value);
	b=parseFloat(document.getElementById('inputB').value);
	c=parseFloat(document.getElementById('inputC').value);
	d=parseFloat(document.getElementById('inputD').value);
	result=a+b+c+d;
	document.getElementById('output').innerHTML=result;
}
function difference(){
	a=parseFloat(document.getElementById('inputA').value);
	b=parseFloat(document.getElementById('inputB').value);
	c=parseFloat(document.getElementById('inputC').value);
	d=parseFloat(document.getElementById('inputD').value);
	result=a-b-c-d;
	document.getElementById('output').innerHTML=result;
}
function product(){
	a=parseFloat(document.getElementById('inputA').value);
	b=parseFloat(document.getElementById('inputB').value);
	c=parseFloat(document.getElementById('inputC').value);
	d=parseFloat(document.getElementById('inputD').value);
	result=a*b*c*d;
	document.getElementById('output').innerHTML=result;
}
function quotient(){
	a=parseFloat(document.getElementById('inputA').value);
	b=parseFloat(document.getElementById('inputB').value);
	c=parseFloat(document.getElementById('inputC').value);
	d=parseFloat(document.getElementById('inputD').value);
	result=a/b/c/d;
	document.getElementById('output').innerHTML=result;
}