function SetRandom(){
	document.getElementById('x1').value=Math.floor(100*Math.random()+1);
	document.getElementById('y1').value=Math.floor(100*Math.random()+1);
	document.getElementById('x2').value=Math.floor(100*Math.random()+1);
	document.getElementById('y2').value=Math.floor(100*Math.random()+1);
}
function Calculate(){
	var x1=parseFloat(document.getElementById('x1').value);
	var y1=parseFloat(document.getElementById('y1').value);
	var x2=parseFloat(document.getElementById('x2').value);
	var y2=parseFloat(document.getElementById('y2').value);
	var distance=Math.sqrt(Math.pow(x1-x2,2)+Math.pow(y1-y2,2));
	var result=Math.round(100*distance)/100;
	document.getElementById('output').innerHTML=
	'The distance between('+
	x1+
	','+
	y1+
	') and ('+
	x2+
	','+
	y2+
	') is '+
	result;
}