function CheckTriangle(){
	var lengthA,lengthB,lengthC,result;
	lengthA = parseFloat(document.getElementById('sideA').value);
	lengthB = parseFloat(document.getElementById('sideB').value);
	lengthC = parseFloat(document.getElementById('sideC').value);
	if(lengthA > 0){
		if(lengthB > 0){
			if(lengthC > 0){
				if(lengthA == lengthB){
					if(lengthB == lengthC){
						result = 'This is an equilateral triangle.';
					}
					else result = 'This is an isosceles triangle.';
				}
				else if(lengthB == lengthC){
					result = 'This is an isosceles triangle.';
				}
				else if(lengthA == lengthC){
					result = 'This is an isosceles triangle.';
				}
				else result = 'This is a scalene triangle.';
			}
			else result = 'This is not a triangle!';
		}
		else result = 'This is not a triangle!';
	}
	else result = 'This is not a triangle!';
	document.getElementById('output').innerHTML = result;
}