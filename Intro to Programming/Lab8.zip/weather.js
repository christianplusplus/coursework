function DewOperate(){
	var textTemperature, textHumidity, temperature, humidity, dewpoint, errorMsg;
	textTemperature = document.getElementById("temp").value;
	temperature = parseFloat(textTemperature);
	textHumidity = document.getElementById("humid").value;
	humidity = parseFloat(textHumidity);
	dewpoint = DewCalculate(temperature,humidity);
	dewpoint = Math.round(dewpoint * 100) / 100;
	document.getElementById("dewout").innerHTML = 
		"Today's dew point is "
		+ dewpoint
		+ "F&deg.";
	errorMsg = '';
	if(textTemperature == ''){
		errorMsg += 'No temperature specified.<br>';
	}
	else if(isNaN(temperature)){
		errorMsg += 'Temperature must be a number.<br>';
	}
	if(textHumidity == ''){
		errorMsg += 'No humidity specified.<br>';
	}
	else if(isNaN(humidity)){
		errorMsg += 'Humidity must be a number.<br>';
	}
	if(humidity < 0 || humidity > 100){
		errorMsg += 'Humidity must be between 0 and 100%.<br>';
	}
	if(errorMsg != ''){
		document.getElementById("dewout").innerHTML = errorMsg;
	}
}
function DewCalculate(temp,humid){
	return temp - (100 - humid) / 2.778;
}
function WindOperate(){
	var textTemperature, textWindSpeed, temperature, windSpeed, windChill, errorMsg;
	textTemperature = document.getElementById("temp").value;
	temperature = parseFloat(textTemperature);
	textWindSpeed = document.getElementById("wind").value;
	windSpeed = parseFloat(textWindSpeed);
	windChill = WindCalculate(temperature,windSpeed);
	windChill = Math.round(windChill * 100) / 100;
	document.getElementById("windout").innerHTML = 
		"Today's wind chill index is "
		+ windChill
		+ "F&deg.";
	errorMsg = '';
	if(textTemperature == ''){
		errorMsg += 'No temperature specified.<br>';
	}
	else if(isNaN(temperature)){
		errorMsg += 'Temperature must be a number.<br>';
	}
	if(textWindSpeed == ''){
		errorMsg += 'No wind speed specified.<br>';
	}
	else if(isNaN(windSpeed)){
		errorMsg += 'Wind speed must be a number.<br>';
	}
	if(windSpeed < 0){
		errorMsg += 'Wind speed cannot be negative.<br>';
	}
	if(errorMsg != ''){
		document.getElementById("windout").innerHTML = errorMsg;
	}
}
function WindCalculate(temp,wind){
	return 35.74 + 0.6215 * temp + (0.4275 * temp - 35.75) * Math.pow(wind,0.16);
}