var userScore=0, computerScore=0, currScore=0;
var MAX=100;
function startup(){
	document.getElementById("hold").disabled = true;
	document.getElementById("comp").disabled = true;
}
function roll(){
	var msg, die;
	die = Math.floor(6 * Math.random()) + 1;
	document.getElementById('output').innerHTML = '';
	if(die == 1){
		currScore = 0
		document.getElementById('roll').disabled = true;
		document.getElementById('hold').disabled = true;
		document.getElementById('comp').disabled = false;
		msg = 'Oh no! You rolled a 1. Your turn is over now.';
	}
	else{
		currScore += die;
		document.getElementById("hold").disabled = false;
		msg = 'Hold or roll again.';
	}
	document.getElementById('score').innerHTML = currScore;
    document.getElementById('dieImg').src = 'images/die' + die + '.gif';
	document.getElementById('output').innerHTML = msg;
}
function hold(){
	var msg;
	userScore += currScore;
	currScore = 0;
	document.getElementById('roll').disabled = true;
	document.getElementById('hold').disabled = true;
	document.getElementById('comp').disabled = false;
	document.getElementById('myscore').value = userScore;
	document.getElementById('score').innerHTML = currScore;
	msg = 'Good job! Now let the computer try.';
	if(userScore >= MAX){
		document.getElementById('comp').disabled = true;
		msg = '';
		alert('Congraduations! You win!');
	}
	document.getElementById('output').innerHTML = msg
}
function computerTurn(){
	var imgName;
	var i=0;
	var times = Math.floor(Math.random()*4) + 1;
	var mesg='Computer begins turn:<br>';
	document.getElementById("roll").disabled = true;
	document.getElementById("hold").disabled = true;
	while (i<times){
		i += 1;
		mesg += 'Rolling...';
		var roll=Math.floor(Math.random()*6) + 1;
		imgName='images/die' + roll + '.gif';
    	document.getElementById('dieImg').src = imgName;
    	if (roll==1){
			currScore = 0;
			mesg += 'Computer rolled a 1<br>'
			break;
		}
		else{
    		currScore += roll;
    		mesg += 'Computer rolled a '+roll+'. Current roll total = '+currScore+'<br>';
    		if (computerScore+currScore>=MAX){
					break;
			}
		}
	}
	computerScore += currScore;
	mesg += 'Computer ends turn with turn score = '+currScore+ ' and total score = '+computerScore+'<br>';
	currScore = 0;
	document.getElementById('myscore').value=userScore;
	document.getElementById('compscore').value=computerScore;
	document.getElementById('score').innerHTML=currScore;
	if (computerScore>=MAX){
		mesg +='Computer has won! Game over';
	}
	else{
		document.getElementById("roll").disabled = false;
	}
	document.getElementById('output').innerHTML=mesg;
	document.getElementById('comp').disabled = true;
}

