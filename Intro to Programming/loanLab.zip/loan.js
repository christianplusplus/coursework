function Loan(){
	var p, r, n, m, principal, rate, totalM, totalI, month, col1, col2, col3, col4, col5, error;
	principal = parseFloat(document.getElementById('principal').value);
	p = principal;
	rate = parseFloat(document.getElementById('interest').value);
	r = rate;
	r /= 1200;
	n = parseFloat(document.getElementById('months').value);
	month = 1;
	m = Math.ceil(100*(p*r/(1 - 1/Math.pow(1 + r,n))))/100;
	totalM = 0;
	totalI = 0;
	col1 = '<b>Month</b><br>';
	col2 = '<b>Payment</b><br>';
	col3 = '<b>Principal</b><br>';
	col4 = '<b>Interest</b><br>';
	col5 = '<b>Balance</b><br>';
	while(p > 0){
		col1 += month + '<br>';
		month ++;
		col2 += '$' + m + '<br>';
		totalM = Math.round(100*(totalM + m))/100;
		col3 += '$' + Math.round(100*(m - r*p))/100 + '<br>';
		col4 += '$' + Math.round(100*r*p)/100 + '<br>';
		totalI = Math.round(100*(totalI + r*p))/100;
		p = Math.round(100*(1 + r)*p)/100 - m;
		col5 += '$' + Math.round(100*p)/100 + '<br>';
		if((1 + r)*p < m){
			m = Math.round(100*(1 + r)*p)/100;
		}
	}
	document.getElementById('output').innerHTML =
		'<hr><table style="margin:0px auto;"><tr><td>' +
		col1 +
		'</td><td>' +
		col2 +
		'</td><td>' +
		col3 +
		'</td><td>' +
		col4 +
		'</td><td>' +
		col5 +
		'</td></tr></table><hr>Total Paid Amount: $' +
		totalM +
		'&nbsp;&nbsp;&nbsp;Total Paid Interest: $' +
		totalI;
	error = '';
	if(isNaN(principal)){
		error += 'Principal must be an amount.<br>';
	}
	else if(principal <= 0){
		error += 'Principal must be greater than zero.<br>';
	}
	if(isNaN(rate)){
		error += 'Rate must be a percentage.<br>';
	}
	else if(rate <= 0){
		error += 'Rate must be greater than zero.<br>';
	}
	if(isNaN(n)){
		error += 'Months must be an amount.<br>';
	}
	else if(n % 1 != 0 || n < 2){
		error += 'Months must be an integer of at least 2.<br>';
	}
	if(error != ''){
		document.getElementById('output').innerHTML = 'Error:<br>' + error;
	}
}