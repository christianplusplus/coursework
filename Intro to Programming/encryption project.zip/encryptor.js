var array = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
function EncryptText(){
	var inputString, outputString, character, index, shift;
	inputString = document.getElementById('text').value.toLowerCase();
	shift = parseFloat(document.getElementById('shift').value);
	if(isNaN(shift) || shift%1 != 0){
		document.getElementById('output').innerHTML = 'ERROR<br>Encryption Level must be an integer.';
		document.getElementById('returnButton').innerHTML = '';
		return;
	}
	outputString = '';
	while(inputString != ''){
		character = inputString.charAt(0);
		index = array.indexOf(character);
		
		if(index >= 0){
			while(index + shift < 0){
				shift += 26;
			}
			while(index + shift > 25){
				shift -= 26;
			}
			character = array[index + shift];
		}
		outputString += character;
		inputString = inputString.substring(1,inputString.length);
	}
	document.getElementById('output').innerHTML = outputString;
	document.getElementById('returnButton').innerHTML = '<br><input type="button" value="Return to Textbox" onclick="ReturntoTextbox()">';
}
function DecryptText(){
	var inputString, outputString, character, index, shift;
	inputString = document.getElementById('text').value.toLowerCase();
	shift = parseFloat(document.getElementById('shift').value);
	if(isNaN(shift) || shift%1 != 0){
		document.getElementById('output').innerHTML = 'ERROR<br>Encryption Level must be an integer.';
		document.getElementById('returnButton').innerHTML = '';
		return;
	}
	outputString = '';
	while(inputString != ''){
		character = inputString.charAt(0);
		index = array.indexOf(character);
		if(index >= 0){
			while(index - shift > 25){
				shift += 26;
			}
			while(index - shift < 0){
				shift -= 26;
			}
			character = array[index - shift];
		}
		outputString += character;
		inputString = inputString.substring(1,inputString.length);
	}
	document.getElementById('output').innerHTML = outputString;
	document.getElementById('returnButton').innerHTML = '<br><input type="button" value="Return to Textbox" onclick="ReturntoTextbox()">';
}
function ReturntoTextbox(){
	document.getElementById('text').value = document.getElementById('output').innerHTML;
}