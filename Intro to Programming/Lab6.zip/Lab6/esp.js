/* Renamed image files to simplify fuctions. */
var guess;
function GuessSquare(){
	guess = 0;
}
function GuessTriangle(){
	guess = 1;
}
function GuessCircle(){
	guess = 2;
}
function GuessStar(){
	guess = 3;
}
function CheckShape(){
	var shape, correctSpan, totalSpan, percentSpan, answer;
	correctSpan = parseFloat(document.getElementById('correctSpan').innerHTML);
	totalSpan = parseFloat(document.getElementById('totalSpan').innerHTML);
	
	answer = 'Nope. Try again.';
	shape = Math.floor((4 * Math.random()));
	if(shape == guess){
		correctSpan = correctSpan + 1;
		answer = 'Correct!';
	}
	totalSpan = totalSpan + 1;
	percentSpan = Math.round(10000 * correctSpan / totalSpan) / 100;
	
	document.getElementById('mysteryImg').src = 'images/shape' + shape + '.gif';
	document.getElementById('output').innerHTML = answer;
	document.getElementById('correctSpan').innerHTML = correctSpan;
	document.getElementById('totalSpan').innerHTML = totalSpan;
	document.getElementById('percentSpan').innerHTML = percentSpan;
}