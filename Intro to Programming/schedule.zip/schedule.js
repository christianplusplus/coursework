function cs142Info(){
	alert("Instructor: George Thomas");
}
function cs125Info(){
	alert("Instructor: Kathleen Lynch");
}
function math222Info(){
	alert("Instructor: Linda Eroh");
}
function math301Info(){
	alert("Instructor: K Gunawardena");
}
function nameChangeToEmail(){
	document.getElementById('myName').innerHTML='<i>wendlc69@uwosh.edu</i>';
}
function emailChangeToName(){
	document.getElementById('myName').innerHTML='<i>Christian Wendlandt\'s</i>';
}