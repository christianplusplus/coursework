"""
Christian Wendlandt
Professor George Thomas
CS300
Assignment 1
2018.9.27
"""

#each state is a tuple (F,M,P,T,D1,D2,S1,S2,B) with initial value (1,1,1,1,1,1,1,1,1)
#a typical end goal is (-1,-1,-1,-1,-1,-1,-1,-1,-1)
#each value represents which side of the river each person/object is on
#1 for the left side of the river and -1 for the right side of the river
#each action must move the boat (B) from one side of the river to the other
#and must include at least one adult (F,M, or P)
#then each action is to pick an adult on the same side as the boat and possibly one partner from the same side
#for example: (1,1,-1,-1,-1,-1,1,1,1) -> (-1,1,-1,-1,-1,-1,-1,1,-1)
#in this action, the father takes son #1 from the left side to the right side with the boat

from search import Problem, breadth_first_search,depth_first_search, iterative_deepening_search

class RP(Problem):
    #these variables will be used as indices for the list
    F = 0 #father
    M = 1 #mother
    P = 2 #police officer
    T = 3 #thief
    D1 = 4 #daughter 1
    D2 = 5 #daughter 2
    S1 = 6 #son 1
    S2 = 7 #son 2
    B = 8 #boat
    
    def __init__(self, goal):
        self.initial = (1,1,1,1,1,1,1,1,1)
        self.goalState = goal
    
    def actions(self, state):
        list = []
        
        #state[RP.X]-2*state[RP.B] effectively moves a person to the other side
        
        #this takes care of the father, mother, or police man traveling by themselves
        for i in range(3):
            action = [x for x in state]
            action[i] -= 2*action[RP.B]
            action[RP.B] -= 2*action[RP.B]
            if self.validate(action):
                list.append(tuple(action))
        
        #this takes care of the father, mother, or police man traveling with someone else
        for i in range(3):
            for j in range(i+1,RP.B):
                action = [x for x in state]
                action[i] -= 2*action[RP.B]
                action[j] -= 2*action[RP.B]
                action[RP.B] -= 2*action[RP.B]
                if self.validate(action):
                    list.append(tuple(action))
            
        return list
    
    def validate(self, state):
        #verify that everyone is either on the left or the right, as opposed the "far left", "far right", or "in the middle"
        for i in state:
            if abs(i) != 1:
                return False
        
        #dad can not be in the presence of the girls without mom
        #mom can not be in the presence of the boys without dad
        if state[RP.F] != state[RP.M]:
            if state[RP.F] == state[RP.D1] or state[RP.F] == state[RP.D2] or state[RP.M] == state[RP.S1] or state[RP.M] == state[RP.S2]:
                return False
        
        #the thief can not be alone with any of the family without the policeman
        if state[RP.P] != state[RP.T]:
            if state[RP.T] == state[RP.F]:
                return False
            if state[RP.T] == state[RP.M]:
                return False
            if state[RP.T] == state[RP.D1]:
                return False
            if state[RP.T] == state[RP.D2]:
                return False
            if state[RP.T] == state[RP.S1]:
                return False
            if state[RP.T] == state[RP.S2]:
                return False
                
        return True
    
    def result(self, state, action):
        return action
    
    def goal_test(self, state):
        return state == self.goalState
        
def main():
    print("Raft Problem:")
    goalState = (-1,-1,-1,-1,-1,-1,-1,-1,-1)

    problem = RP(goalState)
    goal = breadth_first_search(problem)
    print("Path = ")
    print("{")
    for i in goal.path():
        print(i)
    print("}")
    print ("Path cost =",end=" ")
    print(goal.path_cost)

main()