"""
Christian Wendlandt
Professor George Thomas
CS300
Assignment 1
2018.9.27
"""

#each state is a tuple (J1,J2,J3) with initial value (7,0,0)
#a typical end goal is (2,2,3)
#each value represents the number of liters of water in a particular jug
#each action pours water from one jug to another without spilling over
#and without stopping unless the "pourer" is empty or the "pouree" is full
#the capacity of each jug is defined by the tuple (7,4,3)
#an example action: (7,0,0) -> (3,4,0)
#in this action, jug #1 is poured into jug #2 but stops just before jug #2 spills over

from search import Problem, breadth_first_search,depth_first_search, iterative_deepening_search

class JP(Problem):
    #this tuple will be used to check the capacity of the jugs
    capacity = (7,4,3)
    
    def __init__(self, goal):
        self.initial = (7,0,0)
        self.goalState = goal
    
    def actions(self, state):
        list = []
        
        #this attempts to pour each non-empty jug into each other jug
        for i in range(len(state)):
            for j in range(len(state)):
                if i == j or state[i] == 0 or j == JP.capacity[j]:
                    continue
                action = [x for x in state]
                difference = min(state[i],JP.capacity[j]-state[j])
                action[i] -= difference
                action[j] += difference
                if self.validate(action):
                    list.append(tuple(action))
            
        return list
    
    #with the way I create them, I don't think I have any invalid actions
    def validate(self, state):
        #verify that each jug has a volume of water that is between zero and its capacity
        for i in range(len(state)):
            if state[i] < 0 or state[i] > JP.capacity[i]:
                return False
                
        return True
    
    def result(self, state, action):
        return action
    
    def goal_test(self, state):
        return state == self.goalState
        
def main():
    print("Jug Problem:")
    goalState = (2,2,3)

    problem = JP(goalState)
    goal = breadth_first_search(problem)
    print("Path = ")
    print("{")
    for i in goal.path():
        print(i)
    print("}")
    print ("Path cost =",end=" ")
    print(goal.path_cost)

main()