#CS300
#Assigment 3
#Christian Wendlandt
#2018.11.6

from search import Problem
from csp import backtracking_search, no_inference, forward_checking, mac
from csp import first_unassigned_variable,mrv,num_legal_values,unordered_domain_values,lcv
from csp import CSP,usa,france,australia,NQueen,UniversalDict

#______________________________________________________________________________
#

# Variables are stored not as individual 1's and 0's on the board, but as numbers that
# represent the rows and columns. So in an nxn board, we have 2n variables, where
# variables 0 through n-1 represent the rows, and variables n through 2n-1 represent
# the columns.
#
# We represent a sequence of 0's and 1's as the numerical value of that sequence as a
# binary number. From the left to right, or top to bottem, the sequences are considered
# as little-endian.
#
# As an example:
#
# 1100
# 0101
# 1010
# 0011
#
# yields the following variable set: [0:3,1:10,2:5,3:12,4:5,5:3,6:12,7:10].
# The solution is not actually ordered like in this example.
# We use bit operators to access the value of an individual cell.

#______________________________________________________________________________
#

# Implements each of the row/col binary constraints of the board.
# X < size implies that X is a row.
# X >= size implies that X is a column.
def constraints(A, a, B, b):
    if A < size:
        if B < size:
            return a!=b
        else:
            return ((a >> (B - size)) & 1) == ((b >> A) & 1)
    else:
        if B < size:
            return ((a >> B) & 1) == ((b >> (A - size)) & 1)
        else:
            return a!=b
    return True # should never really reach this line

#______________________________________________________________________________
#
    
# Checks that a row/column sequence does not contain more than 2 0's or 1's in a row,
# as well as making sure that the 0's and 1's are balanced.
# We utilize the dynamic programming paradigm to minimize runtime.
def isValidNumber(number):
    if number in validNumbers:
        return validNumbers[number]
    balance = 0
    count0 = 0
    count1 = 0
    for i in range(size):
        if number & (1 << i) == 0:
            count0 += 1
            count1 = 0
            balance += 1
        else:
            count1 += 1
            count0 = 0
            balance -= 1
        if count0 == 3 or count1 == 3:
            validNumbers[number] = False
            return False
    validNumbers[number] = balance == 0
    return balance == 0
    
def rowMatchesMap(number, row, map):
    for i in range(size):
        if map[row][i] == '1' and (number >> i) & 1 != 1:
            return False
        if map[row][i] == '0' and (number >> i) & 1 != 0:
            return False
    return True

def colMatchesMap(number, col, map):
    for i in range(size):
        if map[i][col] == '1' and (number >> i) & 1 != 1:
            return False
        if map[i][col] == '0' and (number >> i) & 1 != 0:
            return False
    return True
    
#______________________________________________________________________________
#

def printMap(map):
    for line in map:
        for char in line:
            print(char, end='')
        print()
        
def printSolution(solution):
    for i in range(size):
        for j in range(size):
            print((solution[i] >> j) & 1, end = '')
        print()
        
#______________________________________________________________________________
# These next four methods find cutoff points for the domain ranges.
# For example, if the 3rd bit in a row is 1, then the row value must
# be at least 8. This makes trimming the Domain a bit faster.

def getRowFloors(map):
    floors = [];
    for i in range(0, size):
        floors.append(0)
    for i in range(0, size):
        for j in range(0, size):
            if(map[i][j] == '1'):
                floors[i] += 1 << j
    return floors
    
def getRowCeils(map):
    ceils = [];
    max = 2**size - 1
    for i in range(0, size):
        ceils.append(max)
    for i in range(0, size):
        for j in range(0, size):
            if(map[i][j] == '0'):
                ceils[i] -= 1 << j
    return ceils
    
def getColFloors(map):
    floors = [];
    for i in range(0, size):
        floors.append(0)
    for i in range(0, size):
        for j in range(0, size):
            if(map[j][i] == '1'):
                floors[i] += 1 << j
    return floors
    
def getColCeils(map):
    ceils = [];
    max = 2 ** size - 1
    for i in range(0, size):
        ceils.append(max)
    for i in range(0, size):
        for j in range(0, size):
            if(map[j][i] == '0'):
                ceils[i] -= 1 << j
    return ceils
    
#______________________________________________________________________________
#
    
def makeVars():
    vars = []
    for i in range(2 * size):
        vars.append(i)
    return vars
    
def makeNeighbors(vars):
    neighbors = {}
    for var in vars:
        list = []
        for j in range(var):
            list.append(j)
        for j in range(var + 1, len(vars)):
            list.append(j)
        neighbors[var] = list
    return neighbors
    
def makeDomains(vars, rowFloors, rowCeils, colFloors, colCeils):
    domain = {}
    for var in vars:
        if var < size:
            domain[var] = range(rowFloors[var], rowCeils[var] + 1)
        else:
            domain[var] = range(colFloors[var - size], colCeils[var - size] + 1)
    return domain
        
def trimDomains(domains, map):
    for domain in domains:
        domains[domain] = [i for i in domains[domain] if isValidNumber(i)]
    for value in range(size):
        domains[value] = [i for i in domains[value] if rowMatchesMap(i, value, map)]
    for value in range(size + 1, size * 2):
        domains[value] = [i for i in domains[value] if colMatchesMap(i, value - size, map)]

#______________________________________________________________________________
#
        
def solvePuzzle(map):
    global size, validNumbers
    size = len(map)
    validNumbers = {}
    
    rowFloors = getRowFloors(map)
    rowCeils = getRowCeils(map)
    colFloors = getColFloors(map)
    colCeils = getColCeils(map)
    
    vars = makeVars()
    domains = makeDomains(vars, rowFloors, rowCeils, colFloors, colCeils)
    neighbors = makeNeighbors(vars)
    
    trimDomains(domains, map)
    
    problem = CSP(vars, domains, neighbors, constraints)
    return backtracking_search(problem, select_unassigned_variable=mrv,
            order_domain_values=lcv, inference=mac)
          
def runFileToSysOut(filename):
    file = open(filename, 'r')
    map = [list(line) for line in file.read().splitlines()]
    printMap(map)
    result = solvePuzzle(map)
    print()
    printSolution(result)
    print()

#______________________________________________________________________________
# Here we define inputs and outputs at the API level.
# I've only defined one method for input/output.         
# The program crashes if a Sujiru board is unsolvable.

def main():
    runFileToSysOut('p1.txt')
    runFileToSysOut('p2.txt')
    runFileToSysOut('p3.txt')

main()