#CS300
#Assignment 2
#Problem 1
#Christian Wendlandt
#2018.10.22

from search import Problem, breadth_first_search,depth_first_search, iterative_deepening_search
from search import UndirectedGraph,GraphProblem,Graph
from search import InstrumentedProblem,compare_searchers
from search import uniform_cost_search,greedy_best_first_graph_search,astar_search
from utils import Dict,euclidean,infinity

#______________________________________________________________________________   
#the way that the graph is described in the handout seems to contradict that
#you want the graph to be undirected. note that a 1->3 edge has a different
#weight than a 3->1 edge. so then the graph is actually directed.
def readMap(file):
	array = dict()
	map = dict()
	j = 0
	for line in file.readlines():
		i = 0
		for char in line:
			if char != '\n':
				array[(i,j)] = int(char)
				i += 1
		j += 1
	for x in array:
		if array[x] == 0:
			continue
		map[x] = dict()
		if (x[0]+1,x[1]) in array and array[(x[0]+1,x[1])] != 0:
			map[x][(x[0]+1,x[1])] = array[(x[0]+1,x[1])]
		if (x[0],x[1]+1) in array and array[(x[0],x[1]+1)] != 0:
			map[x][(x[0],x[1]+1)] = array[(x[0],x[1]+1)]
		if (x[0]-1,x[1]) in array and array[(x[0]-1,x[1])] != 0:
			map[x][(x[0]-1,x[1])] = array[(x[0]-1,x[1])]
		if (x[0],x[1]-1) in array and array[(x[0],x[1]-1)] != 0:
			map[x][(x[0],x[1]-1)] = array[(x[0],x[1]-1)]
	return map

#______________________________________________________________________________
#implementation of the manhattan distance heuristic
class myProblem(GraphProblem):
	def h(self, node):
		locs = getattr(self.graph, 'locations', None)
		if locs:
			return abs(locs[node.state][0]-locs[self.goal][0])+abs(locs[node.state][1]-locs[self.goal][1])
		else:
			return infinity

#______________________________________________________________________________
def readTuple(file):
	badCharacters = '()\n '
	line = file.readline()
	for char in badCharacters:
		line = line.replace(char, '')
	return (int(line.split(',')[0]), int(line.split(',')[1]))

#______________________________________________________________________________
def main():
	file = open('L1.txt', 'r')
	start = readTuple(file)
	goal = readTuple(file)
	map = readMap(file)
	graph = Graph(map)
	graph.locations = Dict()
	for i in graph.nodes():
		graph.locations.update({i : i}) 
	problem1 = InstrumentedProblem(myProblem(start, goal, graph))

	file = open('L2.txt', 'r')
	start = readTuple(file)
	goal = readTuple(file)
	map = readMap(file)
	graph = Graph(map)
	graph.locations = Dict()
	for i in graph.nodes():
		graph.locations.update({i : i}) 
	problem2 = InstrumentedProblem(myProblem(start, goal, graph))

	file = open('L3.txt', 'r')
	start = readTuple(file)
	goal = readTuple(file)
	map = readMap(file)
	graph = Graph(map)
	graph.locations = Dict()
	for i in graph.nodes():
		graph.locations.update({i : i}) 
	problem3 = InstrumentedProblem(myProblem(start, goal, graph))

	problems = [problem1, problem2, problem3]
	header = ['Algorithm', 'L1((1,1),(19,14))', 'L2((1,1),(12,11))', 'L3((1,1),(4,13))']
	searchers = [uniform_cost_search, greedy_best_first_graph_search, astar_search]
	compare_searchers(problems, header, searchers)

main()