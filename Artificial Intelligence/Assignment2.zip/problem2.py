#CS300
#Assignment 2
#Problem 2
#Christian Wendlandt
#2018.10.22

from search import Problem
from utils import probability, argmax, weighted_sample_with_replacement
import random,math

#______________________________________________________________________________
#Genetic algorithms

def genetic_search(problem, fitness_fn, ngen=1000, pmut=0.1):
	"""Call genetic_algorithm on the appropriate parts of a problem.
	This requires the problem to have states that can mate and mutate,
	plus a value method that scores states.
	"""
	s = problem.initial
	states = [problem.result(s, a) for a in problem.actions(s)]
	random.shuffle(states)
	return genetic_algorithm(states, problem.value, ngen, pmut)
	
def genetic_algorithm(population, fitness_fn, ngen=1000, pmut=0.1):
	highest = 0
	highestEvolved = None
	for i in range(ngen):
		new_population = []
		for j in range(len(population)):
			fitnesses = map(fitness_fn, population)
			p1, p2 = weighted_sample_with_replacement(population, fitnesses, 2)
			child = p1.mate(p2)
			if random.uniform(0, 1) < pmut:
				child.mutate()
			new_population.append(child)
		population = new_population
		
		#Check and keep track of max; not necessarily pure GA
		currentEvolved = argmax(population, fitness_fn)
		currentHigh = fitness_fn(currentEvolved)
		if currentHigh > highest:    
			highest = currentHigh
			highestEvolved = currentEvolved
	return highestEvolved
	
	#Pure GA might return this instead        
	#return argmax(population, fitness_fn)
	
class GAState:
	"Abstract class for individuals in a genetic search."
	def __init__(self, genes, gen):
		self.genes = genes
		self.gen = gen #added to track generations

	def mate(self, other):
		"Return a new individual crossing self and other."
		c = random.randrange(len(self.genes))
		return self.__class__(self.genes[:c] + other.genes[c:],self.gen+1)

	def mutate(self):
		"Change a few of my genes."
		abstract

	def __repr__(self):
		return "%s" % (self.genes,)
	
	#override if this is not what you want
	def __eq__(self,other):
		return isinstance(other, GAState) and self.genes == other.genes
 
#______________________________________________________________________________
#NQueenProblem and NQueenState
class NQueenState(GAState):
	'''
	special state for genetic algorithms, extends from GAState NQueen problem
	genes is the state for regular problems, wrapped in GAState child for this version
	Override the methods you are interested in.
	'''
	def __init__(self, genes, gen):
		GAState.__init__(self, genes, gen)

	def mutate(self):
		col = random.randrange(len(self.genes))
		mut = random.randrange(len(self.genes))
		while mut == self.genes[col]:
			mut = random.randrange(len(self.genes))
		self.genes[col] = mut
		
class NQueenProblem(Problem):
	'''
	The problem of placing N queens on an NxN board with none attacking
	each other.  The problem can be initialized to some random, non-viable state.
	Recall that the states (init, etc.) are all NQueenState objects, so the genes 
	in the state are represented as an N-element array, where
	a value of r in the c-th entry means there is a queen at column c,
	row r. Keeps track of the number of steps too.
	'''
	def __init__(self, N, init):
		self.N = N
		self.initial = init

	def actions(self, state):
		neighbors = []
		for i in range(len(state.genes)):
			if state.genes[i]-1 >= 0:
				neighbor = []
				for j in range(len(state.genes)):
					neighbor.append(state.genes[j])
				neighbor[i] = state.genes[i]-1
				neighbors.append(NQueenState(neighbor, state.gen+1))
			if state.genes[i]+1 < len(state.genes):
				neighbor = []
				for j in range(len(state.genes)):
					neighbor.append(state.genes[j])
				neighbor[i] = state.genes[i]+1
				neighbors.append(NQueenState(neighbor, state.gen+1))
		return neighbors
	
	def result(self, state, action):
		''' Modify this if your result state is different from your action'''
		return action

	def value(self, state):
		count = 0
		for i in range(len(state.genes)):
			for j in range(i+1,len(state.genes)):
				if i != j and not(self.conflict(state.genes[i], i, state.genes[j], j)):
					count += 1
		return count

	def conflict(self, row1, col1, row2, col2):    
		'''
		Utility method. You can use this in other methods.
		Would putting two queens in (row1, col1) and (row2, col2) conflict?
		'''
		return (row1 == row2 ## same row
				or col1 == col2 ## same column
				or row1-col1 == row2-col2  ## same \ diagonal
				or row1+col1 == row2+col2) ## same / diagonal

#______________________________________________________________________________
def makeProblems(count, size, sizeRange):
	problems = []
	for i in range(count):
		for j in range(sizeRange):
			genes = []
			for k in range(size + j):
				genes.append(random.randrange(size + j))
			print(genes)
			problem = NQueenProblem(size + j, NQueenState(genes,0))
			problems.append(problem)
	return problems

#______________________________________________________________________________
def main():
	count = 1
	size = 8
	sizeRange = 3
	generations = 100
	mutationRate = .1
	problems = makeProblems(count, size, sizeRange)
	#'''
	for problem in problems:
		goal = genetic_search(problem, NQueenProblem.value, ngen=100, pmut=0.1)
		print("Best Offspring = ", goal)
		print("Value = ", problem.value(goal))
		print("Generation = ", goal.gen)
	'''
	file = open('data.dat','w')
	file.write('V G Q\n')
	file.close()
	file = open('data.dat','a')
	run = 0
	totalRuns = count * sizeRange
	for problem in problems:
		goal = genetic_search(problem, NQueenProblem.value, ngen=generations, pmut=mutationRate)
		maxScore = (len(goal.genes)-1)*len(goal.genes)/2
		file.write(str(problem.value(goal))+' '+str(generations if problem.value(goal) != maxScore else goal.gen)+' '+str(len(goal.genes))+'\n')
		run += 1
		print('{0:.2f}%'.format(run/totalRuns*100))
	file.close()
	print('done...')
	'''

main()