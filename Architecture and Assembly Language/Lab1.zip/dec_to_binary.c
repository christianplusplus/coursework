#include "stdio.h"

#define MAX_BITS 32

void print_binary(int);

int main()
{
	int num;
	printf("Enter a valid positive (32-bit) integer: ");
	scanf("%d", &num);
	print_binary(num);
	printf("\n");
	return 0;
}

void print_binary(int val)
{
	int array[MAX_BITS];
	int index = 0;
	while(val > 0)
	{
		array[index] = val % 2;
		index++;
		val /= 2;
	}
	index--;
	while(index >= 0)
	{
	printf("%d", array[index]);
	index--;
	}
}
