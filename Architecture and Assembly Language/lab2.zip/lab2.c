#include "stdio.h"
#include "string.h"
#define MAX_BITS 256

int main()
{
	int the_bits[MAX_BITS];
	char the_value[MAX_BITS];
	int dec_num = 0;
	int twos_pow = 1;
	int len;
	int i;

	printf("Enter up to a 32-bit integer in two's complement: ");
	scanf("%s", the_value);
	
	len = strlen(the_value);
	
	for(i = 0; i < len; i++)
	{
		the_bits[i] = the_value[i] - '0';
	}

	if(the_bits[0] == 0)
	{
		for(i = len - 1; i >= 0; i--)
		{
			dec_num += the_bits[i] * twos_pow;
			twos_pow *= 2;
		}
	}
	else
	{
		printf("-");
		for(i = 0; i < len; i++) //Flip the bits.
			the_bits[i] = 1 - the_bits[i];
		the_bits[len - 1]++; //Add a one to the LSB.
		for(i = len - 1; i >= 0; i--) //Carry it through.
		{
			if(i = 0 && the_bits[i] > 1)
				the_bits[i] = 0;
			else if(the_bits[i] > 1)
			{
				the_bits[i] = 0;
				the_bits[i-1]++;
			}
		}
		for(i = len - 1; i >= 0; i--)
		{
			dec_num += the_bits[i] * twos_pow;
			twos_pow *= 2;
		}
	}
	
	printf("%d\n", dec_num);
	
	return 0;
}
