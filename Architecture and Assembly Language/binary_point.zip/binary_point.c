#include "stdio.h"
#define MAX_BITS 32

void main()
{
  double input;
  int integral;
  int integralCount = 0;
  int integralBinary[MAX_BITS];
  double decimal;
  int decimalCount = 0;
  int decimalBinary[MAX_BITS];
  int i;

  printf("Enter a positive real value: ");
  scanf("%lf", &input);

  integral = (int)input;
  decimal = input - integral;

  while(integral > 0)
  {
    integralBinary[integralCount++] = integral % 2;
    integral /= 2;
  }

  while(decimalCount < MAX_BITS)
  {
    decimal *= 2;
    if(decimal >= 1)
    {
      decimalBinary[decimalCount++] = 1;
      decimal--;
    }
    else
      decimalBinary[decimalCount++] = 0;
    if(decimal == 0)
      break;
  }

  while(integralCount > 0)
    printf("%d", integralBinary[--integralCount]);

  printf(".");

  for(i = 0; i < decimalCount; i++)
    printf("%d", decimalBinary[i]);

  printf("\n");
}
