#include "stdio.h"
#include "stdlib.h"
/*******************************************************************************
 * Description: Matrix Multiplication Application.
 * Author: Christian Wendlandt
 * Date: 04/04/17
*******************************************************************************/
void inputDimensions(char* , unsigned*, unsigned*);
int checkArraySizes(unsigned, unsigned);
int** allocateArray(unsigned, unsigned);
int checkMalloc(int**, unsigned);
void freeArray(int**, unsigned);
void inputArray(char*, int**, unsigned, unsigned);
void printArray(char*, int**, unsigned, unsigned);
void matrixProduct(int**, int**, unsigned, unsigned, int**, unsigned);
int dotProduct(int**, int**, unsigned, unsigned, unsigned);
int power(int, int);
int getMaxLength(int**, unsigned, unsigned);

int main()
{
  int** arrayA;
  unsigned arrayARows;
  unsigned arrayACols;
  int** arrayB;
  unsigned arrayBRows;
  unsigned arrayBCols;
  int** productArray;

  inputDimensions("first", &arrayARows, &arrayACols);
  inputDimensions("second", &arrayBRows, &arrayBCols);
  if(checkArraySizes(arrayACols, arrayBRows))
    return 1;

  arrayA = allocateArray(arrayARows, arrayACols);
  if(checkMalloc(arrayA, arrayARows))
    return 1;

  arrayB = allocateArray(arrayBRows, arrayBCols);
  if(checkMalloc(arrayB, arrayBRows))
  {
    freeArray(arrayA, arrayARows);
    return 1;
  }

  productArray = allocateArray(arrayARows, arrayBCols);
  if(checkMalloc(productArray, arrayARows))
  {
    freeArray(arrayA, arrayARows);
    freeArray(arrayB, arrayBRows);
    return 1;
  }

  inputArray("first", arrayA, arrayARows, arrayACols);
  inputArray("second", arrayB, arrayBRows, arrayBCols);
  printArray("first", arrayA, arrayARows, arrayACols);
  printArray("second", arrayB, arrayBRows, arrayBCols);

  matrixProduct(productArray, arrayA, arrayARows, arrayACols,
      arrayB, arrayBCols);
  printArray("product", productArray, arrayARows, arrayBCols);

  freeArray(arrayA, arrayARows);
  freeArray(arrayB, arrayBRows);
  freeArray(productArray, arrayARows);

  return 0;
}

int** allocateArray(unsigned arrayRows, unsigned arrayCols)
{
  unsigned i;
  int** array;

  array = (int**)malloc(arrayRows * sizeof(int*));
  if(array == NULL)
    return array;
  for(i = 0; i < arrayRows; i++)
  {
    *(array + i) = (int*)malloc(arrayCols * sizeof(int));
    if(*(array + i) == NULL)
      return array;
  }
  return array;
}

int checkMalloc(int** array, unsigned arrayRows)
{
  int i;

  if(array == NULL)
  {
    freeArray(array, 0);
    printf("malloc failed\n");
    return 1;
  }
  for(i = 0; i < arrayRows; i++)
    if(*(array + i) == NULL)
    {
      freeArray(array, i);
      printf("malloc failed\n");
      return 1;
    }
  return 0;
}

void freeArray(int** array, unsigned index)
{
  unsigned i;

  for(i = 0; i < index; i++)
    free(*(array + i));
  free(array);
}

void inputDimensions(char* numeral, unsigned* rows, unsigned* cols)
{
  printf("Enter the dimensions of the %s matrix:", numeral);
  scanf("%u", rows);
  scanf("%u", cols);
}

int checkArraySizes(unsigned cols, unsigned rows)
{
  if(cols != rows)
  {
    printf("Incompatible dimensions.\n");
    return 1;
  }
  return 0;
}

void inputArray(char* numeral, int** array,
    unsigned arrayRows, unsigned arrayCols)
{
  unsigned i;
  unsigned j;

  printf("Enter the values for the %s matrix:\n", numeral);
  for(i = 0; i < arrayRows; i++)
    for(j = 0; j < arrayCols; j++)
      scanf("%d", *(array + i) + j);
}

void printArray(char* numeral, int** array,
    unsigned arrayRows, unsigned arrayCols)
{
  unsigned i;
  unsigned j;
  int maxLength = getMaxLength(array, arrayRows, arrayCols);

  printf("Here is your %s matrix:\n", numeral);
  for(i = 0; i < arrayRows; i++)
  {
    for(j = 0; j < arrayCols; j++)
      printf("%*d ", maxLength, *(*(array + i) + j));
    printf("\n");
  }
}

void matrixProduct(int** productArray, int** arrayA, unsigned arrayARow,
    unsigned arrayAColOrBRow, int** arrayB, unsigned arrayBCol)
{
  unsigned i;
  unsigned j;

  for(i = 0; i < arrayARow; i++)
    for(j = 0; j < arrayBCol; j++)
      *(*(productArray + i) + j) = dotProduct(arrayA, arrayB,
          i, j, arrayAColOrBRow);
}

int dotProduct(int** arrayA, int** arrayB,
    unsigned row, unsigned col, unsigned termsLength)
{
  int product = 0;
  unsigned i;

  for(i = 0; i < termsLength; i++)
    product += (*(*(arrayA + row) + i)) * (*(*(arrayB + i) + col));

  return product;
}

int power(int base, int exponent)
{
  int i;
  int result = 1;

  for(i = 0; i < exponent; i++)
    result *= base;

 return result;
}

int getMaxLength(int** array, unsigned arrayRows, unsigned arrayCols)
{
  int i;
  int j;
  int maxLength = 1;
  int factorIfNegative;
  int num;

  for(i = 0; i < arrayRows; i++)
    for(j = 0; j < arrayCols; j++)
    {
      num = *(*(array + i) + j);
      factorIfNegative = num < 0 ? 10 : 1;
      while(abs(num) * factorIfNegative >= power(10, maxLength))
        maxLength++;
    }

  return maxLength;
}
