/************************************************************
 * Description: Adder for unsigned integer values.
 * Author: Christian Wendlandt
 * Date: 03/05/17
************************************************************/
#include "stdio.h"

#define MAX_BITS 32

unsigned short get_bits(unsigned int, short);
unsigned short sum(unsigned short, unsigned short, unsigned short);
unsigned short carry(unsigned short, unsigned short, unsigned short);
unsigned int set_bit(unsigned int, short, unsigned short);

void main()
{
  unsigned int a, b;
  unsigned int result = 0;
  unsigned short ai, bi, si;
  unsigned short cIn = 0;
  short i;

  printf("Enter two positive numbers: ");
  scanf("%u%u", &a, &b);

  for(i = 0; i < MAX_BITS; i++)
  {
    ai = get_bits(a, i);
    bi = get_bits(b, i);
    si = sum(cIn, ai, bi);
    cIn = carry(cIn, ai, bi);
    result = set_bit(result, i, si);
  }

  if(cIn)
    printf("overflow has occured\n");
  else
  {
    printf("Result in decimal: %u\n", result);
    printf("Result in hex: %x\n", result);
  }
}

unsigned short get_bits(unsigned int num, short i)
{
  unsigned int mask = 1;

  mask = mask << i;
  num = num & mask;
  num = num >> i;

  return (unsigned short)num;
}

unsigned short sum(unsigned short cIn, unsigned short ai, unsigned short bi)
{
  return ai ^ bi ^ cIn;
}

unsigned short carry(unsigned short cIn, unsigned short ai, unsigned short bi)
{
  return (ai & bi) | ((ai ^ bi) & cIn);
}

unsigned int set_bit(unsigned int result, short i, unsigned short si)
{
  unsigned int mask = si;
  mask = mask << i;

  return result | mask;
}
