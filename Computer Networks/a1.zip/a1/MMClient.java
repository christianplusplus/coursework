/** Client program for the MM app
 *
 *  @author Christian Wendlandt
 *
 *  @version CS 391 - Spring 2018 - A1
 **/

import java.io.*;
import java.net.*;

public class MMClient
{
    private static final int ANSWER_SIZE = 4;
    static String hostName = "localhost";// name of server machine
    static int portNumber = 5555;// port on which server listens
    static Socket socket;// socket to server
    static DataInputStream in;// input stream from server
    static DataOutputStream out;// output stream to server
    static BufferedReader console;// keyboard input stream
    static String thankYou = "    Thank you for playing!";
    static String lengthError = "    Your guess must be exactly " +
            ANSWER_SIZE + " characters long.\n";
    static String charError = "    Your guess can only have A, B, " +
            "C, D, E, or F in it.\n";
    static String guessAgain = "    Guess again...";
    static String yOrN = "    Y or N please...";
    static String youWinPlayAgain = "    You win!\n" +
            "    Another game? (Y/N)";
    
    /* connect to the server then repeatedly perform the 3 following
       steps:
           1. read the reply from the server
           2. input the user's next query string
           3. if the query is in {"Y","y","N","n"}, send it to the
              server as is else repeatedly prompt the user for a
              4-character query String that is then sent to the server
       until the server's reply is "    Thank you for playing!".
       The amount and format of the console output (e.g., user prompt,
       server replies) are imposed as part of the problem statement
       in the handout (as shown in the provided session trace).
     */
    public static void main(String[] args)
    {
        String query, reply, inputError;
        
        try
        {
            socket = new Socket(hostName, portNumber);
            System.out.println("Connected to server: " + socket);
            openStreams();
            while(true)
            {
                reply = in.readUTF();
                System.out.println(reply);
                if(reply.equals(thankYou))
                    break;
                query = console.readLine().trim().toUpperCase();
                while(!query.matches("[A-F]{" + ANSWER_SIZE + "}"))
                {
                    inputError = "";
                    if(reply.equals(youWinPlayAgain))
                    {
                        if(query.matches("[YN]"))
                            break;
                        inputError += yOrN;
                    }
                    else
                    {
                        if(!query.matches(".{" + ANSWER_SIZE + "}"))
                            inputError += lengthError;
                        if(!query.matches("[A-F]+"))
                            inputError += charError;
                        inputError += guessAgain;
                    }
                    System.out.println(inputError);
                    query = console.readLine().trim().toUpperCase();
                }
                out.writeUTF(query);
            }
            close();
        }
        catch(UnknownHostException ex)
        {
            System.err.println("Unknown host: " + hostName);
            close();
            System.exit(1);
        }
        catch(IOException ex)
        {
            System.err.println("I/O error when connecting to " +
                    hostName);
            close();
            System.exit(1);
        }
    }// main method

    /* open the necessary I/O streams and initializes the in, out,
       and console static variables; this method does not catch
       any exceptions.
     */
    static void openStreams() throws IOException
    {
        in = new DataInputStream(socket.getInputStream());
        out = new DataOutputStream(socket.getOutputStream());
        console = new BufferedReader(
                new InputStreamReader(System.in));
    }// openStreams method

    /* close ALL open I/O streams and sockets
     */
    static void close()
    {
        try
        {
            if(console != null)
                console.close();
            if(in != null)
                in.close();
            if(out != null)
                out.close();
            if(socket != null)
                socket.close();
        }
        catch(IOException ex)
        {
            System.err.println("Error in close(): " +
                    ex.getMessage());
        }
    }// close method
}// MMClient class