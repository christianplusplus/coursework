/** Peer.java - A peer-to-peer file sharing program
 *
 *  @version CS 391 - Spring 2018 - A4
 *
 *  @author Christian Wendlandt
 * 
 *  @bug The initial join of a new peer does work fully.
 *
 *  @bug The Status command does work fully.
 *
 *  @bug The Find command does work fully.
 *
 *  @bug The Get command does work fully.
 * 
 *  @bug The Quit command does work fully.
 * 
 **/

import java.io.*;
import java.net.*;
import java.util.*;

class Peer {
    String name,    // symbolic name of the peer, e.g., "P1" or "P2"
    ip,         // IP address in dotted decimal notation, e.g., "127.0.0.1"
    filesPath;  // path to local file repository, e.g., "dir1/dir2/dir3"
    int lPort,      // lookup port number (permanent UDP port)
    ftPort;     // file transfer port number (permanent TCP port)
    List<Neighbor> neighbors;      // current neighbor peers of this peer
    LookupThread  lThread;         // thread listening to the lookup socket
    FileTransferThread  ftThread;  // thread list. to the file transfer socket
    int seqNumber;                 // identifier for next Find request (used to
                                   // control the flooding by avoiding loops)
    Scanner scanner;               // used for keyboard input
    HashSet<String> findRequests;  // record of all lookup requests seen so far

    /* Instantiate a new peer (including setting a value of 1 for its initial
       sequence number), launch its lookup and file transfer threads,
       (and start the GUI thread, which is already implemented for you)
     */
    Peer(String name2, String ip, int lPort, String filesPath, 
     String nIP, int nPort) {
        name = name2;
        try 
        {
            this.ip = InetAddress.getByName(ip).toString();
            int slash = this.ip.indexOf("/");
            if(slash > -1 )
            this.ip = this.ip.substring(slash+1);
        }
        catch(UnknownHostException ex)
        {
        System.err.println("Unknown host: " + ip);
        System.exit(1);
        }
        this.lPort = lPort;
        ftPort = lPort + 1;
        this.filesPath = filesPath;
        neighbors = new ArrayList<>();
        if(nIP != null)
            neighbors.add(new Neighbor(nIP, nPort));
        scanner = new Scanner(System.in);
        findRequests = new HashSet<>();
        seqNumber = 1;
        GUI gui = new GUI();
        GUI.createAndShowGUI(name);
        lThread = new LookupThread();
        lThread.start();
        ftThread = new FileTransferThread();
        ftThread.start();
    }// constructor

    /* display the commands available to the user
       Do NOT modify this method.
     */
    static void displayMenu() {
    System.out.println("\nYour options:");
    System.out.println("    1. [S]tatus");
    System.out.println("    2. [F]ind <filename>");
    System.out.println("    3. [G]et <filename> <peer IP> <peer port>");
    System.out.println("    4. [Q]uit");
    System.out.print("Your choice: ");
    }// displayMenu method

    /* input the next command chosen by the user
     */
    int getChoice() {
        switch(scanner.next().trim().toUpperCase())
        {
            case "1":
            case "S":
                return 1;
            case "2":
            case "F":
                return 2;
            case "3":
            case "G":
                return 3;
            case "4":
            case "Q":
                return 4;
        }
        return -1;
    }// getChoice method
        
    /* this is the implementation of the peer's main thread, which
       continuously displays the available commands, input the user's
       choice, and executes the selected command, until the latter
       is "Quit"
     */
    public void run() {
        while(true)
        {
            displayMenu();
            try
            {
                switch(getChoice())
                {
                    case 1:
                        processStatusRequest();
                        break;
                    case 2:
                        processFindRequest();
                        break;
                    case 3:
                        processGetRequest();
                        break;
                    case 4:
                        processQuitRequest();
                        System.exit(0);
                    default:
                        System.out.println("Please input one of the" +
                                " displayed commands.");
                }
            }
            catch(NumberFormatException ex)
            {
                System.out.println("One of the arguments is a malfo" +
                        "rmed number.");
            }
        }
    }// run method

    /* execute the Quit command, that is, send a "leave" message to all of the
       peer's neighbors, then terminate the lookup thread
     */
    void processQuitRequest() {
        DatagramSocket socket;
        DatagramPacket packet;
        String message;
        byte[] buf;
        
        try
        {
            socket = new DatagramSocket();
            for(Neighbor neighbor : neighbors)
            {
                message = "leave " + ip + ' ' + lPort;
                buf = message.getBytes();
                packet = new DatagramPacket(buf, buf.length,
                        InetAddress.getByName(neighbor.ip),
                        neighbor.port);
                socket.send(packet);
            }
            lThread.terminate();
            ftThread.close();
            if(ftThread.serverSocket != null)
                ftThread.serverSocket.close();
        }
        catch(SocketException ex)
        {
            System.err.println(ex);
        }
        catch(UnknownHostException ex)
        {
            System.err.println(ex);
        }
        catch(IOException ex)
        {
            System.err.println(ex);
        }
    }// processQuitRequest method

    /* execute the Status command, that is, read and display the list
       of files currently stored in the local directory of shared
       files, then print the list of neighbors. The EXACT format of
       the output of this method (including indentation, line
       separators, etc.) is specified via examples in the assignment
       handout.
     */
    void processStatusRequest() {
        File dir = new File(filesPath);
        System.out.println("==================");
        System.out.println("Local files:");
        for(File file : dir.listFiles())
            System.out.println("    " + file.getName());
        System.out.println("Neighbors:");
        printNeighbors();
        System.out.println("==================");
    }// processStatusRequest method

    /* execute the Find command, that is, prompt the user for the file
       name, then look it up in the local directory of shared
       files. If it is there, inform the user. Otherwise, send a
       lookup message to all of the peer's neighbors. The EXACT format
       of the output of this method (including the prompt and
       notification), as well as the format of the 'lookup' messages
       are specified via examples in the assignment handout. Do not forget
       to handle the Find-request ID properly.
     */
    void processFindRequest() {
        DatagramSocket socket;
        DatagramPacket packet;
        String fileName;
        String message;
        byte[] buf;
        
        System.out.println("==================");
        System.out.print("Name of file to find: ");
        fileName = scanner.next();
        if(new File(filesPath, fileName).exists())
            System.out.println("this file exists locally in " +
                    filesPath + '/');
        else
        {
            try
            {
                socket = new DatagramSocket();
                for(Neighbor neighbor : neighbors)
                {
                    message = "lookup " + fileName + ' ' + name +
                            '#' + seqNumber + ' ' + ip + ' ' + lPort +
                            ' ' + ip + ' ' + lPort;
                    buf = message.getBytes();
                    packet = new DatagramPacket(buf, buf.length,
                            InetAddress.getByName(neighbor.ip),
                            neighbor.port);
                    socket.send(packet);
                }
                seqNumber++;
            }
            catch(SocketException ex)
            {
                System.err.println(ex);
            }
            catch(UnknownHostException ex)
            {
                System.err.println(ex);
            }
            catch(IOException ex)
            {
                System.err.println(ex);
            }
        }
        System.out.println("==================");
    }// processFindRequest method

    /* execute the Get command, that is, prompt the user for the file
       name and address and port number of the selected peer with the
       needed file. Send a "get" message to that peer and wait for its
       response. If the file is not available at that peer, inform the
       user. Otherwise, extract the file contents from the response,
       output the contents on the user's terminal and save this file
       (under its original name) in the local directory of shared
       files.  The EXACT format of this method's output (including the
       prompt and notification), as well as the format of the "get"
       messages are specified via examples in the assignment
       handout.
     */
    void processGetRequest() {
        DataOutputStream out;
        DataInputStream in;
        String fileName;
        String fileContent;
        String response;
        String sIP;
        int sPort;
        Socket socket;
        int spaceIndex;
        
        System.out.println("==================");
        System.out.print("Name of file to get: ");
        fileName = scanner.next();
        System.out.print("Address of source peer: ");
        sIP = scanner.next();
        System.out.print("Port of source peer: ");
        sPort = Integer.parseInt(scanner.next());
        try
        {
            socket = new Socket(sIP, sPort);
            in = new DataInputStream(socket.getInputStream());
            out = new DataOutputStream(socket.getOutputStream());
            out.writeUTF("get " + fileName);
            fileContent = in.readUTF();
            if(fileContent.equals("fileNotFound"))
                System.out.println("The file '" + fileName +
                        "' is not available at " + sIP + ':' + sPort);
            else
            {
                response = fileContent.substring(0,
                        fileContent.indexOf(' '));
                fileContent = fileContent.substring(
                        fileContent.indexOf(' ') + 1);
                writeFile(fileName, fileContent);
                System.out.println("Contents of the received file b" +
                        "etween dashes:");
                System.out.println("- - - - - - - - - - - - - -");
                System.out.println(fileName + ':');
                System.out.println(fileContent);
                System.out.println("- - - - - - - - - - - - - -");
            }
            System.out.println("==================");
        }
        catch(UnknownHostException ex)
        {
            System.err.println(ex);
        }
        catch(IOException ex)
        {
            System.err.println(ex);
        }
    }// processGetRequest method

    /* create a text file in the local directory of shared files whose
       name and contents are given as arguments.
     */
    void writeFile(String fileName, String contents) {
        try
        {
            PrintWriter output = new PrintWriter(filesPath + '/' +
                    fileName);
            output.print(contents);
            output.flush();
            output.close();
        }
        catch(FileNotFoundException ex)
        {
            System.err.println(ex);
        }
    }// writeFile method

    /* Send to the user's terminal the list of the peer's
       neighbors. The EXACT format of this method's output is specified by
       example in the assignment handout.
     */
    void printNeighbors() { 
        for(Neighbor neighbor : neighbors)
            System.out.println("    " + neighbor.toString());
    }// printNeighbors method

    /* Do NOT modify this class
     */
    class Neighbor {
    String ip;
    int port;

    Neighbor(String ip, int port) {
        this.ip = ip;
        this.port = port;
    }// constructor

    public boolean equals(Object o) {
        if (o == this) { return true;  }
        if (!(o instanceof Neighbor)) { return false;  }        
        Neighbor n = (Neighbor) o;         
        return n.ip.equals(ip) && n.port == port;
    }// equals method

    public String toString() {
        return ip + ":" + port;
    }// toString method
    }// Neighbor class

    class LookupThread extends Thread {
    
    DatagramSocket socket = null;           // UDP server socket
    private volatile boolean stop = false;  // flag used to stop the thread

    /* Stop the lookup thread by closing its server socket. This
       works (in a not-so-pretty way) because this thread's run method is
       constantly listening on that socket.
       Do NOT modify this method.
     */
    public void terminate() {
        stop = true;
        socket.close();
    }// terminate method


    /* This is the implementation of the thread that listens on
       the UDP lookup socket. First (at startup), if the peer has
       exactly one neighbor, send a "join" message to this
       neighbor. Otherwise, skip this step. Second, continuously
       wait for an incoming datagram (i.e., a request), display
       its contents in the GUI's Lookup panel, and process the
       request using the helper method below.
    */
    public void run() {
        DatagramPacket packet;
        String message;
        byte[] buf;
        
        
        try
        {
            socket = new DatagramSocket(lPort);
            if(neighbors.size() == 1)
            {
                message = "join " + ip + ' ' + lPort;
                buf = message.getBytes();
                packet = new DatagramPacket(buf, buf.length,
                        InetAddress.getByName(neighbors.get(0).ip),
                        neighbors.get(0).port);
                socket.send(packet);
            }
                
            buf = new byte[256];
            packet = new DatagramPacket(buf, buf.length);
            while(!stop)
            {
                socket.receive(packet);
                message = new String(packet.getData(), 0,
                        packet.getLength());
                process(message);
            }
        }
        catch(SocketException ex)
        {
        }
        catch(UnknownHostException ex)
        {
            System.err.println(ex);
        }
        catch(IOException ex)
        {
            System.err.println(ex);
        }
    }// run method

    /* This helper method processes the given request, which was
       received by the Lookup socket. Based on the first field of
       the request (i.e., the "join", "leave", "lookup", or "file"
       keyword), perform the appropriate action. All actions are
       quite short, except for the "lookup" request, which has its
       own helper method below.
     */
    void process(String request) {
        StringTokenizer message = new StringTokenizer(request, " ");
        Neighbor neighbor;
        String command;
        String sourceIP;
        int sourcePort;
        String fileName;
        
        GUI.displayLU("Received:   " + request);
        switch(message.nextToken())
        {
            case "join":
                neighbor = new Neighbor(message.nextToken(),
                        Integer.parseInt(message.nextToken()));
                if(!neighbors.contains(neighbor))
                    neighbors.add(neighbor);
                break;
            case "lookup":
                processLookup(message);
                break;
            case "file":
                message.nextToken();
                message.nextToken();
                message.nextToken();
                neighbor = new Neighbor(message.nextToken(),
                        Integer.parseInt(message.nextToken()));
                if(!neighbors.contains(neighbor))
                    neighbors.add(neighbor);
                break;
            case "leave":
                neighbor = new Neighbor(message.nextToken(),
                        Integer.parseInt(message.nextToken()));
                neighbors.remove(neighbor);
        }
    }// process method

    /* This helper method processes a "lookup" request received
       by the Lookup socket. This request is represented by the
       given tokenizer, which contains the whole request line,
       minus the "lookup" keyword (which was removed from the
       beginning of the request) by the caller of this method.
       Here is the algorithm to process such requests:
           If the peer already received this request in the past (see request
       ID), ignore the request. 
           Otherwise, check if the requested file is stored locally (in the 
       peer's directory of shared files):
         + If so, send a "file" message to the source peer of the request 
           and, if necessary, add this source peer to the list 
           of neighbors of this peer.
             + If not, send a "lookup" message to all neighbors of this peer,
               except the peer that sent this request (that is, the "from" peer
           as opposed to the "source" peer of the request).
     */
    void processLookup(StringTokenizer line) {
        String fileName = line.nextToken();
        String lookupRequestID = line.nextToken();
        String fromIP = line.nextToken();
        String fromPort = line.nextToken();
        String sourceIP = line.nextToken();
        String sourcePort = line.nextToken();
        DatagramPacket packet;
        byte[] buf;
        String message;
        
        if(findRequests.contains(lookupRequestID))
        {
            GUI.displayLU("Saw request before:  no forwarding");
            return;
        }
        findRequests.add(lookupRequestID);
        try
        {
            if(new File(filesPath, fileName).exists())
            {
                message = "file " + fileName + " is at " + ip + ' ' +
                        lPort + " (tcp port: " + ftPort + ')';
                buf = message.getBytes();
                packet = new DatagramPacket(buf, buf.length,
                        InetAddress.getByName(sourceIP),
                        Integer.parseInt(sourcePort));
                socket.send(packet);
                Neighbor neighbor = new Neighbor(sourceIP,
                        Integer.parseInt(sourcePort));
                if(!neighbors.contains(neighbor))
                    neighbors.add(neighbor);
                GUI.displayLU("Sent:   " + message);
            }
            else
            {
                GUI.displayLU("   File is NOT available at this pee" +
                        "r");
                for(Neighbor neighbor : neighbors)
                {
                    if(neighbor.equals(new Neighbor(fromIP,
                            Integer.parseInt(fromPort))) ||
                            neighbor.equals(new Neighbor(sourceIP,
                                    Integer.parseInt(sourcePort))))
                        continue;
                    message = "lookup " + fileName + ' ' +
                            lookupRequestID + ' ' + ip + ' ' + lPort +
                            ' ' + sourceIP + ' ' + sourcePort;
                    buf = message.getBytes();
                    packet = new DatagramPacket(buf, buf.length,
                            InetAddress.getByName(neighbor.ip),
                            neighbor.port);
                    socket.send(packet);
                    GUI.displayLU("   Forward request to " +
                            neighbor.ip + ':' + neighbor.port);
                }
            }
        }
        catch(SocketException ex)
        {
            System.err.println(ex);
        }
        catch(UnknownHostException ex)
        {
            System.err.println(ex);
        }
        catch(IOException ex)
        {
            System.err.println(ex);
        }
    }// processLookup method

    }// LookupThread class
    
    class FileTransferThread extends Thread {

    ServerSocket serverSocket = null;   // TCP listening socket
    Socket clientSocket = null;         // TCP socket to a client
    DataInputStream in = null;          // input stream from client
    DataOutputStream out = null;        // output stream to client
    String request, reply;

    /* this is the implementation of the peer's File Transfer
       thread, which first creates a listening socket (or welcome
       socket or server socket) and then continuously waits for
       connections. For each connection it accepts, the newly
       created client socket waits for a single request and processes
       it using the helper method below (and is finally closed).
    */  
    public void run() {
        try
        {
            serverSocket = new ServerSocket(ftPort);
            
            while(true)
            {
                clientSocket = serverSocket.accept();
                openStreams();
                request = in.readUTF();
                GUI.displayFT("Received:   " + request);
                process(request);
                close();
            }
        }
        catch(SocketException ex)
        {
        }
        catch(IOException ex)
        {
            System.err.println(ex);
        }
    }// run method
    
    /* Process the given request received by the TCP client
       socket.  This request must be a "get" message (the only
       command that uses the TCP sockets). If the requested
       file is stored locally, read its contents (as a String)
       using the helper method below and send them to the other side
       in a "fileFound" message. Otherwise, send back a "fileNotFound"
       message.
     */
    void process(String request) { 
        File file;
        if(request.substring(0, request.indexOf(' ')).equals("get"))
        {
            try
            {
                request = request.substring(request.indexOf(' ') + 1);
                file = new File(filesPath, request);
                
                if(file.exists())
                {
                    reply = "fileFound " + new String(readFile(file));
                    GUI.displayFT("    Read file " + filesPath + '/' +
                            request);
                    GUI.displayFT("    Sent back file contents");
                }
                else
                {
                    reply = "fileNotFound";
                    GUI.displayFT("    responded: " + reply);
                }
                out.writeUTF(reply);
            }
            catch(IOException ex)
            {
                System.err.println(ex);
            }
        }
    }// process method

    /* Given a File object for a file that we know is stored at this
       peer, return the contents of the file as a byte array.
    */
    byte[] readFile(File file) {
        try
        {
            BufferedReader reader = new BufferedReader(
                    new FileReader(file));
            StringBuilder string = new StringBuilder();
            String line;
            
            while((line = reader.readLine()) != null)
            {
                string.append(line);
                string.append('\n');
            }
            return string.toString().getBytes();
        }
        catch(FileNotFoundException ex)
        {
            System.err.println(ex);
        }
        catch(IOException ex)
        {
            System.err.println(ex);
        }
        return null;
    }// readFile method

    /* Open the necessary I/O streams and initialize the in and out
       variables; this method does not catch any exceptions.
    */
    void openStreams() throws IOException {
        in = new DataInputStream(clientSocket.getInputStream());
        out = new DataOutputStream(clientSocket.getOutputStream());
    }// openStreams method

    /* close all open I/O streams and the client socket
     */
    void close() {
        try
        {
            if(in != null)
                in.close();
            if(out != null)
                out.close();
            if(clientSocket != null)
                clientSocket.close();
        }
        catch(IOException ex)
        {
            System.err.println(ex);
        }
    }// close method
    
    }// FileTransferThread class

}// Peer class
