/* Server program for the OnlineOrder app

   @author Christian Wendlandt

   @version CS 391 - Spring 2018 - A2
*/

import java.net.*;
import java.io.*;
import java.util.*;

public class OOServer
{
    static ServerSocket serverSocket = null;  //listening socket
    static int portNumber = 55555;      //port on which server listens
    static Socket clientSocket = null;        //socket to a client

    /* Start the server then repeatedly wait for a connection request,
       accept, and start a new thread to handle one online order
    */
    public static void main(String[] args)
    {
        try
        {
            serverSocket = new ServerSocket(portNumber);
            System.out.println("Server started: " + serverSocket);
            while(true)
            {
                clientSocket = serverSocket.accept();
                System.out.println("New Connection established: " +
                        clientSocket);
                new Thread(new OO(clientSocket)).start();
            }
        }
        catch(IOException ex)
        {
            System.err.println("Server I/O error: " + ex);
        }
    }// main method
}// OOServer class

class OO implements Runnable
{
    static final int MAIN = 0;          //M state
    static final int PIZZA_SLICE = 1;   //PS state
    static final int HOT_SUB = 2;       //HS state
    static final int DISPLAY_ORDER = 3; //DO state
    static final Menu mm = new Menu(new String[]
            {"Main Menu:", "Pizza Slices", "Hot Subs",
            "Display order"});//Main Menu
    static final Menu psm = new Menu(new String[]
            {"Choose a Pizza Slice:", "Cheese","Pepperoni", "Sausage",
            "Back to Main Menu", "Display Order" });//Pizza Slice menu
    static final Menu hsm = new Menu(new String[]
            {"Choose a Hot Sub:", "Italian", "Meatballs",
            "Back to Main Menu", "Display Order"});//Hot Sub menu
    static final Menu dom = new Menu(new String[]
            {"What next?", "Proceed to check out",
            "Go Back to Main Menu"});//Display Order menu
    int state;                          //current state
    Order order;                        //current order
    Socket clientSocket = null;         //socket to a client
    DataInputStream in = null;          //input stream from client
    DataOutputStream out = null;        //output stream to client

    /* Init client socket, current state, and order, and open the
       necessary streams
     */
    OO(Socket clientSocket)
    {
        this.clientSocket = clientSocket;
        try
        {
            openStreams(this.clientSocket);
        }
        catch(IOException ex)
        {
            System.err.println("Server I/O error: " + ex);
            close();
        }
        state = MAIN;
        order = new Order();
    }// OO constuctor

    /* each execution of this thread corresponds to one online
       ordering session
     */
    public void run()
    {
        try
        {
            placeOrder();
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage() + " at " +
					clientSocket.toString());
        }
        close();
    }// run method

    /* implement the OO protocol as described by the FSM in the
       handout Note that, before reading the first query
       (i.e., option), the server must display the welcome message
       shown in the trace in the handout, followed by the main menu.
     */
    void placeOrder() throws IOException
    {
        String bars = "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n";
        String invalid = "Invalid option!\n";
        String prefix = "";
        String query;
        int option;
        
        protocolLoop:
        while(true)
        {
            switch(state)
            {
                case MAIN:
                    out.writeUTF(prefix + mm.toString());
                    prefix = bars;
                    query = in.readUTF();
                    if(!query.matches(
							"[1-" + (mm.getNumOptions() - 1) + "]"))
                    {
                        prefix = invalid;
                        continue protocolLoop;
                    }
                    option = Integer.parseInt(query);
                    switch(option)
                    {
                        case 1:
                            state = PIZZA_SLICE;
                            break;
                        case 2:
                            state = HOT_SUB;
                            break;
                        case 3:
                            state = DISPLAY_ORDER;
                            prefix += order.toString() + "\n" + bars;
                    }
                    break;
                case PIZZA_SLICE:
                    out.writeUTF(prefix + psm.toString());
                    prefix = bars;
                    query = in.readUTF();
                    if(!query.matches(
							"[1-" + (psm.getNumOptions() - 1) + "]"))
                    {
                        prefix = invalid;
                        continue protocolLoop;
                    }
                    option = Integer.parseInt(query);
                    switch(option)
                    {
                        case 1:
                        case 2:
                        case 3:
                            order.addItem(psm.getOption(option));
                            break;
                        case 4:
                            state = MAIN;
                            break;
                        case 5:
                            state = DISPLAY_ORDER;
                            prefix += order.toString() + "\n" + bars;
                    }
                    break;
                case HOT_SUB:
                    out.writeUTF(prefix + hsm.toString());
                    prefix = bars;
                    query = in.readUTF();
                    if(!query.matches(
							"[1-" + (hsm.getNumOptions() - 1) + "]"))
                    {
                        prefix = invalid;
                        continue protocolLoop;
                    }
                    option = Integer.parseInt(query);
                    switch(option)
                    {
                        case 1:
                        case 2:
                            order.addItem(hsm.getOption(option));
                            break;
                        case 3:
                            state = MAIN;
                            break;
                        case 4:
                            state = DISPLAY_ORDER;
                            prefix += order.toString() + "\n" + bars;
                    }
                    break;
                case DISPLAY_ORDER:
                    out.writeUTF(prefix + dom.toString());
                    prefix = bars;
                    query = in.readUTF();
                    if(!query.matches(
							"[1-" + (mm.getNumOptions() - 1) + "]"))
                    {
                        prefix = invalid;
                        continue protocolLoop;
                    }
                    option = Integer.parseInt(query);
                    switch(option)
                    {
                        case 1:
                            out.writeUTF("Thank you for your visit!");
                            break protocolLoop;
                        case 2:
                            state = MAIN;
                    }
            }
        }
    }// placeOrder method

    /* open the necessary I/O streams and initialize the in and out
      static variables; this method does not catch any exceptions
    */
    void openStreams(Socket socket) throws IOException
    {
        in = new DataInputStream(clientSocket.getInputStream());
        out = new DataOutputStream(clientSocket.getOutputStream());
    }// openStreams method

    /* close all open I/O streams and sockets
     */
    void close()
    {
        try
        {
            if(in != null)
                in.close();
            if(out != null)
                out.close();
            if(clientSocket != null)
                clientSocket.close();
        }
        catch(IOException ex)
        {
            System.err.println("Error in close(): "
					+ ex.getMessage());
        }
    }// close method
}// OO class