/* Game thread for the Scribble app
   @author Christian Wendlandt
   @version CS 391 - Spring 2018 - A3
*/

import java.util.*;
import java.io.*;
import java.net.*;

class Scribble implements Runnable
{
    static char[] tiles = {'A','A','A','A','A','A','A','A','A',
        'B','B','C','C','D','D','D','D',
        'E','E','E','E','E','E','E','E','E','E','E','E',
        'F','F','G','G','G','H','H','I','I','I','I','I','I','I','I','I',
        'J','K','L','L','L','L','M','M','N','N','N','N','N','N',
        'O','O','O','O','O','O','O','O','P','P','Q','R','R','R','R','R','R',
        'S','S','S','S','T','T','T','T','T','T',
        'U','U','U','U','V','V','W','W','X','Y','Y','Z'};
    static final int WIDTH = 10;      // width of board
    static final int HEIGHT = 10;     // height of board
    static final int MAX_TURNS = 3;   // number of turns in a game
    static String[] dict;             // dictionary of allowed words
    char[][] board;                   // the Scribble board
    State state;                      // current state in the Scribble FSM
    Socket player1, player2;          // player sockets
    DataInputStream in1, in2;         // input streams of player sockets
    DataOutputStream out1, out2;      // output streams of player sockets
    String name1, name2;              // player names
    int turn;                         // the current turn in the game
    char[] rack1, rack2;              // tile rack for both players
    int score1, score2;               // scores for both players
    Random rnd;                       // random generator for the whole game

    /* add your instance/class variables, if any, after this point and before
       the constructor that follows */
    
    static final int RACK_SIZE = 7;
    boolean isFirstWord = true;

    /* initialize a Scribble game:
       + load the dictionary
       + open the sockets' streams
       + create an empty board
       + initialize the two racks with 7 random tiles each
       + initialize other variables, as needed, including rnd with the given
         seed
     */
    Scribble(Socket clientSocket1, Socket clientSocket2, int seed)
    {
        rnd = new Random(seed);
        rack1 = new char[RACK_SIZE];
        for(int i = 0; i < RACK_SIZE; i++)
            rack1[i] = tiles[rnd.nextInt(tiles.length)];
        rack2 = new char[RACK_SIZE];
        for(int i = 0; i < RACK_SIZE; i++)
            rack2[i] = tiles[rnd.nextInt(tiles.length)];
        board = new char[HEIGHT][WIDTH];
        for(int i = 0; i < HEIGHT; i++)
            for(int j = 0; j < WIDTH; j++)
                board[i][j] = ' ';
        if(rnd.nextBoolean())
        {
            player2 = clientSocket1;
            player1 = clientSocket2;
        }
        else
        {
            player1 = clientSocket1;
            player2 = clientSocket2;
        }
        state = State.I1;
        turn = 1;
        score1 = score2 = 0;
        openStreams(player1, player2);
        loadDictionary();
    }// constructor

    /* implement the Scribble FSM given in the handout. The output
       sent to the console by this method is also specified in the handout,
       namely in the provided traces.
     */
    public void run()
    {
        String location = "";
        String direction = "";
        String word;
        String pleaseWait = ", please wait for your opponent...";
                
        while(true)
        {
            try
            {
                switch(state)
                {
                    case I1:
                        out1.writeUTF("N");
                        name1 = in1.readUTF();
                        out1.writeUTF(name1 + pleaseWait);
                        out2.writeUTF("N");
                        state = State.I2;
                        break;
                    case I2:
                        name2 = in2.readUTF();
                        out2.writeUTF(name2 + pleaseWait);
                        out1.writeUTF(getGameState(1));
                        out1.writeUTF("S");
                        state = State.I3;
                        break;
                    case I3:
                        location = in1.readUTF();
                        try
                        {
                            validateStartPosition(location);
                            out1.writeUTF("D");
                            state = State.I4;
                        }
                        catch(BadWordPlacementException ex)
                        {
                            out1.writeUTF(getGameState(1));
                            out1.writeUTF(ex.getMessage());
                            out1.writeUTF("S");
                        }
                        break;
                    case I4:
                        direction = in1.readUTF();
                        try
                        {
                            validateDirection(direction);
                            out1.writeUTF("W");
                            state = State.I5;
                        }
                        catch(BadWordPlacementException ex)
                        {
                            out1.writeUTF(ex.getMessage());
                            out1.writeUTF("D");
                        }
                        break;
                    case I5:
                        word = in1.readUTF();
                        try
                        {
                            updateGame(location, direction, word, 1);
                            out1.writeUTF(getGameState(1));
                        }
                        catch(BadWordPlacementException ex)
                        {
                            out1.writeUTF(getGameState(1));
                            out1.writeUTF(ex.getMessage());
                        }
                        out1.writeUTF(name1 + pleaseWait);
                        out2.writeUTF(getGameState(2));
                        out2.writeUTF("S");
                        state = State.I6;
                        break;
                    case I6:
                        location = in2.readUTF();
                        try
                        {
                            validateStartPosition(location);
                            out2.writeUTF("D");
                            state = State.I7;
                        }
                        catch(BadWordPlacementException ex)
                        {
                            out2.writeUTF(getGameState(2));
                            out2.writeUTF(ex.getMessage());
                            out2.writeUTF("S");
                        }
                        break;
                    case I7:
                        direction = in2.readUTF();
                        try
                        {
                            validateDirection(direction);
                            out2.writeUTF("W");
                            state = State.I8;
                        }
                        catch(BadWordPlacementException ex)
                        {
                            out2.writeUTF(ex.getMessage());
                            out2.writeUTF("D");
                        }
                        break;
                    case I8:
                        word = in2.readUTF();
                        try
                        {
                            updateGame(location, direction, word, 2);
                            if(turn == MAX_TURNS)
                            {
                                out1.writeUTF(getGameState(1));
                                out2.writeUTF(getGameState(2));
                                if(score1 == score2)
                                {
                                    out1.writeUTF("You tied - GAME OVER!");
                                    out2.writeUTF("You tied - GAME OVER!");
                                }else if(score1 > score2)
                                {
                                    out1.writeUTF("You won - GAME OVER!");
                                    out2.writeUTF("You lost - GAME OVER!");
                                }else
                                {
                                    out1.writeUTF("You lost - GAME OVER!");
                                    out2.writeUTF("You won - GAME OVER!");
                                }
                                return;
                            }
                            turn++;
                            out2.writeUTF(getGameState(2));
                        }
                        catch(BadWordPlacementException ex)
                        {
                            if(turn == MAX_TURNS)
                            {
                                out1.writeUTF(getGameState(1));
                                out2.writeUTF(getGameState(2));
                                out2.writeUTF(ex.getMessage());
                                if(score1 == score2)
                                {
                                    out1.writeUTF("You tied - GAME OVER!");
                                    out2.writeUTF("You tied - GAME OVER!");
                                }else if(score1 > score2)
                                {
                                    out1.writeUTF("You won - GAME OVER!");
                                    out2.writeUTF("You lost - GAME OVER!");
                                }else
                                {
                                    out1.writeUTF("You lost - GAME OVER!");
                                    out2.writeUTF("You won - GAME OVER!");
                                }
                                return;
                            }
                            turn++;
                            out2.writeUTF(getGameState(2));
                            out2.writeUTF(ex.getMessage());
                        }
                        out2.writeUTF(name2 + pleaseWait);
                        out1.writeUTF(getGameState(1));
                        out1.writeUTF("S");
                        state = State.I3;
                }
            }
            catch(IOException ex)
            {
                System.err.println(ex);
            }
        }
    }// run method

    /* return the string representation of the current game state from the
       perspective of the given player (i.e., 1 or 2). More precisely, the
       returned string must contain, in order:
       + the state of the board
       + the turn number
       + the scores of both players
       + the rack of the given player
       The format of the returned string is fully specified in the traces
       included in the handout.
     */
    String getGameState(int player)
    {
        StringBuilder gameState = new StringBuilder();
        
        gameState.append(toString());
        gameState.append("Turn: ");
        gameState.append(turn);
        gameState.append("\nScores: ");
        gameState.append(player == 1 ? score1 : score2);
        gameState.append(" (opponent: ");
        gameState.append(player == 2 ? score1 : score2);
        gameState.append(")\nRack: ");
        gameState.append(player == 1 ? rack1 : rack2);
        return gameState.toString();
    }// getGameState method

    /* Initialize dict with the contents of the dict.txt file (stored in the
       same directory as this file).
       Each word must be in all uppercase. Duplicates (if any) must be
       removed, yielding a total of 276,643 distinct words that must be
       sorted in alphabetical order within dict.
     */
     static void loadDictionary()
     {
         BufferedReader reader;
         String line;
         ArrayList<String> list = new ArrayList<>();
         
         try
         {
             reader = new BufferedReader(new FileReader(new File("dict.txt")));
             while((line = reader.readLine()) != null)
                 list.add(line);
         }
         catch(FileNotFoundException ex)
         {
             System.err.println("Can't find dict.txt: " + ex);
         }
         catch(IOException ex)
         {
             System.err.println("I/O error while trying to read dict.txt: "+ex);
         }
         dict = list.toArray(new String[0]);
     }// loadDictionary method

    /* return true if and only if the given word (assumed to be all uppercase)
       is in dict
     */
    static boolean isInDictionary(String word)
    {
        int comparison;
        int mid;
        int left = 0;
        int right = dict.length - 1;
        
        while(right >= left)
        {
            mid = (right + left) / 2;
            comparison = word.compareTo(dict[mid]);
            if(comparison < 0)
                right = mid - 1;
            else if(comparison > 0)
                left = mid + 1;
            else
                return true;
        }
        return false;
    }// isInDictionary method

    /* convert the Scribble board to a string
       The format of this string is fully specified in the traces included
       in the handout. Here is what the empty board must look like:

        |0|1|2|3|4|5|6|7|8|9|
       -+-+-+-+-+-+-+-+-+-+-+
       A| | | | | | | | | | |
       -+-+-+-+-+-+-+-+-+-+-+
       B| | | | | | | | | | |
       -+-+-+-+-+-+-+-+-+-+-+
       C| | | | | | | | | | |
       -+-+-+-+-+-+-+-+-+-+-+
       D| | | | | | | | | | |
       -+-+-+-+-+-+-+-+-+-+-+
       E| | | | | | | | | | |
       -+-+-+-+-+-+-+-+-+-+-+
       F| | | | | | | | | | |
       -+-+-+-+-+-+-+-+-+-+-+
       G| | | | | | | | | | |
       -+-+-+-+-+-+-+-+-+-+-+
       H| | | | | | | | | | |
       -+-+-+-+-+-+-+-+-+-+-+
       I| | | | | | | | | | |
       -+-+-+-+-+-+-+-+-+-+-+
       J| | | | | | | | | | |
       -+-+-+-+-+-+-+-+-+-+-+

       The traces in the handout also show that some of the vertical and
       horizontal bars must be omitted, namely when they appear between
       two letters. Similarly, an interior '+' may NOT be displayed when it
       is surrounded by 4 letters.
     */
    public String toString()
    {
        StringBuilder table = new StringBuilder();
        int ascii = 'A';
        
        table.append(" |0|1|2|3|4|5|6|7|8|9|\n-+-+-+-+-+-+-+-+-+-+-+\n");
        for(int i = 0; i < HEIGHT; i++)
        {
            table.append((char)ascii++);
            for(int j = 0; j < WIDTH; j++)
            {
                if(j == 0)
                    table.append('|');
                else
                {
                    if(board[i][j - 1] == ' ' || board[i][j] == ' ')
                        table.append('|');
                    else
                        table.append(' ');
                }
                table.append(board[i][j]);
            }
            table.append("|\n-+");
            for(int j = 0; j < WIDTH; j++)
            {
                if(i == WIDTH || board[i][j] == ' ' || board[i + 1][j] == ' ')
                    table.append('-');
                else
                    table.append(' ');
                if(i == WIDTH || j == WIDTH || board[i][j] == ' ' ||
                        board[i + 1][j] == ' ' || board[i][j + 1] == ' ' ||
                        board[i + 1][j + 1] == ' ')
                    table.append('+');
                else
                    table.append(' ');
            }
            table.append('\n');
        }
        return table.toString();
    }// toString method

    /* open the I/O streams of the given sockets and assign them to the
     corresponding instance variables of this object
    */
    void openStreams(Socket socket1, Socket socket2)
    {
        try
        {
            in1 = new DataInputStream(socket1.getInputStream());
            out1 = new DataOutputStream(socket1.getOutputStream());
            in2 = new DataInputStream(socket2.getInputStream());
            out2 = new DataOutputStream(socket2.getOutputStream());
        }
        catch(IOException ex)
        {
            System.err.println("Server I/O error: " + ex);
        }
    }// openStreams method

    /* states of the Scribble FSM. You MUST use this data type, e.g., State.I1

     *** do NOT modify this enum type ***
     */
    public enum State{I1, I2, I3, I4, I5, I6, I7, I8}

    /* exception that must be raised when a player puts down an invalid word,
     that is, a word w that meets at least one of the following requirements:
     + at least one of the words formed using w is not in the dictionary
     + w is too long to fit on the board, i.e., it goes off the right
       side of the board when placed in the 'across' direction or it goes off
       the bottom of the board when placed in the 'down' direction
     + one of the letters in w does not match an existing letter already on the
       board at that position
     + one of the letters in w is not on the player's rack and the position of
       that letter on the board is empty (i.e., w is not reusing an existing
       letter on the board)
     + w does not build on an existing word and this is not the first word of
       the game

     You must instantiate this exception class in your solution whenever
     appropriate.

     *** do NOT modify this class ***
    */
    class BadWordPlacementException extends RuntimeException
    {
        BadWordPlacementException(String message)
        {
            super(message);
        }
    }// BadWordPlacementException class

    /* add your instance methods after this point */
    
    /* 
     * Validates that a chosen position follows the position format and is
     * located on the game board, otherwise throwing an exception.
     */
    void validateStartPosition(String location) throws BadWordPlacementException
    {
        if(location.length() != 2 || location.charAt(0) < 'A' ||
                location.charAt(0) > 'A' + HEIGHT - 1 ||
                location.charAt(1) < '0' ||
                location.charAt(1) > '0' + WIDTH - 1)
            throw new BadWordPlacementException("Invalid location!");
    }
    
    /* 
     * Validates that a chosen direction follows the direction format, otherwise
     * throwing an exception.
     */
    void validateDirection(String direction) throws BadWordPlacementException
    {
        if(direction.length() != 1 || direction.charAt(0) != 'D' &&
                direction.charAt(0) != 'A')
            throw new BadWordPlacementException("Invalid direction!");
    }
    
    /*
     * Validates that a word placement follows all placement rules, otherwise
     * throwing an exception. If the placement is valid, the word will be scored
     * and placed onto the board. In order, this checks:
     * -for each letter
     *   -if the letter's position is actually on the board.
     *   -if the correct letter is already in the correct position.
     *   -if the player's rack contains the letter needed for an empty position.
     *   -if an incorrect letter is placed where this word's letter should go.
     * -if the word longwise is in the dictionary.
     * -if all words crosswise are in the dictionary.
     * -if the word correctly contains a letter from another word.
     * -if the word is actually new and not made up entirely of an old word.
     */
    void updateGame(String location, String direction, String word, int player)
            throws BadWordPlacementException
    {
        char[][] newBoard = new char[HEIGHT][WIDTH];
        char[] newRack = new char[RACK_SIZE];
        boolean addsToAWord = false;
        boolean makesANewWord = false;
        int row = location.charAt(0) - 'A';
        int col = location.charAt(1) - '0';
        int charIndex;
        int wordScore = 0;
        String wordRow, wordCol;
        String tooLongErr = word + " is too long to fit on the board.";
        String conflictErr = " in " + word +
                " conflicts with a different letter on the board.";
        String noNewWordErr = word + " does not build on an existing word.";
        String doesntAppendErr = word + " does not build on an existing word.";
        
        for(int i = 0; i < HEIGHT; i++)
            for(int j = 0; j < WIDTH; j++)
                newBoard[i][j] = board[i][j];
        if(player == 1)
            for(int i = 0; i < RACK_SIZE; i++)
                newRack[i] = rack1[i];
        else
            for(int i = 0; i < RACK_SIZE; i++)
                newRack[i] = rack2[i];
        if(direction.charAt(0) == 'A')
            for(int i = 0; i < word.length(); i++)
            {
                if(i + col == WIDTH)
                    throw new BadWordPlacementException(tooLongErr);
                if(newBoard[row][i + col] == ' ')
                {
                    charIndex = getCharIndex(newRack, word.charAt(i));
                    if(charIndex != -1)
                    {
                        newBoard[row][i + col] = newRack[charIndex];
                        newRack[charIndex] = ' ';
                        makesANewWord = true;
                    }
                    else
                        throw new BadWordPlacementException(
                                "You do not have the letter " + word.charAt(i) +
                                        " on your rack!");
                }
                else
                {
                    if(newBoard[row][i + col] == word.charAt(i))
                        addsToAWord = true;
                    else
                        throw new BadWordPlacementException(word.charAt(i) +
                                conflictErr);
                }
            }
        else
            for(int i = 0; i < word.length(); i++)
            {
                if(i + row == HEIGHT)
                    throw new BadWordPlacementException(tooLongErr);
                if(newBoard[i + row][col] == ' ')
                {
                    charIndex = getCharIndex(newRack, word.charAt(i));
                    if(charIndex != -1)
                    {
                        newBoard[i + row][col] = newRack[charIndex];
                        newRack[charIndex] = ' ';
                        makesANewWord = true;
                    }
                    else
                        throw new BadWordPlacementException(
                                "You do not have the letter " + word.charAt(i) +
                                        " on your rack!");
                }
                else
                {
                    if(newBoard[i + row][col] == word.charAt(i))
                        addsToAWord = true;
                    else
                        throw new BadWordPlacementException(word.charAt(i) +
                                conflictErr);
                }
            }
        if(direction.charAt(0) == 'A')
        {
            wordRow = getWordRow(row, col, newBoard);
            if(!isInDictionary(wordRow))
                throw new BadWordPlacementException("The word " + wordRow +
                        " is not in the dictionary.");
            wordScore += wordRow.length();
            while(--col >= 0 && board[row][col] != ' ');
            col++;
            for(int i = col; i < wordRow.length() + col; i++)
            {
                wordCol = getWordCol(row, i, newBoard);
                if(wordCol.length() <= 1 || this.board[row][i] != ' ')
                    continue;
                if(!isInDictionary(wordCol))
                    throw new BadWordPlacementException("The word " + wordCol +
                            " is not in the dictionary.");
                wordScore += wordCol.length();
            }
        }
        else
        {
            wordCol = getWordCol(row, col, newBoard);
            if(!isInDictionary(wordCol))
                throw new BadWordPlacementException("The word " + wordCol +
                        " is not in the dictionary.");
            wordScore += wordCol.length();
            while(--row >= 0 && board[row][col] != ' ');
            row++;
            for(int i = row; i < wordCol.length() + row; i++)
            {
                wordRow = getWordRow(i, col, newBoard);
                if(wordRow.length() <= 1 || this.board[i][col] != ' ')
                    continue;
                if(!isInDictionary(wordRow))
                    throw new BadWordPlacementException("The word " + wordRow +
                            " is not in the dictionary.");
                wordScore += wordRow.length();
            }
        }
        if(!addsToAWord && !isFirstWord)
            throw new BadWordPlacementException(doesntAppendErr);
        if(!makesANewWord)
            throw new BadWordPlacementException(noNewWordErr);
        isFirstWord = false;
        board = newBoard;
        for(int i = 0; i < RACK_SIZE; i++)
            if(newRack[i] == ' ')
                newRack[i] = tiles[rnd.nextInt(tiles.length)];
        if(player == 1)
        {
            score1 += wordScore;
            rack1 = newRack;
        }
        else
        {
            score2 += wordScore;
            rack2 = newRack;
        }
    }
    
    /*
     * Gets the index of a character in a character array.
     */
    int getCharIndex(char[] word, char letter)
    {
        for(int i = 0; i < word.length; i++)
            if(letter == word[i])
                return i;
        return -1;
    }
    
    /*
     * Gathers and returns all letters in a row connected the position of a
     * letter on the board as a string.
     */
    String getWordRow(int row, int col, char[][] board)
    {
        int startCol;
        int endCol;
        StringBuilder word = new StringBuilder();
        
        while(--col >= 0 && board[row][col] != ' ');
        startCol = ++col;
        while(++col < WIDTH && board[row][col] != ' ');
        endCol = --col;
        for(int i = startCol; i <= endCol; i++)
            word.append(board[row][i]);
        return word.toString();
    }
    
    /*
     * Gathers and returns all letters in a column connected the position of a
     * letter on the board as a string.
     */
    String getWordCol(int row, int col, char[][] board)
    {
        int startRow;
        int endRow;
        StringBuilder word = new StringBuilder();
        
        while(--row >= 0 && board[row][col] != ' ');
        startRow = ++row;
        while(++row < HEIGHT && board[row][col] != ' ');
        endRow = --row;
        for(int i = startRow; i <= endRow; i++)
            word.append(board[i][col]);
        return word.toString();
    }
}// Scribble class
