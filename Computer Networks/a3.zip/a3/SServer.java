/* Server program for the Scribble app
   @author Christian Wendlandt
   @version CS 391 - Spring 2018 - A3
*/

import java.net.*;
import java.io.*;

public class SServer
{
    static ServerSocket serverSocket = null;   // listening socket
    static int portNumber = 55555;             // port on which server listens
    static int seed;                       // seed for controlling the
                                               // randomness of the game

    /* Start the server, then repeatedly wait for and accept two connection
       requests and start a new Scribble thread to handle one game between
       the two corresponding players. Before starting the thread, this method
       sends a <welcome + wait prompt> message to both players. Each successive
       thread is passed a seed value, starting with the seed 0 for the first
       thread, the seed 1 for the second thread, etc.
       The output sent to the console by this method is described in the handout.
    */
    public static void main(String[] args)
    {
        Socket clientSocket1 = null;
        Socket clientSocket2 = null;
        DataOutputStream out1 = null;
        DataOutputStream out2 = null;
        String welcome = "Welcome to Scribble!\n";
        String pleaseWait = "Please wait for your opponent...";
        seed = 0;
        
        try
        {
            serverSocket = new ServerSocket(portNumber);
            System.out.println("Server started: " + serverSocket);
            while(true)
            {
                clientSocket1 = serverSocket.accept();
                System.out.println("First player connected: " + clientSocket1);
                out1 = new DataOutputStream(clientSocket1.getOutputStream());
                out1.writeUTF(welcome);
                out1.writeUTF(pleaseWait);
                
                clientSocket2 = serverSocket.accept();
                System.out.println("Second player connected: " + clientSocket2);
                out2 = new DataOutputStream(clientSocket2.getOutputStream());
                out2.writeUTF(welcome);
                out2.writeUTF(pleaseWait);
                
                new Thread(new Scribble(
                        clientSocket1, clientSocket2, seed++)).start();
            }
        }
        catch(IOException ex)
        {
            System.err.println("Server I/O error: " + ex.getMessage());
        }
        finally
        {
            try
            {
                if(out1 != null)
                    out1.close();
                if(out2 != null)
                    out2.close();
                if(clientSocket1 != null)
                    clientSocket1.close();
                if(clientSocket2 != null)
                    clientSocket2.close();
                if(serverSocket != null)
                    serverSocket.close();
            }
            catch(IOException ex)
            {
                System.err.println("Error in close(): " + ex.getMessage());
            }
        }
    }// main method
}// SServer class