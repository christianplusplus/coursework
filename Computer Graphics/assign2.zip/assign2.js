/**
 * Graphical Kaleidoscope
 * CS 371
 * Professor Thomas Naps
 * Author: Christian Wendlandt
 * Version: 2019.2.25
 *
 * This script is for a graphical kaleidoscope that inserts itself onto an html canvas.
 * Vertices are mirrored accross tile lines for each viewport drawn.
 * For "golly-gee-whiz" points, the number of viewports is adjustable via html buttons and
 * each tile (a.k.a viewport) will reflect accordingly. In addition, each animation effect
 * is toggeable, the square in the middle disappears, and the triangle in the corner morphs
 * into a diamond.
 * Bonus features can be accessed with the "More Tiles", "Less Tiles", "Bounce", and
 * "CRAZY Button" elements.
 */

var gl;
var canvas;
var scenes;
var program;
var horzVPTiles;
var vertVPTiles;
var bounce;
var theta, thetaRate, thetaOrient;
var tween, tweenRate, tweenOrient;
var reflect, reflectRate, reflectOrient;

/**
 * Loads specified vertices into the graphics buffer and initiates rendering.
 * Ties together the viewport(s) and event listeners with each of their html elements.
 * render() is called onload and per button click.
 */
window.onload = function init()
{
	canvas = document.getElementById("gl-canvas");
	
	gl = WebGLUtils.setupWebGL(canvas);//More efficient
	//gl = WebGLDebugUtils.makeDebugContext(canvas.getContext("webgl"));//For debugging
	if(!gl){alert("WebGL isn't available");}
	
    scenes = [];
    var numberOfScenes = 2;
    for(var i = 0; i < numberOfScenes; i++)
        scenes.push({"shapes":[],"vertices":[],"vertexCounts":[],"colors":[],"aniCodes":[]});
	
    makeShapes();
	
	gl.clearColor(0,0,0,1);
	program = initShaders(gl, "vertex-shader", "fragment-shader");
	gl.useProgram(program);
	
    loadScenes();

    makeButtons();
	
	gl.uniform1i(gl.getUniformLocation(program, "smooth_flag"), 1);
    resetAnimations();
	render();
};

/**
 * Clears the canvas, creates viewports, and draws on each viewport with mirroring effect.
 */
function render()
{
    updateAnimations();
    
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.uniform1f(gl.getUniformLocation(program, "theta"), theta);
    gl.uniform1f(gl.getUniformLocation(program, "tween"), tween);
    gl.uniform1f(gl.getUniformLocation(program, "reflect"), reflect);
    
    var VPHeight = canvas.height / vertVPTiles;
    var VPWidth = canvas.width / horzVPTiles;
    for(var i = 1; i <= vertVPTiles; i++)
    {
        for(var j = 1; j <= horzVPTiles; j++)
        {
            gl.viewport(canvas.width-VPWidth*j, canvas.height-VPHeight*i, VPWidth, VPHeight);
            gl.uniform1f(gl.getUniformLocation(program, "xScale"), j%2==1?1:-1);
            gl.uniform1f(gl.getUniformLocation(program, "yScale"), i%2==1?1:-1);
	        drawAllShapes();
        }
    }
    requestAnimFrame(render);
}

/**
 * Acts as a helper function by loading in each of the shapes that are drawn later.
 *     These are all hard-coded into this function.
 */
function makeShapes()
{
    //Middle Square
	addShape(gl.TRIANGLE_FAN,
            [vec2(-.5,-.5),vec2(-.5,.5),vec2(.5,.5),vec2(.5,-.5)],
            [vec4(1,0,0,1),vec4(0,1,0,1),vec4(0,0,1,1),vec4(1,0,1,1)],
            0,
            [0,1,1]
    );
    addShape(gl.TRIANGLE_FAN,
            [vec2(0,0),vec2(-1,1),vec2(0,0),vec2(1,-1)],
            [vec4(0,0,0,1),vec4(0,0,0,1),vec4(0,0,0,1),vec4(0,0,0,1)],
            1,
            [0,1,1]
    );

    //Corner Triangle
    addShape(gl.TRIANGLE_STRIP,
            [vec2(.5,.5),vec2(.5,1),vec2(1,.5)],
            [vec4(1,1,0,1),vec4(0,1,1,1),vec4(1,0,1,1)],
            -1,
            [0,1,1]
    );
	addShape(gl.TRIANGLE_STRIP,
            [vec2(.5,.5),vec2(.5,1),vec2(1,.5)],
            [vec4(1,1,0,1),vec4(0,1,1,1),vec4(1,0,1,1)],
            0,
            [0,1,1]
    );
    addShape(gl.TRIANGLE_STRIP,
            [vec2(1,1),vec2(.5,1),vec2(1,.5)],
            [vec4(1,0,0,1),vec4(0,1,1,1),vec4(1,0,1,1)],
            1,
            [0,1,1]
    );
    addShape(gl.TRIANGLE_STRIP,
            [vec2(.5,.5),vec2(.5,1),vec2(1,.5)],
            [vec4(1,1,0,1),vec4(0,1,1,1),vec4(1,0,1,1)],
            0,
            [0,1,1]
    );
    addShape(gl.TRIANGLE_STRIP,
            [vec2(.25,.25),vec2(.5,.5),vec2(1,.5)],
            [vec4(1,1,0,1),vec4(1,1,0,1),vec4(1,0,1,1)],
            1,
            [0,1,1]
    );
    addShape(gl.TRIANGLE_STRIP,
            [vec2(.5,.5),vec2(.5,1),vec2(1,.5)],
            [vec4(1,1,0,1),vec4(0,1,1,1),vec4(1,0,1,1)],
            0,
            [0,1,1]
    );
    addShape(gl.TRIANGLE_STRIP,
            [vec2(.25,.25),vec2(.5,1),vec2(.5,.5)],
            [vec4(1,1,0,1),vec4(0,1,1,1),vec4(1,1,0,1)],
            1,
            [0,1,1]
    );
    
    //The Fat Semi-Circle
    var fidelity = 50;
    addShape(gl.TRIANGLE_STRIP,
            makeFatSemiCircle(fidelity),
            oscillateColors(fidelity,vec4(1,1,0,1),vec4(1,.4,0,1)),
            0,
            [1,1,1]
    );
    addShape(gl.TRIANGLE_STRIP,
            makeCircleWithCenter(fidelity),
            oscillateColors(fidelity,vec4(.5,.5,1,1),vec4(0,0,1,1)),
            1,
            [1,1,1]
    );

    //The Diagonal Line
    addShape(gl.LINE_STRIP,
            [vec2(-1,-1),vec2(1,1)],
            [vec4(0.5,0.5,1,1),vec4(1,0.5,0.5,1)],
            -1,
            [0,1,1]
    );
}

/**
 * Shapes and vertices are held and maintained in lists before being drawn.
 * This function puts that data where it needs to go while also bunching up the needed
 * inputs into one call.
 *
 * shape : The gl primitive for the shape.
 * vertexList : The array of vertices for the shape.
 * colorList : The array of color vectors that are applied to each vertex.
 * scene : the scene number that the shape belongs to. used for animation.
 *     use -1 for use in all scenes.
 * aniCode : This is an array of 0's and 1's that determines which animations to apply to a shape.
 *    In order, they are [twist,tween,reflect].
 */
function addShape(shape, vertexList, colorList, scene, aniCode)
{
    var i, size;
    if(scene >= 0)//add to only one scene
    {
        i = scene;
        size = i + 1;
    }
    else//add to all of the scenes
    {
        i = 0;
        size = scenes.length;
    }
    for(; i < size; i++)
    {
        scenes[i].shapes.push(shape);
        vertexList.forEach(function(vertex){scenes[i].vertices.push(vertex);});
        scenes[i].vertexCounts.push(vertexList.length);
        colorList.forEach(function(color){scenes[i].colors.push(color);});
        scenes[i].aniCodes.push(aniCode);
    }
}

/**
 * Binds buffers and loads vertex and color data for each scene.
 *    **Uses 2 buffers per scene, so expect this to break in later assignments.**
 */
function loadScenes()
{
    for(var i = 0; i < scenes.length; i++)    
    {
        gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
	    gl.bufferData(gl.ARRAY_BUFFER, flatten(scenes[i].vertices), gl.STATIC_DRAW);
	    var position = gl.getAttribLocation(program, "position"+i);
	    gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
	    gl.enableVertexAttribArray(position);

        gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
        gl.bufferData(gl.ARRAY_BUFFER, flatten(scenes[i].colors), gl.STATIC_DRAW);
	    var color = gl.getAttribLocation(program, "color"+i);
        gl.vertexAttribPointer(color, 4, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(color);
    }
}

/**
 * Takes the list gl primitives and vertex data and draws all stored shapes.
 */
function drawAllShapes()
{   
    for(shapeIndex = vertexIndex = 0;
        shapeIndex < scenes[0].shapes.length;
        vertexIndex += scenes[0].vertexCounts[shapeIndex++]
    )
    {
        gl.uniform1i(gl.getUniformLocation(program, "twistFlag"), scenes[0].aniCodes[shapeIndex][0]);
        gl.uniform1i(gl.getUniformLocation(program, "tweenFlag"), scenes[0].aniCodes[shapeIndex][1]);
        gl.uniform1i(gl.getUniformLocation(program, "reflectFlag"), scenes[0].aniCodes[shapeIndex][2]);
        gl.drawArrays(scenes[0].shapes[shapeIndex],vertexIndex,scenes[0].vertexCounts[shapeIndex]);
    }
}

/**
 * Produces vertices for a thick semi-circle going from (0,-1) to (-1,0).
 * 
 * vertexCount : The number of total vertices to be used in drawing the semi-circle.
 *     Increasing vertexCount increases graphical fidelity.
 *     Works best with an even numbers of vertices and you should have 4 at a minimum.
 *
 * returns curve : An array containing vec2 coordinates. Works with the Triangle Strip primitive.
 */
function makeFatSemiCircle(vertexCount)
{
    var radius;
    var xValue;
    var yValue;
    var step;
    var maxSteps = Math.floor(vertexCount/2)-1;
    var fatness = .2;
    var curve = [];
    for(var i = 0; i < vertexCount; i++)
    {
        if(i % 2 == 0)
            radius = 1 + fatness;
        else
            radius = 1 - fatness;
        step = Math.floor(i / 2);
        xValue = radius*Math.cos(step*Math.PI/2/maxSteps)-1;
        yValue = radius*Math.sin(step*Math.PI/2/maxSteps)-1;
        curve.push(vec2(xValue, yValue));
    }
    return curve;
}

/**
 * Produces vertices for a circle centered at (0,0). For each vertex on the perimeter,
 *     there is a vertex in the center of the circle.
 *     This is useful for animation.
 * 
 * vertexCount : The number of total vertices to be used in drawing the circle.
 *     Increasing vertexCount increases graphical fidelity.
 *     Works best with an even numbers of vertices and you should have 6 at a minimum.
 *
 * returns curve : An array containing vec2 coordinates. Works with the Triangle Strip primitive.
 */
function makeCircleWithCenter(vertexCount)
{
    var xValue;
    var yValue;
    var radius = .5;
    var step;
    var maxSteps = Math.floor(vertexCount/2)-1;
    var curve = [];
    for(var i = 0; i < vertexCount; i++)
    {
        if(i % 2 == 0)
        {
            step = Math.floor(i / 2);
            xValue = radius*Math.cos(-step*Math.PI*2/maxSteps+Math.PI*1.25);
            yValue = radius*Math.sin(-step*Math.PI*2/maxSteps+Math.PI*1.25);
            
        }
        else
            xValue = yValue = 0;
        curve.push(vec2(xValue, yValue));
    }
    return curve;
}

/**
 * Produces an array of oscillating colors vectors.
 *
 * vertexCount : The number of vectors to produce.
 *     Note that for an odd number of vectors, color1 gets one more vector.
 * color1 : The vec4 description of the first color.
 * color2 : The vec4 description of the second color.
 *
 * returns vertexColorMap : The array oscillating color vectors.
 */
function oscillateColors(vertexCount, color1, color2)
{
    var vertexColorMap = [];
    for(var i = 0; i < vertexCount; i++)
    {   
        if(i % 2 == 0)
            vertexColorMap.push(color1);
        else
            vertexColorMap.push(color2);
    }
    return vertexColorMap;
}

/**
 * Acts as a helper function that implements each of the events linked to the html buttons.
 *     These are all hard-coded into this function.
 */
function makeButtons()
{
    document.getElementById("moreTiles").onclick = function()
    {
        horzVPTiles++;
        vertVPTiles++;
    };
    document.getElementById("lessTiles").onclick = function()
    {
        if(horzVPTiles > 1)
        {
            horzVPTiles--;
            vertVPTiles--;
        }
    };
    document.getElementById("twist").onclick = function()
    {
        if(thetaRate == 0)
        {
            thetaRate = 0.03;
            document.getElementById("twistLabel").innerHTML = ":ON";
        }
        else
        {
            thetaRate = 0;
            document.getElementById("twistLabel").innerHTML = ":OFF";
        }
    };
    document.getElementById("tween").onclick = function()
    {
        if(tweenRate == 0)
        {
            tweenRate = 0.01;
            document.getElementById("tweenLabel").innerHTML = ":ON";
        }
        else
        {
            tweenRate = 0;
            document.getElementById("tweenLabel").innerHTML = ":OFF";
        }
    };
    document.getElementById("reflect").onclick = function()
    {
        if(reflectRate == 0)
        {
            reflectRate = 0.01;
            document.getElementById("reflectLabel").innerHTML = ":ON";
        }
        else
        {
            reflectRate = 0;
            document.getElementById("reflectLabel").innerHTML = ":OFF";
        }
    };
    document.getElementById("reset").onclick = function()
    {
        resetAnimations();
    };
    document.getElementById("crazy").onclick = function()
    {
        thetaRate = tweenRate = reflectRate = .03;
        thetaOrient = tweenOrient = relfectOrient = 1;
        horzVPTiles = vertVPTiles = 6;
        bounce = true;
        document.getElementById("twistLabel").innerHTML = ":ON";
        document.getElementById("tweenLabel").innerHTML = ":ON";
        document.getElementById("reflectLabel").innerHTML = ":ON";
        document.getElementById("bounceLabel").innerHTML = ":ON";
    };
    document.getElementById("bounce").onclick = function()
    {
        if(bounce)
        {
            bounce = false;
            document.getElementById("bounceLabel").innerHTML = ":OFF";
        }
        else
        {
            bounce = true;
            document.getElementById("bounceLabel").innerHTML = ":ON";
        }
    };
}

/**
 * Resets all of the javascript variables that control
 *     tweening, twisting, reflecting, and mirroring the viewport.
 */
function resetAnimations()
{
    theta = thetaRate = tween = tweenRate = reflect = reflectRate = 0;
    thetaOrient = tweenOrient = reflectOrient = 1;
    horzVPTiles = vertVPTiles = 2;
    bounce = false;
    document.getElementById("twistLabel").innerHTML = ":OFF";
    document.getElementById("tweenLabel").innerHTML = ":OFF";
    document.getElementById("reflectLabel").innerHTML = ":OFF";
    document.getElementById("bounceLabel").innerHTML = ":OFF";
}

/**
 * Updates the theta, tween, and reflect variables between renders.
 */
function updateAnimations()
{
    theta += thetaRate * thetaOrient;
    tween += tweenRate * tweenOrient;
    reflect += reflectRate * reflectOrient;

    if(thetaRate>0)
    {
        if(theta>6)
        {
            theta = 6
            thetaOrient = -1;
            if(!bounce)
            {
                thetaRate = 0;
                document.getElementById("twistLabel").innerHTML = ":OFF";
            }
        }
        if(theta<0)
        {
            theta = 0
            thetaOrient = 1;
            if(!bounce)
            {
                thetaRate = 0;
                document.getElementById("twistLabel").innerHTML = ":OFF";
            }
        }
    }
    if(tweenRate>0)
    {
        if(tween>1)
        {
            tween = 1;
            tweenOrient = -1;
            if(!bounce)
            {
                tweenRate = 0;
                document.getElementById("tweenLabel").innerHTML = ":OFF";
            }
        }
        if(tween<0)
        {
            tween = 0
            tweenOrient = 1;
            if(!bounce)
            {
                tweenRate = 0;
                document.getElementById("tweenLabel").innerHTML = ":OFF";
            }
        }
    }
    if(reflectRate>0)
    {
        if(reflect>1)
        {
            reflect = 1;
            reflectOrient = -1;
            if(!bounce)
            {
                reflectRate = 0;
                document.getElementById("reflectLabel").innerHTML = ":OFF";
            }
        }
        if(reflect<0)
        {
            reflect = 0;
            reflectOrient = 1;
            if(!bounce)
            {
                reflectRate = 0;
                document.getElementById("reflectLabel").innerHTML = ":OFF";
            }
        }
    }
}
