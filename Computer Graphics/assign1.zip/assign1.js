/**
 * Graphical Kaleidoscope
 * CS 371
 * Professor Thomas Naps
 * Author: Christian Wendlandt
 * Version: 2019.2.14
 *
 * This script is for a graphical kaleidoscope that inserts itself onto an html canvas.
 * Vertices are mirrored accross tile lines for each viewport drawn.
 * For "golly-gee-whiz" points, the number of viewports is adjustable via html buttons and
 * each tile (a.k.a viewport) will reflect accordingly.
 * Certain parametric equations found online were utilized to draw the two fancy curves. Their
 * documentation and sources can be found with their respective functions.
 */

var gl;
var canvas;
var shapes;
var vertexCounts;
var vertices;
var colors;
var program;
var horzVPTiles;
var vertVPTiles;

/**
 * Loads specified vertices into the graphics buffer and initiates rendering.
 * Ties together the viewport(s) and event listeners with each of their respective html elements.
 * render() is called onload and per button click.
 */
window.onload = function init()
{
	canvas = document.getElementById("gl-canvas");
	
	gl = WebGLUtils.setupWebGL(canvas);//More efficient
	//gl = WebGLDebugUtils.makeDebugContext(canvas.getContext("webgl"));//For debugging
	if(!gl){alert("WebGL isn't available");}
	
	shapes = [];
	vertexCounts = [];
	vertices = [];
    colors = [];
    horzVPTiles = 2;
    vertVPTiles = 2;
	
	//define geometry here
    //Middle Square
	addShape(gl.TRIANGLE_FAN,
            [vec2(-.5,-.5),vec2(-.5,.5),vec2(.5,.5),vec2(.5,-.5)],
            [vec4(1,0,0,1),vec4(0,1,0,1),vec4(0,0,1,1),vec4(1,0,1,1)]
    );
    //Corner Triangle
	addShape(gl.TRIANGLE_STRIP,
            [vec2(.5,.5),vec2(.5,1),vec2(1,.5)],
            [vec4(1,1,0,1),vec4(0,1,1,1),vec4(1,0,1,1)]
    );
    //The Fat Semi-Circle
    addShape(gl.TRIANGLE_STRIP,
            makeFatSemiCircle(20),
            oscillateColors(20,vec4(1,1,0,1),vec4(1,.4,0,1))
    );
    //The Pretty Greenish Parametric Curve 
    addShape(gl.LINE_STRIP,
            prettyParametricCurve(300),
            oscillateColors(300,vec4(1,0,1,1),vec4(0,1,0,1))
    );
    //The Redish-Pink Parametric Rose Curve
    addShape(gl.LINE_STRIP,
            rose(300),
            oscillateColors(300,vec4(1,0.5,0.5,1),vec4(1,.8,.8,1))
    );
    //The Diagonal Line
    addShape(gl.LINE_STRIP,
            [vec2(-1,-1),vec2(1,1)],
            [vec4(0.5,0.5,1,1),vec4(1,0.5,0.5,1)]
    );
	
	gl.clearColor(0,0,0,1);
	
	program = initShaders(gl, "vertex-shader", "fragment-shader");
	gl.useProgram(program);
	
	var bufferId = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
	gl.bufferData(gl.ARRAY_BUFFER, flatten(vertices), gl.STATIC_DRAW);
	
	var vPosition = gl.getAttribLocation(program, "vPosition");
	gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
	gl.enableVertexAttribArray(vPosition);
	
	var cBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, cBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(colors), gl.STATIC_DRAW);
	
	var vColor = gl.getAttribLocation(program, "vColor");
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vColor);

    document.getElementById("moreHorzTiles").onclick = function(){horzVPTiles++;render();};
    document.getElementById("moreVertTiles").onclick = function(){vertVPTiles++;render();};
    document.getElementById("lessHorzTiles").onclick = function(){if(horzVPTiles>1)horzVPTiles--;render();};
    document.getElementById("lessVertTiles").onclick = function(){if(vertVPTiles>1)vertVPTiles--;render();};
	
	render();
};

/**
 * Clears the canvas, creates viewports, and draws on each viewport with correct mirroring for each one.
 */
function render()
{
	gl.clear(gl.COLOR_BUFFER_BIT);
	gl.uniform1i(gl.getUniformLocation(program, "smooth_flag"), 1);
	
    var VPHeight = canvas.height / vertVPTiles;
    var VPWidth = canvas.width / horzVPTiles;
    for(i = 0; i < vertVPTiles; i++)
    {
        for(j = 0; j < horzVPTiles; j++)
        {
            gl.viewport(VPWidth * j, VPHeight * i, VPWidth, VPHeight);
            gl.uniform1f(gl.getUniformLocation(program, "xMagnitude"), 1-2*(j%2));
            gl.uniform1f(gl.getUniformLocation(program, "yMagnitude"), 1-2*(i%2));
	        drawAllShapes();
        }
    }
}

/**
 * Shapes and vertices are held and maintained in lists before being drawn.
 * This function puts that data where it needs to go while also bunching up the needed data
 * into one call.
 *
 * shape : The gl primitive for the shape.
 * vertexList : The array of vertices for the shape.
 * colorList : The array of color vectors that are applied to each vertex.
 */
function addShape(shape, vertexList, colorList)
{
	vertexCounts.push(vertexList.length);
	vertexList.forEach(function(vertex){vertices.push(vertex);});
    colorList.forEach(function(color){colors.push(color);});
	shapes.push(shape);
}

/**
 * Takes the list gl primitives and vertex data and draws all stored shapes.
 */
function drawAllShapes()
{
	var counters = [0,0];//keeps track of the number of vertices in each shape and where each shape begins
	shapes.forEach(function(){drawShape(counters);});//using a list to pass by reference.
    //There's probably a better way to do this in javascript
}

/**
 * Draws a particular shape given the index of the gl primitive and an index pointing to a count of its vertices.
 *
 * counters : A two element array.
 * counters[0] : The index for the gl primitive and for the number of vertices per shape stored in vertexCounts
 * counters[1] : The the starting index for each set of vertices
 */
function drawShape(counters)
{
	gl.drawArrays(shapes[counters[0]], counters[1], vertexCounts[counters[0]]);
	counters[1] += vertexCounts[counters[0]];
	counters[0]++;
}

/**
 * Produces vertices for a thick semi-circle going from (0,-1) to (-1,0).
 * 
 * vertexCount : The number of total vertices to be used in drawing the semi-circle.
 *         Increasing vertexCount increases graphical fidelity.
 *         Works best with an even numbers of vertices and you should have 4 at a minimum.
 *
 * returns curve : An array containing vec2 coordinates. Works with the Triangle Strip primitive.
 */
function makeFatSemiCircle(vertexCount)
{
    var radius;
    var xValue;
    var yValue;
    var step;
    var maxSteps = Math.floor(vertexCount/2)-1;
    var fatness = .2;
    var curve = [];
    for(i = 0; i < vertexCount; i++)
    {
        if(i % 2 == 0)
            radius = 1 + fatness;
        else
            radius = 1 - fatness;
        step = Math.floor(i / 2);
        xValue = radius*Math.cos(step*Math.PI/2/maxSteps)-1;
        yValue = radius*Math.sin(step*Math.PI/2/maxSteps)-1;
        curve.push(vec2(xValue, yValue));
    }
    return curve;
}

/**
 * Produces an array of oscillating colors vectors.
 *
 * vertexCount : The number of vectors to produce.
 *        Note that for an odd number of vertices, color1 gets one more vector.
 * color1 : The vec4 description of the first color.
 * color2 : The vec4 description of the second color.
 *
 * returns vertexColorMap : The array oscillating color vectors.
 */
function oscillateColors(vertexCount, color1, color2)
{
    var vertexColorMap = [];
    for(i = 0; i < vertexCount; i++)
    {   
        if(i % 2 == 0)
            vertexColorMap.push(color1);
        else
            vertexColorMap.push(color2);
    }
    return vertexColorMap;
}

/**
 * Produces an array of vertices for a parametric rose curve.
 *
 * vertexCount : The number of total vertices to be used in drawing the curve.
 *         Increasing vertexCount increases graphical fidelity.
 *
 * returns curve : The array of curve vertices.
 *
 * source : https://en.wikipedia.org/wiki/Rose_(mathematics)
 */
function rose(vertexCount)
{
    var xValue;
    var yValue;
    var curve = [];
    for(i = 0; i <= 20; i += 20/(vertexCount-1))
    {
        xValue = (Math.cos(i*2/3)*Math.cos(i))/2.5-.5;
        yValue = (Math.cos(i*2/3)*Math.sin(i))/2.5+.5;
        curve.push(vec2(xValue, yValue));
    }
    return curve;
}

/**
 * Produces an array of vertices for a fancy parametric curve.
 *
 * vertexCount : The number of total vertices to be used in drawing the curve.
 *         Increasing vertexCount increases graphical fidelity.
 *
 * returns curve : The array of curve vertices.
 *
 * source : http://www.sineofthetimes.org/the-art-of-parametric-equations-2/
 */
function prettyParametricCurve(vertexCount)
{
    var xValue;
    var yValue;
    var curve = [];
    for(i = 0; i <= 7; i += 7/(vertexCount-1))
    {
        xValue = (Math.cos(i)+Math.cos(6*i)/2+Math.sin(14*i)/3)/4+.5;
        yValue = (Math.sin(i)+Math.sin(6*i)/2+Math.cos(14*i)/3)/4-.5;
        curve.push(vec2(xValue, yValue));
    }
    return curve;
}
