package Compiler;

/**
 * @author Christian Wendlandt
 * @version 2018.4.18
 */
public class Method
{
    private String type;
    private String name;
    private String parentClass;
    private Closure envir;
    
    public Method(String type, String name, String parentClass, Closure envir)
    {
        this.type = type;
        this.name = name;
        this.parentClass = parentClass;
        this.envir = envir;
    }
    
    public String getType()
    {
        return type;
    }
    
    public Closure getEnvir()
    {
        return envir;
    }
    
    public String getLabel()
    {
        return parentClass + '_' + name;
    }
}
