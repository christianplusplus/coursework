package Compiler;

import Compiler.lexer.*;
import Compiler.node.*;
import Compiler.parser.*;
import java.io.*;
import java.util.HashMap;

public class Main{
    public static void main(String[] arguments)
    {
        HashMap<String, Variable> symbolTable;
        HashMap<String, Method> methodTable;
        Closure environment;
        SymbolTable visiter;
        PrintTree codeWriter;
        
        try
        {
            Lexer lexer = new Lexer(new PushbackReader(
                    new InputStreamReader(System.in), 1024));
            Parser parser = new Parser(lexer);
            Start ast = parser.parse();
            visiter = new SymbolTable();
            ast.apply(visiter);
            symbolTable = visiter.getSymbolTable();
            methodTable = visiter.getMethodTable();
            environment = visiter.getEnvironment();
            codeWriter = new PrintTree(symbolTable, methodTable, environment);
            ast.apply(codeWriter);
            if(ErrorLog.isEmpty())
                codeWriter.printAssembly(arguments[0]);
            else
                ErrorLog.printLog();
        }
        catch(Exception ex)
        {
            System.out.println("NOT VALID: " + ex);
        }
    }
}