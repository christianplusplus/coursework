package Starter;
import java.util.HashMap;
/*
	Add methods to handle the traversal of other nodes in 
	the syntax tree. Some methods will need to be updated. 
	For instance, the interpret method for a Stmt assumes 
	that all statements are print statements. This is 
	obviously not the case and needs to be handled.
*/

public class Interpreter
{
    HashMap<String, Integer> variables;
    
    public Interpreter()
    {
        variables = new HashMap<>();
    }
    
    public int interpret(Stmts stmts) 
    {
        if(stmts instanceof SepStmtList)
            return interpret((SepStmtList)stmts);
        if(stmts instanceof LastStmtList)
            return interpret((LastStmtList)stmts);
        return 1;
    }
    public int interpret(SepStmtList stmts)
    {
        if(interpret(stmts.stmt) == 1)
            return 1;
        return interpret(stmts.stmts);
    }
    public int interpret(LastStmtList stmt)
    {
        return interpret(stmt.stmt);
    }
    
    public int interpret(Stmt stmt)
    {
        if(stmt instanceof AssignStmt)
            return interpret((AssignStmt)stmt);
        if(stmt instanceof PrintStmt)
            return interpret((PrintStmt)stmt);
        return 1;
    }
    public int interpret(AssignStmt stmt)
    {
        variables.put(stmt.id, interpret(stmt.expression));
        return 0;
    }
    public int interpret(PrintStmt stmt)
    {
        ExpList expList = stmt.expList;
        System.out.println(interpret(expList));
        return 0;
    }

    public int interpret(Expression exp)
    {
        if(exp instanceof IdExp)
            return interpret((IdExp)exp);
        if(exp instanceof NumExp)
            return interpret((NumExp)exp);
        if(exp instanceof BinOpExp)
            return interpret((BinOpExp)exp);
        if(exp instanceof UnOpExp)
            return interpret((UnOpExp)exp);
        return 1;
    }
    public int interpret(IdExp exp)
    {
        return variables.get(exp.id);
    }
    public int interpret(NumExp exp)
    {
        return exp.num;
    }
    public int interpret(BinOpExp exp)
    {
        BinOp binOp = exp.binOp;
        int value1 = interpret(exp.expression1);
        int value2 = interpret(exp.expression2);
        
        if(binOp instanceof BinOpAdd)
            return value1 + value2;
        if(binOp instanceof BinOpSub)
            return value1 - value2;
        if(binOp instanceof BinOpMult)
            return value1 * value2;
        if(binOp instanceof BinOpDiv)
            return value1 / value2;
        if(binOp instanceof BinOpMod)
            return value1 % value2;
        return 0;
    }
    public int interpret(UnOpExp exp)
    {
        UnaryOp unaryOp = exp.unaryOp;
        int value = interpret(exp.expression);
        
        if(unaryOp instanceof UnaryOpLShift)
            return value << 1;
        if(unaryOp instanceof UnaryOpRShift)
            return value >> 1;
        return 1;
    }

    public String interpret(ExpList list) 
    {
        if(list instanceof SepExpList)
            return interpret((SepExpList)list);
        if(list instanceof LastExpList)
            return interpret((LastExpList)list);
        return "NaN";
    }
    public String interpret(SepExpList list)
    {
        return interpret(list.expression) + "," + interpret(list.expList);
    }
    public String interpret(LastExpList list)
    {
        return Integer.toString(interpret(list.expression));
    }
}