package Project2;

import Project2.lexer.*;
import Project2.node.*;
import java.io.*;

public class Main{

    public static void main(String[] args){
        try{
            // Create a lexer instance.
            Lexer l = new Lexer(new PushbackReader(
                    new InputStreamReader(
                    new FileInputStream(
                    new File(args[0])))));
            PrintWriter output = new PrintWriter(new File(args[1]));

            Token t = l.next();
            while (!t.getText().equals("")){
                if(!t.getClass().getSimpleName().equals("TWhitespace"))
                    output.write("<"+t.getClass().getSimpleName()+">");
                t = l.next();
            }
            output.write((char)13);
            output.write((char)10);
            output.flush();
            output.close();
        }
        catch(Exception e){ System.out.println(e.getMessage()); }
    }
}
