/**
 * Creates an abstract syntax tree out of a stream of tokens.
 *
 * @author Christian Wendlandt
 * @version 2018.3.5
 */

import java.util.HashMap;

public class Parser
{
    private StreamReader reader;
    private String token;
    private String tokenName;
    private String tokenValue;
    
    Parser(String stream)
    {
        reader = new StreamReader(stream);
        token = reader.next();
        tokenName = token.substring(0, token.indexOf(","));
        tokenValue = token.substring(token.indexOf(",") + 1);
    }
    
    private void match(String token) throws ParseException
    {
        if(token.equals(tokenName))
        {
            this.token = reader.next();
            tokenName = token.substring(0, token.indexOf(","));
            tokenValue = token.substring(token.indexOf(",") + 1);
        }
        else
            throw new ParseException("Error. Expecting " + tokenName + ".");
    }
    
    private void Ss() throws ParseException
    {
        switch(tokenName)
        {
            case "TId": S(); Z(); break;
            case "TEcho": S(); Z(); break;
            default: throw new ParseException("Error. Not a Statement list.");
        }
    }
    
    private void Z() throws ParseException
    {
        switch(tokenName)
        {
            case "TSemicolon": match("TSemicolon"); S(); Z(); break;
            case "EOF": break;
            default: throw new ParseException("Error. Not a Statement list.");
        }
    }
    
    private void S() throws ParseException
    {
        switch(tokenName)
        {
            case "TId": match("TId"); match("TAssign"); E(); break;
            case "TEcho": match("TEcho"); match("Lparen"); El(); match("Rparen"); break;
            default: throw new ParseException("Error. Not a Statement.");
        }
    }
    
    private void E() throws ParseException
    {
        switch(tokenName)
        {
            case "TId": T(); Y(); break;
            case "TNumber": T(); Y(); break;
            default: throw new ParseException("Error. Not an Expression.");
        }
    }
    
    private void Y() throws ParseException
    {
        switch(tokenName)
        {
            case "TSemicolon": break;
            case "TPlus": match("TPlus"); T(); Y(); break;
            case "TMinus": match("TMinus"); T(); Y(); break;
            case "EOF": break;
            default: throw new ParseException("Error. Not an Expression.");
        }
    }
    
    private void T() throws ParseException
    {
        switch(tokenName)
        {
            case "TId": F(); W(); break;
            case "TNumber": F(); W(); break;
            default: throw new ParseException("Error. Not an Expression.");
        }
    }
    
    private void W() throws ParseException
    {
        switch(tokenName)
        {
            case "TSemicolon": break;
            case "TPlus": break;
            case "TMinus": break;
            case "TTimes": match("TTimes"); F(); W(); break;
            case "TDiv": match("TDiv"); F(); W(); break;
            case "TMod": match("TMod"); F(); W(); break;
            case "EOF": break;
            default: throw new ParseException("Error. Not an Expression.");
        }
    }
    
    private void F() throws ParseException
    {
        switch(tokenName)
        {
            case "TId": N(); V(); break;
            case "TNumber": N(); V(); break;
            default: throw new ParseException("Error. Not an Expression.");
        }
    }
    
    private void V() throws ParseException
    {
        switch(tokenName)
        {
            case "TSemicolon": break;
            case "TPlus": break;
            case "TMinus": break;
            case "TTimes": break;
            case "TDiv": break;
            case "TMod": break;
            case "TLshift": match("TLshift"); V(); break;
            case "TRshift": match("TRshift"); V(); break;
            case "EOF": break;
            default: throw new ParseException("Error. Not an Expression.");
        }
    }
    
    private void N() throws ParseException
    {
        switch(tokenName)
        {
            case "TId": match("TId"); break;
            case "TNumber": match("TNumber"); break;
            default: throw new ParseException("Error. Not a Number.");
        }
    }
    
    private void El() throws ParseException
    {
        switch(tokenName)
        {
            case "TId": E(); U(); break;
            case "TNumber": E(); U(); break;
            default: throw new ParseException("Error. Not an Expression List.");
        }
    }
    
    private void U() throws ParseException
    {
        switch(tokenName)
        {
            case "TComma": match("TComma"); E(); U(); break;
            case "TRparen": break;
            default: throw new ParseException("Error. Not an Expression List.");
        }
    }
}