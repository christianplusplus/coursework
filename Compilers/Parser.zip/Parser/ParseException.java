/**
 * Write a description of class ParseException here.
 *
 * @author Christian Wendlandt
 * @version 2018.3.5
 */
public class ParseException extends Exception
{
    private String message;
    
    ParseException()
    {
        this("Error while parsing.");
    }
    ParseException(String message)
    {
        this.message = message;
    }
    
    public String getMessage()
    {
        return message;
    }
    
    @Override
    public String toString()
    {
        return message;
    }
}