I think I got everything to work
The ouptut works in Mars 4.5
"ant all" to compile all source files and compile prog1 into assembly
"ant bad" to run prog2