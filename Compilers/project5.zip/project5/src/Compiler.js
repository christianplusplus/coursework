Package Compiler;

Helpers
    sp  = ' ';
    tab = 9;
    cr = 13;
    lf = 10;
    eol = cr lf | cr | lf;
    digit = ['0'..'9'];
    letter = ['a'..'z'] | ['A'..'Z'];
    anychar = [[35..255] + 33];
Tokens
    whitespace = (sp | tab | eol)+;
    int = digit digit*;
    real = digit+ '.' digit+;
    begin = 'BEGIN';
    end = 'END';
    classtoken = 'CLASS';
    colon = ':';
    semicolon = ';';
    lcbracket = '{';
    rcbracket = '}';
    comma = ',';
    lparen = '(';
    rparen = ')';
    assign = ':=';
    lbracket = '[';
    rbracket = ']';
    if = 'IF';
    then = 'THEN';
    else = 'ELSE';
    while = 'WHILE';
    for = 'FOR';
    inc = '++';
    dec = '--';
    get = 'GET';
    put = 'PUT';
    new = 'NEW';
    period = '.';
    return = 'RETURN';
    switch = 'SWITCH';
    case = 'CASE';
    break = 'BREAK';
    default = 'DEFAULT';
    true = 'TRUE';
    false = 'FALSE';
    equal = '==';
    notequal = '!=';
    gte = '>=';
    lte = '<=';
    gt = '>';
    lt = '<';
    add = '+';
    minus = '-';
    mult = '*';
    div = '/';
    typeint = 'INT';
    typereal = 'REAL';
    typestring = 'STRING';
    typeboolean = 'BOOLEAN';
    typevoid = 'VOID';
    stringliteral = '"' (anychar | sp)* '"';
    id = letter (letter | digit | '_')*;
Ignored Tokens
    whitespace;
Productions
    prog
        = begin classmethodstmt* end//
        ;
    classmethodstmt
        = {declaration} classtoken id lcbracket methodstmtseq* rcbracket
        | {definition} type id lparen paramlist? rparen stmtblock
        | {groupdefinition} id extraid* colon type semicolon//
        ;
    extraid
        = comma id//
        ;
    methodstmtseq
        = {declaration} type id lparen paramlist? rparen stmtblock
        | {groupdefiniiton} id extraid* colon type semicolon//
        ;
    stmtblock
        = lcbracket stmt* rcbracket//
        ;
    stmt
        = {assignmentstmt} id arrpointer? assign logicalexpr semicolon//
        | {stringliteralassignmentstmt} id arrpointer? assign stringliteral semicolon//
        | {declarationstmt} id extraid* colon type arrpointer? semicolon//
        | {ifthenstmt} if lparen boolean rparen then stmtblock//
        | {ifthenelsestmt} if lparen boolean rparen then [firststmtblock]:stmtblock else [secondstmtblock]:stmtblock//
        | {whileloopstmt} while lparen boolean rparen stmtblock//
        | {forloopstmt} for lparen type? id assign [init]:logicalexpr [firstsemicolon]:semicolon [condition]:boolean [secondsemicolon]:semicolon loopupdate rparen stmtblock//
        | {getstmt} id arrpointer? assign get lparen rparen semicolon//
        | {putstmt} put lparen id arrpointer? rparen semicolon//
        | {incstmt} id arrpointer? inc semicolon//
        | {decstmt} id arrpointer? dec semicolon//
        | {newstmt} [firstid]:id arrpointer? assign new [secondid]:id lparen rparen semicolon
        | {methodcallstmt} id lparen varlist? rparen semicolon
        | {objectmethodcallstmt} [firstid]:id arrpointer? period [secondid]:id lparen varlist? rparen methodcall* semicolon
        | {returnstmt} return logicalexpr semicolon
        | {switchstmt} switch lparen logicalexpr rparen lcbracket switchcase+ default colon stmt* rcbracket
        ;
    methodcall
        = period id lparen varlist? rparen
        ;
    switchcase
        = case lparen int rparen colon stmt* switchbreak?
        ;
    switchbreak
        = break semicolon
        ;
    loopupdate
        = {incupdate} id inc
        | {decupdate} id dec
        | {assignupdate} id assign logicalexpr
        ;
    paramlist
        = id colon type arrpointer? extraparam*
        ;
    extraparam
        = comma id colon type arrpointer?
        ;
    varlist
        = logicalexpr extravar*
        ;
    extravar
        = comma logicalexpr
        ;
    logicalexpr
        = {condition} [expression1]:expr cond [expression2]:expr//
        | {expression} expr//
        ;
    expr
        = {add} expr add term//
        | {minus} expr minus term//
        | {term} term//
        ;
    term
        = {mult} term mult factor// check for negation
        | {div} term div factor//
        | {factor} factor//
        ;
    factor
        = {parenthesis} lparen logicalexpr rparen//
        | {negative} minus factor//
        | {intliteral} int//
        | {realliteral} real//
        | {true} true//
        | {false} false//
        | {id} id arrpointer?//
        | {methodcall} id lparen varlist? rparen
        | {objectmethodcall} [firstid]:id arrpointer? period [secondid]:id lparen varlist? rparen
        ;
    boolean
        = {true} true//
        | {false} false//
        | {condition} [expression1]:expr cond [expression2]:expr//
        | {id} id//
        ;
    arrpointer
        = lbracket int rbracket//
        ;
    cond
        = {equal} equal//
        | {notequal} notequal//
        | {greaterthanorequal} gte//
        | {lessthanorequal} lte//
        | {greaterthan} gt//
        | {lessthan} lt//
        ;
    type
        = {int} typeint//
        | {real} typereal//
        | {string} typestring//
        | {boolean} typeboolean//
        | {void} typevoid
        | {id} id
        ;
