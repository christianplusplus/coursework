package Compiler;

/**
 * @author Christian Wendlandt
 * @version 2018.4.18
 */

import Compiler.analysis.*;
import Compiler.node.*;
import java.util.*;

public class SymbolTable extends DepthFirstAdapter
{
    Closure envir;
    Closure rootEnvironment;
    HashMap<String, Variable> symbolTable;
    LinkedList<String> stack;
    
    public SymbolTable()
    {
        envir = new Closure(null);
        rootEnvironment = envir;
        symbolTable = new HashMap<>();
        stack = new LinkedList<>();
    }
    
    public HashMap<String, Variable> getSymbolTable()
    {
        return symbolTable;
    }
    
    public Closure getEnvironment()
    {
        return rootEnvironment;
    }
    
    public void descendEnvironment()
    {
        envir = envir.makeChild();
    }
    
    public void ascendEnvironment()
    {
        envir = envir.getParent();
    }
    
    public void declareVar(String type, String name, int arrayNumber)
    {
        Variable var;
        int lineNumber = Integer.parseInt(stack.pop());
        
        if(envir.add(name))
        {
            switch(type)
            {
                case "BOOLEAN":
                    var = new Variable(Variable.Type.BOOLEAN, name, arrayNumber);
                    break;
                case "INT":
                    var = new Variable(Variable.Type.INT, name, arrayNumber);
                    break;
                case "REAL":
                    var = new Variable(Variable.Type.REAL, name, arrayNumber);
                    break;
                case "STRING":
                    var = new Variable(Variable.Type.STRING, name, arrayNumber);
                    break;
                default:
                    ErrorLog.log(type + " is not a valid variable type", lineNumber);
                    return;
            }
            symbolTable.put(envir.getVarId(name), var);
        }
        else
            ErrorLog.log(name + " is already defined in its closure", lineNumber);
    }
    
    //rules for closures
    public void inAStmtblock(AStmtblock node)
    {descendEnvironment();}
    public void outAStmtblock(AStmtblock node)
    {ascendEnvironment();}
    public void inADeclarationClassmethodstmt(ADeclarationClassmethodstmt node)
    {descendEnvironment();}
    public void outADeclarationClassmethodstmt(ADeclarationClassmethodstmt node)
    {ascendEnvironment();}
    public void inADeclarationMethodstmtseq(ADeclarationMethodstmtseq node)
    {descendEnvironment();}
    public void outADeclarationMethodstmtseq(ADeclarationMethodstmtseq node)
    {ascendEnvironment();}
    public void inAForloopstmtStmt(AForloopstmtStmt node)
    {descendEnvironment();}
    public void outAForloopstmtStmt(AForloopstmtStmt node)
    {ascendEnvironment();}
    public void inASwitchstmtStmt(ASwitchstmtStmt node)
    {descendEnvironment();}
    public void outASwitchstmtStmt(ASwitchstmtStmt node)
    {ascendEnvironment();}
    
    public void caseAGroupdefinitionClassmethodstmt(AGroupdefinitionClassmethodstmt node)
    {
        String[] names;
        String type;
        
        node.getId().apply(this);
        List<PExtraid> copy = new ArrayList<>(node.getExtraid());
        names = new String[copy.size() + 1];
        names[0] = node.getId().getText();
        
        for(int i = 0; i < copy.size(); i++)
        {
            copy.get(i).apply(this);
            names[i + 1] = stack.pop();
        }
        node.getType().apply(this);
        type = stack.pop();
        
        for(String name : names)
        {
            stack.push(Integer.toString(node.getId().getLine()));
            declareVar(type, name, 1);
        }
    }
    
    public void caseAGroupdefiniitonMethodstmtseq(AGroupdefiniitonMethodstmtseq node)
    {
        String[] names;
        String type;
        
        node.getId().apply(this);
        List<PExtraid> copy = new ArrayList<PExtraid>(node.getExtraid());
        names = new String[copy.size() + 1];
        names[0] = node.getId().getText();
        
        for(int i = 0; i < copy.size(); i++)
        {
            copy.get(i).apply(this);
            names[i + 1] = stack.pop();
        }
        node.getType().apply(this);
        type = stack.pop();
        
        for(String name : names)
        {
            stack.push(Integer.toString(node.getId().getLine()));
            declareVar(type, name, 1);
        }
    }
    
    public void caseADeclarationstmtStmt(ADeclarationstmtStmt node)
    {
        String[] names;
        String type;
        int arrSize = 1;
        
        node.getId().apply(this);
        List<PExtraid> copy = new ArrayList<PExtraid>(node.getExtraid());
        names = new String[copy.size() + 1];
        names[0] = node.getId().getText();
        
        for(int i = 0; i < copy.size(); i++)
        {
            copy.get(i).apply(this);
            names[i + 1] = stack.pop();
        }
        node.getType().apply(this);
        type = stack.pop();
        
        if(node.getArrpointer() != null)
        {
            node.getArrpointer().apply(this);
            arrSize = Integer.parseInt(stack.pop());
        }
        
        for(String name : names)
        {
            stack.push(Integer.toString(node.getId().getLine()));
            declareVar(type, name, arrSize);
        }
    }
    
    public void caseAExtraid(AExtraid node)
    {
        stack.push(node.getId().toString().trim());
    }
    
    public void caseAForloopstmtStmt(AForloopstmtStmt node)
    {
        String type = "";
        String name;
        
        inAForloopstmtStmt(node);
        if(node.getType() != null)
        {
            node.getType().apply(this);
            type = node.getType().toString().trim();
        }
        node.getId().apply(this);
        name = node.getId().getText();
        if(!type.equals(""))
        {
            stack.push(Integer.toString(node.getId().getLine()));
            declareVar(type, name, 1);
        }
        
        node.getInit().apply(this);
        node.getCondition().apply(this);
        node.getLoopupdate().apply(this);
        node.getStmtblock().apply(this);
        outAForloopstmtStmt(node);
    }
    
    public void caseAArrpointer(AArrpointer node)
    {
        node.getInt().apply(this);
        stack.push(node.getInt().getText());
    }
    
    public void caseABooleanType(ABooleanType node)
    {
        node.getTypeboolean().apply(this);
        stack.push("BOOLEAN");
    }
    
    public void caseAStringType(AStringType node)
    {
        node.getTypestring().apply(this);
        stack.push("STRING");
    }
    
    public void caseAIntType(AIntType node)
    {
        node.getTypeint().apply(this);
        stack.push("INT");
    }
    
    public void caseARealType(ARealType node)
    {
        node.getTypereal().apply(this);
        stack.push("REAL");
    }
    
    public void caseAIdType(AIdType node)
    {
        node.getId().apply(this);
        stack.push(node.getId().toString().trim());
    }
}
