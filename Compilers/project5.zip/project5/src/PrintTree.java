package Compiler;

import Compiler.analysis.*;
import Compiler.node.*;
import java.util.*;


class PrintTree extends DepthFirstAdapter
{
    HashMap<String, Variable> symbolTable;
    LinkedList<String> typeStack;
    Closure envir;
    ArrayList<String> data;
    ArrayList<String> code;
    int labelCounter;
    
 	public PrintTree(HashMap<String, Variable> symbolTable, Closure envir)
    {
        this.symbolTable = symbolTable;
        typeStack = new LinkedList<>();
        this.envir = envir;
        data = new ArrayList<>();
        code = new ArrayList<>();
        labelCounter = 0;
        data.add(".data");
        data.add("true: .asciiz \"true\"");
        data.add("false: .asciiz \"false\"");
        data.add(".align 2");
        code.add(".text");
        code.add(".globl MAIN");
        code.add("MAIN:");
        for(String var : symbolTable.keySet())
            if(!symbolTable.get(var).getType().equals("STRING"))
                data.add(var + symbolTable.get(var).memoryCode());
	}
    
    public void printAssembly()
    {
        for(String line : data)
            System.out.println(line);
        for(String line : code)
            System.out.println(line);
    }
    
    private String getLabel()
    {
        return "label_" + labelCounter++;
    }
    
    private void outNewLine()
    {
        code.add("li $v0, 11");
        code.add("li $a0, 10");
        code.add("syscall");
    }
    
    private void pushRegister(int reg, String type)
    {
        if(type.equals("BOOLEAN") || type.equals("INT"))
        {
            code.add("sw $s" + reg + ", 0($sp)");
            code.add("add $sp, $sp, -4");
            typeStack.push(type);
        }
        else if(type.equals("REAL"))
        {
            code.add("s.s $f" + reg * 2 + ", 0($sp)");
            code.add("add $sp, $sp, -4");
            typeStack.push(type);
        }
    }
    
    private void popRegister(int reg, String type)
    {
        if(type.equals("BOOLEAN") || type.equals("INT"))
        {
            code.add("add $sp, $sp, 4");
            code.add("lw $s" + reg + ", 0($sp)");
        }
        else if(type.equals("REAL"))
        {
            code.add("add $sp, $sp, 4");
            code.add("l.s $f" + reg * 2 + ", 0($sp)");
        }
    }

    public void descendEnvironment()
    {
        envir = envir.getNextChild();
    }
    
    public void ascendEnvironment()
    {
        envir = envir.getParent();
    }
    
    //rules for closures
    public void inAStmtblock(AStmtblock node)
    {descendEnvironment();}
    public void outAStmtblock(AStmtblock node)
    {ascendEnvironment();}
    public void inADeclarationClassmethodstmt(ADeclarationClassmethodstmt node)
    {descendEnvironment();}
    public void outADeclarationClassmethodstmt(ADeclarationClassmethodstmt node)
    {ascendEnvironment();}
    public void inADeclarationMethodstmtseq(ADeclarationMethodstmtseq node)
    {descendEnvironment();}
    public void outADeclarationMethodstmtseq(ADeclarationMethodstmtseq node)
    {ascendEnvironment();}
    public void inAForloopstmtStmt(AForloopstmtStmt node)
    {descendEnvironment();}
    public void outAForloopstmtStmt(AForloopstmtStmt node)
    {ascendEnvironment();}
    public void inASwitchstmtStmt(ASwitchstmtStmt node)
    {descendEnvironment();}
    public void outASwitchstmtStmt(ASwitchstmtStmt node)
    {ascendEnvironment();}
    
    public void outAProg(AProg node)
    {
        code.add("li $v0, 10");
        code.add("syscall");
    }
    
    public void caseAAssignmentstmtStmt(AAssignmentstmtStmt node)
    {
        String id;
        int offset = 0;
        String type;
        Variable var;
        
        id = envir.getVarId(node.getId().getText());
        
        if(node.getArrpointer() != null)
        {
            node.getArrpointer().apply(this);
            offset = Integer.parseInt(typeStack.pop());
        }
        
        node.getLogicalexpr().apply(this);
        type = typeStack.pop();
        popRegister(0, type);
        if(id.equals(""))
            return;
        
        var = symbolTable.get(id);
        if(offset >= var.getArraySize())
        {
            ErrorLog.log("Index out of bounds", node.getId().getLine());
            return;
        }
        
        code.add("la $s2, " + id);
        if(var.getType().equals("REAL") && type.equals("REAL"))
            code.add("s.s $f0, " + offset * var.getSize() + "($s2)");
        else if(var.getType().equals("REAL") && (type.equals("INT") || type.equals("BOOLEAN")))
        {
            code.add("mtc1 $s0, $f0");
            code.add("cvt.s.w $f0, $f0");
            code.add("s.s $f0, " + offset * var.getSize() + "($s2)");
        }
        else if(var.getType().equals("INT") && (type.equals("INT") || type.equals("BOOLEAN")))
            code.add("sw $s0, " + offset * var.getSize() + "($s2)");
        else if(var.getType().equals("BOOLEAN") && type.equals("BOOLEAN"))
            code.add("sw $s0, " + offset * var.getSize() + "($s2)");
        else
            ErrorLog.log(type + " can't be stored in " + var.getType(), node.getId().getLine());
    }
    
    public void caseAStringliteralassignmentstmtStmt(AStringliteralassignmentstmtStmt node)
    {
        String name = node.getId().getText();
        String id;
        
        id = envir.getVarId(name);
        if(id.equals(""))
            return;
        if(!symbolTable.get(id).getType().equals("STRING"))
        {
            ErrorLog.log(name + " is not a STRING type and cannot store " + node.getStringliteral().getText(), node.getId().getLine());
            return;
        }
        if(symbolTable.get(id).isStringAlreadyAssigned())
        {
            ErrorLog.log("Cannot assign " + node.getStringliteral().getText() + " to " + name + " because strings are immutable", node.getId().getLine());
            return;
        }
        data.add(id +  symbolTable.get(id).memoryCode() + node.getStringliteral().getText());
        data.add(".align 2");
    }
    
    public void caseAArrpointer(AArrpointer node)
    {
        typeStack.push(node.getInt().getText());
    }
    
    public void caseAConditionLogicalexpr(AConditionLogicalexpr node)
    {
        String type1;
        String type2;
        String operator;
        String trueLabel;
        String endLabel;
        
        node.getExpression1().apply(this);
        node.getCond().apply(this);
        node.getExpression2().apply(this);
        
        type2 = typeStack.pop();
        popRegister(1, type2);
        operator = typeStack.pop();
        type1 = typeStack.pop();
        popRegister(0, type1);
        
        trueLabel = getLabel();
        endLabel = getLabel();
        if((type1.equals("INT") || type1.equals("BOOLEAN")) && (type2.equals("INT") || type2.equals("BOOLEAN")))
        {
            code.add(operator + " $s0, $s1, " + trueLabel);
            pushBranch(trueLabel, endLabel);
        }
        else if(type1.equals("REAL") && (type2.equals("INT") || type2.equals("BOOLEAN")))
        {
            code.add("mtc1 $s1, $f2");
            code.add("cvt.s.w $f2, $f2");
            convertAndPrintFPBranch(operator, trueLabel);
            pushBranch(trueLabel, endLabel);
        }
        else if((type1.equals("INT") || type1.equals("BOOLEAN")) && type2.equals("REAL"))
        {
            code.add("mtc1 $s0, $f0");
            code.add("cvt.s.w $f0, $f0");
            convertAndPrintFPBranch(operator, trueLabel);
            pushBranch(trueLabel, endLabel);
        }
        else if(type1.equals("REAL") && type2.equals("REAL"))
        {
            code.add("mtc1 $s0, $f0");
            code.add("cvt.s.w $f0, $f0");
            code.add("mtc1 $s1, $f2");
            code.add("cvt.s.w $f2, $f2");
            convertAndPrintFPBranch(operator, trueLabel);
            pushBranch(trueLabel, endLabel);
        }
        else
            ErrorLog.log("Can't compare " + type1 + " with " + type2);
    }
    
    private void convertAndPrintFPBranch(String operator, String trueLabel)
    {
        switch(operator)
        {
            case "beq":
                code.add("c.eq.s $f0, $f2");
                code.add("bc1t " + trueLabel);
                break;
            case "blt":
                code.add("c.lt.s $f0, $f2");
                code.add("bc1t " + trueLabel);
                break;
            case "ble":
                code.add("c.le.s $f0, $f2");
                code.add("bc1t " + trueLabel);
                break;
            case "bgt":
                code.add("c.le.s $f0, $f2");
                code.add("bc1f " + trueLabel);
                break;
            case "bge":
                code.add("c.lt.s $f0, $f2");
                code.add("bc1f " + trueLabel);
                break;
            case "bne":
                code.add("c.eq.s $f0, $f2");
                code.add("bc1f " + trueLabel);
        }
    }
    
    private void pushBranch(String trueLabel, String endLabel)
    {
        code.add("li $s0, 0");
        code.add("b " + endLabel);
        code.add(trueLabel + ':');
        code.add("li $s0, 1");
        code.add(endLabel + ':');
        pushRegister(0, "BOOLEAN");
    }
    
    public void caseAAddExpr(AAddExpr node)
    {
        String type1;
        String type2;
        
        node.getExpr().apply(this);
        node.getTerm().apply(this);
        
        type2 = typeStack.pop();
        popRegister(1, type2);
        type1 = typeStack.pop();
        popRegister(0, type1);
        
        if((type1.equals("INT") || type1.equals("BOOLEAN")) && (type2.equals("INT") || type2.equals("BOOLEAN")))
        {
            code.add("add $s0, $s0, $s1");
            pushRegister(0, "INT");
        }
        else if(type1.equals("REAL") && (type2.equals("INT") || type2.equals("BOOLEAN")))
        {
            code.add("mtc1 $s1, $f2");
            code.add("cvt.s.w $f2, $f2");
            code.add("add.s $f0, $f0, $f2");
            pushRegister(0, "REAL");
        }
        else if((type1.equals("INT") || type1.equals("BOOLEAN")) && type2.equals("REAL"))
        {
            code.add("mtc1 $s0, $f0");
            code.add("cvt.s.w $f0, $f0");
            code.add("add.s $f0, $f0, $f2");
            pushRegister(0, "REAL");
        }
        else if(type1.equals("REAL") && type2.equals("REAL"))
        {
            code.add("add.s $f0, $f0, $f2");
            pushRegister(0, "REAL");
        }
        else
            ErrorLog.log("Can't add " + type1 + " with " + type2, node.getAdd().getLine());
    }
    
    public void caseAMinusExpr(AMinusExpr node)
    {
        String type1;
        String type2;
        
        node.getExpr().apply(this);
        node.getTerm().apply(this);
        
        type2 = typeStack.pop();
        popRegister(1, type2);
        type1 = typeStack.pop();
        popRegister(0, type1);
        
        if((type1.equals("INT") || type1.equals("BOOLEAN")) && (type2.equals("INT") || type2.equals("BOOLEAN")))
        {
            code.add("sub $s0, $s0, $s1");
            pushRegister(0, "INT");
        }
        else if(type1.equals("REAL") && (type2.equals("INT") || type2.equals("BOOLEAN")))
        {
            code.add("mtc1 $s1, $f2");
            code.add("cvt.s.w $f2, $f2");
            code.add("sub.s $f0, $f0, $f2");
            pushRegister(0, "REAL");
        }
        else if((type1.equals("INT") || type1.equals("BOOLEAN")) && type2.equals("REAL"))
        {
            code.add("mtc1 $s0, $f0");
            code.add("cvt.s.w $f0, $f0");
            code.add("sub.s $f0, $f0, $f2");
            pushRegister(0, "REAL");
        }
        else if(type1.equals("REAL") && type2.equals("REAL"))
        {
            code.add("sub.s $f0, $f0, $f2");
            pushRegister(0, "REAL");
        }
        else
            ErrorLog.log("Can't subtract " + type1 + " with " + type2, node.getMinus().getLine());
    }
    public void caseAMultTerm(AMultTerm node)
    {
        String type1;
        String type2;
        
        node.getTerm().apply(this);
        node.getFactor().apply(this);
        
        type2 = typeStack.pop();
        popRegister(1, type2);
        type1 = typeStack.pop();
        popRegister(0, type1);
        
        if((type1.equals("INT") || type1.equals("BOOLEAN")) && (type2.equals("INT") || type2.equals("BOOLEAN")))
        {
            code.add("mul $s0, $s0, $s1");
            pushRegister(0, "INT");
        }
        else if(type1.equals("REAL") && (type2.equals("INT") || type2.equals("BOOLEAN")))
        {
            code.add("mtc1 $s1, $f2");
            code.add("cvt.s.w $f2, $f2");
            code.add("mul.s $f0, $f0, $f2");
            pushRegister(0, "REAL");
        }
        else if((type1.equals("INT") || type1.equals("BOOLEAN")) && type2.equals("REAL"))
        {
            code.add("mtc1 $s0, $f0");
            code.add("cvt.s.w $f0, $f0");
            code.add("mul.s $f0, $f0, $f2");
            pushRegister(0, "REAL");
        }
        else if(type1.equals("REAL") && type2.equals("REAL"))
        {
            code.add("mul.s $f0, $f0, $f2");
            pushRegister(0, "REAL");
        }
        else
            ErrorLog.log("Can't multiply " + type1 + " with " + type2, node.getMult().getLine());
    }
    
    public void caseADivTerm(ADivTerm node)
    {
        String type1;
        String type2;
        
        node.getTerm().apply(this);
        node.getFactor().apply(this);
        
        type2 = typeStack.pop();
        popRegister(1, type2);
        type1 = typeStack.pop();
        popRegister(0, type1);
        
        if((type1.equals("INT") || type1.equals("BOOLEAN")) && (type2.equals("INT") || type2.equals("BOOLEAN")))
        {
            code.add("div $s0, $s0, $s1");
            pushRegister(0, "INT");
        }
        else if(type1.equals("REAL") && (type2.equals("INT") || type2.equals("BOOLEAN")))
        {
            code.add("mtc1 $s1, $f2");
            code.add("cvt.s.w $f2, $f2");
            code.add("div.s $f0, $f0, $f2");
            pushRegister(0, "REAL");
        }
        else if((type1.equals("INT") || type1.equals("BOOLEAN")) && type2.equals("REAL"))
        {
            code.add("mtc1 $s0, $f0");
            code.add("cvt.s.w $f0, $f0");
            code.add("div.s $f0, $f0, $f2");
            pushRegister(0, "REAL");
        }
        else if(type1.equals("REAL") && type2.equals("REAL"))
        {
            code.add("div.s $f0, $f0, $f2");
            pushRegister(0, "REAL");
        }
        else
            ErrorLog.log("Can't divide " + type1 + " with " + type2, node.getDiv().getLine());
    }
    
    public void caseANegativeFactor(ANegativeFactor node)
    {
        String type;
        
        node.getFactor().apply(this);
        
        type = typeStack.pop();
        popRegister(0, type);
        
        if(type.equals("INT") || type.equals("BOOLEAN"))
        {
            code.add("sub $s0, $zero, $s0");
            pushRegister(0, "INT");
        }
        else if(type.equals("REAL"))
        {
            code.add("neg.s $f0, $f0");
            pushRegister(0, "REAL");
        }
        else
            ErrorLog.log("Can't negate a " + type, node.getMinus().getLine());
    }
    
    public void caseAIntliteralFactor(AIntliteralFactor node)
    {
        code.add("li $s0, " + node.getInt().toString().trim());
        pushRegister(0, "INT");
    }
    
    public void caseARealliteralFactor(ARealliteralFactor node)
    {
        String label;
        
        label = "float_" + getLabel();
        
        data.add(label + ": .float " + node.getReal().toString().trim());
        code.add("l.s $f0, " + label);
        pushRegister(0, "REAL");
    }
    
    public void caseATrueFactor(ATrueFactor node)
    {
        code.add("li $s0, 1");
        pushRegister(0, "BOOLEAN");
    }
    
    public void caseAFalseFactor(AFalseFactor node)
    {
        code.add("li $s0, 0");
        pushRegister(0, "BOOLEAN");
    }
    
    public void caseAIdFactor(AIdFactor node)
    {
        String id;
        int offset = 0;
        String type;
        Variable var;
        
        id = envir.getVarId(node.getId().getText());
        if(id.equals(""))
        {
            typeStack.push("BOOLEAN");
            pushRegister(0, "BOOLEAN");
            return;
        }
        var = symbolTable.get(id);
        type = var.getType();
        
        if(node.getArrpointer() != null)
        {
            node.getArrpointer().apply(this);
            offset = Integer.parseInt(typeStack.pop());
        }
        
        if(offset >= var.getArraySize())
        {
            ErrorLog.log("Index out of bounds", node.getId().getLine());
            return;
        }
        
        code.add("la $s2, " + id);
        switch(type)
        {
            case "BOOLEAN":
                code.add("lw $s0, " + offset * var.getSize() + "($s2)");
                pushRegister(0, type);
                break;
            case "INT":
                code.add("lw $s0, " + offset * var.getSize() + "($s2)");
                pushRegister(0, type);
                break;
            case "REAL":
                code.add("l.s $f0, " + offset * var.getSize() + "($s2)");
                pushRegister(0, type);
                break;
            default:
                ErrorLog.log(type + " can't be used as a factor", node.getId().getLine());
                pushRegister(0, "BOOLEAN");
        }
    }
    
    public void caseATrueBoolean(ATrueBoolean node)
    {
        code.add("li $s0, 1");
        pushRegister(0, "BOOLEAN");
    }
    
    public void caseAFalseBoolean(AFalseBoolean node)
    {
        code.add("li $s0, 0");
        pushRegister(0, "BOOLEAN");
    }
    
    public void caseAConditionBoolean(AConditionBoolean node)
    {
        String type1;
        String type2;
        String operator;
        String trueLabel;
        String endLabel;
        
        node.getExpression1().apply(this);
        node.getCond().apply(this);
        node.getExpression2().apply(this);
        
        type2 = typeStack.pop();
        popRegister(1, type2);
        operator = typeStack.pop();
        type1 = typeStack.pop();
        popRegister(0, type1);
        
        trueLabel = getLabel();
        endLabel = getLabel();
        if((type1.equals("INT") || type1.equals("BOOLEAN")) && (type2.equals("INT") || type2.equals("BOOLEAN")))
        {
            code.add(operator + " $s0, $s1, " + trueLabel);
            pushBranch(trueLabel, endLabel);
        }
        else if(type1.equals("REAL") && (type2.equals("INT") || type2.equals("BOOLEAN")))
        {
            code.add("mtc1 $s1, $f2");
            code.add("cvt.s.w $f2, $f2");
            convertAndPrintFPBranch(operator, trueLabel);
            pushBranch(trueLabel, endLabel);
        }
        else if((type1.equals("INT") || type1.equals("BOOLEAN")) && type2.equals("REAL"))
        {
            code.add("mtc1 $s0, $f0");
            code.add("cvt.s.w $f0, $f0");
            convertAndPrintFPBranch(operator, trueLabel);
            pushBranch(trueLabel, endLabel);
        }
        else if(type1.equals("REAL") && type2.equals("REAL"))
        {
            code.add("mtc1 $s0, $f0");
            code.add("cvt.s.w $f0, $f0");
            code.add("mtc1 $s1, $f2");
            code.add("cvt.s.w $f2, $f2");
            convertAndPrintFPBranch(operator, trueLabel);
            pushBranch(trueLabel, endLabel);
        }
        else
            ErrorLog.log("Can't compare " + type1 + " with " + type2);
    }
    
    public void caseAIdBoolean(AIdBoolean node)
    {
        String id;
        String type;
        Variable var;
        
        id = envir.getVarId(node.getId().getText());
        if(id.equals(""))
        {
            typeStack.push("BOOLEAN");
            pushRegister(0, "BOOLEAN");
            return;
        }
        var = symbolTable.get(id);
        type = var.getType();
        
        code.add("la $s2, " + id);
        switch(type)
        {
            case "BOOLEAN":
                code.add("lw $s0, 0($s2)");
                pushRegister(0, type);
                break;
            case "INT":
                code.add("lw $s0, 0($s2)");
                pushRegister(0, type);
                break;
            default:
                ErrorLog.log(var.getName() + " can't be used as a boolean", node.getId().getLine());
                pushRegister(0, "BOOLEAN");
        }
    }
    
    public void caseAEqualCond(AEqualCond node)
    {
        typeStack.push("beq");
    }
    
    public void caseANotequalCond(ANotequalCond node)
    {
        typeStack.push("bne");
    }
    
    public void caseAGreaterthanorequalCond(AGreaterthanorequalCond node)
    {
        typeStack.push("bge");
    }
    
    public void caseALessthanorequalCond(ALessthanorequalCond node)
    {
        typeStack.push("ble");
    }
    
    public void caseAGreaterthanCond(AGreaterthanCond node)
    {
        typeStack.push("bgt");
    }
    
    public void caseALessthanCond(ALessthanCond node)
    {
        typeStack.push("blt");
    }
    
    public void caseAGetstmtStmt(AGetstmtStmt node)
    {
        String id;
        int offset = 0;
        Variable var;
        
        id = envir.getVarId(node.getId().getText());
        
        if(node.getArrpointer() != null)
        {
            node.getArrpointer().apply(this);
            offset = Integer.parseInt(typeStack.pop());
        }
        
        if(id.equals(""))
            return;
        var = symbolTable.get(id);
        if(offset >= var.getArraySize())
        {
            ErrorLog.log("Index out of bounds", node.getId().getLine());
            return;
        }
        
        code.add("la $s2, " + id);
        
        switch(var.getType())
        {
            case "BOOLEAN":
            case "INT":
                code.add("li $v0, 5");
                code.add("syscall");
                code.add("move $s0, $v0");
                code.add("sw $s0, " + offset * var.getSize() + "($s2)");
                break;
            case "REAL":
                code.add("li $v0, 6");
                code.add("syscall");
                code.add("s.s $f0, " + offset * var.getSize() + "($s2)");
                break;
            case "STRING":
                data.add(id + ": .space 100");
                code.add("la $a0, " + id);
                code.add("li $a1, 100");
                code.add("li $v0, 8");
                code.add("syscall");
        }
    }
    
    public void caseAPutstmtStmt(APutstmtStmt node)
    {
        int offset = 0;
        Variable var;
        String id;
        
        id = envir.getVarId(node.getId().getText());
        
        if(node.getArrpointer() != null)
        {
            node.getArrpointer().apply(this);
            offset = Integer.parseInt(typeStack.pop());
        }
        
        if(id.equals(""))
            return;
        var = symbolTable.get(id);
        if(offset >= var.getArraySize())
        {
            ErrorLog.log("Index out of bounds", node.getId().getLine());
            return;
        }
        
        code.add("la $s2, " + id);
        
        switch(var.getType())
        {
            case "BOOLEAN":
                String falseLabel = getLabel();
                String endLabel = getLabel();
                code.add("li $v0, 4");
                code.add("lw $a0, " + offset * var.getSize() + "($s2)");
                code.add("beq $a0, 0, " + falseLabel);
                code.add("la $a0, true");
                code.add("b " + endLabel);
                code.add(falseLabel + ':');
                code.add("la $a0, false");
                code.add(endLabel + ':');
                code.add("syscall");
                break;
            case "INT":
                code.add("li $v0, 1");
                code.add("lw $a0, " + offset * var.getSize() + "($s2)");
                code.add("syscall");
                break;
            case "REAL":
                code.add("li $v0, 2");
                code.add("l.s $f12, " + offset * var.getSize() + "($s2)");
                code.add("syscall");
                break;
            case "STRING":
                code.add("li $v0, 4");
                code.add("la $a0, 0($s2)");
                code.add("syscall");
        }
    }
    
    public void caseAIncstmtStmt(AIncstmtStmt node)
    {
        int offset = 0;
        Variable var;
        String id;
        
        id = envir.getVarId(node.getId().getText());
        if(id.equals(""))
            return;
        
        if(node.getArrpointer() != null)
        {
            node.getArrpointer().apply(this);
            offset = Integer.parseInt(typeStack.pop());
        }
        
        var = symbolTable.get(id);
        if(offset >= var.getArraySize())
        {
            ErrorLog.log("Index out of bounds", node.getId().getLine());
            return;
        }
        
        code.add("la $s2, " + id);
        
        switch(var.getType())
        {
            case "INT":
                code.add("lw $s0, " + offset * var.getSize() + "($s2)");
                code.add("addi $s0, $s0, 1");
                code.add("sw $s0, " + offset * var.getSize() + "($s2)");
                break;
            case "REAL":
                code.add("l.s $f0, " + offset * var.getSize() + "($s2)");
                code.add("li $s0, 1");
                code.add("mtc1 $s0, $f2");
                code.add("cvt.s.w $f2, $f2");
                code.add("add.s $f0, $f0, $f2");
                code.add("s.s $f0, " + offset * var.getSize() + "($s2)");
                break;
            default:
                ErrorLog.log(var.getName() + " is not a type that can be incremented", node.getId().getLine());
        }
    }
    
    public void caseADecstmtStmt(ADecstmtStmt node)
    {
        int offset = 0;
        Variable var;
        String id;
        
        id = envir.getVarId(node.getId().getText());
        if(id.equals(""))
            return;
        
        if(node.getArrpointer() != null)
        {
            node.getArrpointer().apply(this);
            offset = Integer.parseInt(typeStack.pop());
        }
        
        var = symbolTable.get(id);
        if(offset >= var.getArraySize())
        {
            ErrorLog.log("Index out of bounds", node.getId().getLine());
            return;
        }
        
        code.add("la $s2, " + id);
        
        switch(var.getType())
        {
            case "INT":
                code.add("lw $s0, " + offset * var.getSize() + "($s2)");
                code.add("subi $s0, $s0, 1");
                code.add("sw $s0, " + offset * var.getSize() + "($s2)");
                break;
            case "REAL":
                code.add("l.s $f0, " + offset * var.getSize() + "($s2)");
                code.add("li $s0, 1");
                code.add("mtc1 $s0, $f2");
                code.add("cvt.s.w $f2, $f2");
                code.add("sub.s $f0, $f0, $f2");
                code.add("s.s $f0, " + offset * var.getSize() + "($s2)");
                break;
            default:
                ErrorLog.log(var.getName() + " is not a type that can be decremented", node.getId().getLine());
        }
    }
    
    public void caseAIfthenstmtStmt(AIfthenstmtStmt node)
    {
        String label = "endif_" + getLabel();
        String type;
        
        node.getBoolean().apply(this);
        type = typeStack.pop();
        popRegister(0, type);
        code.add("beq $s0, $zero, " + label);
        
        node.getStmtblock().apply(this);
        code.add(label + ':');
    }
    
    public void caseAIfthenelsestmtStmt(AIfthenelsestmtStmt node)
    {
        String elseLabel = "else_" + getLabel();
        String endLabel = "endif_" + getLabel();
        String type;
        
        node.getBoolean().apply(this);
        type = typeStack.pop();
        popRegister(0, type);
        code.add("beq $s0, $zero, " + elseLabel);
        
        node.getFirststmtblock().apply(this);
        code.add("b " + endLabel);
        
        code.add(elseLabel + ':');
        node.getSecondstmtblock().apply(this);
        code.add(endLabel + ':');
    }
    
    public void caseAWhileloopstmtStmt(AWhileloopstmtStmt node)
    {
        String startLabel = "startwhile_" + getLabel();
        String endLabel = "endwhile_" + getLabel();
        String type;
        
        code.add(startLabel + ":");
        node.getBoolean().apply(this);
        type = typeStack.pop();
        popRegister(0, type);
        code.add("beq $s0, $zero, " + endLabel);
        
        node.getStmtblock().apply(this);
        code.add("b " + startLabel);
        code.add(endLabel + ':');
    }
    
    public void caseAForloopstmtStmt(AForloopstmtStmt node)
    {
        inAForloopstmtStmt(node);
        
        String startLabel = "startfor_" + getLabel();
        String endLabel = "endfor_" + getLabel();
        String id;
        String type;
        Variable var;
        
        id = envir.getVarId(node.getId().getText());
        
        node.getInit().apply(this);
        type = typeStack.pop();
        popRegister(0, type);
        if(id.equals(""))
            return;
        var = symbolTable.get(id);
        
        code.add("la $s2, " + id);
        if(var.getType().equals("REAL") && type.equals("REAL"))
            code.add("s.s $f0, 0($s2)");
        else if(var.getType().equals("REAL") && (type.equals("INT") || type.equals("BOOLEAN")))
        {
            code.add("mtc1 $s0, $f0");
            code.add("cvt.s.w $f0, $f0");
            code.add("s.s $f0, 0($s2)");
        }
        else if(var.getType().equals("INT") && (type.equals("INT") || type.equals("BOOLEAN")))
            code.add("sw $s0, 0($s2)");
        else if(var.getType().equals("BOOLEAN") && type.equals("BOOLEAN"))
            code.add("sw $s0, 0($s2)");
        else
            ErrorLog.log(type + " can't be stored in " + var.getType(), node.getId().getLine());
        
        
        code.add(startLabel + ":");
        node.getCondition().apply(this);
        type = typeStack.pop();
        popRegister(0, type);
        code.add("beq $s0, $zero, " + endLabel);
        
        node.getStmtblock().apply(this);
        node.getLoopupdate().apply(this);
        code.add("b " + startLabel);
        code.add(endLabel + ':');
        
        outAForloopstmtStmt(node);
    }
    
    public void caseAIncupdateLoopupdate(AIncupdateLoopupdate node)
    {
        Variable var;
        String id;
        
        id = envir.getVarId(node.getId().getText());
        if(id.equals(""))
            return;
        
        var = symbolTable.get(id);
        code.add("la $s2, " + id);
        
        switch(var.getType())
        {
            case "INT":
                code.add("lw $s0, 0($s2)");
                code.add("addi $s0, $s0, 1");
                code.add("sw $s0, 0($s2)");
                break;
            case "REAL":
                code.add("l.s $f0, 0($s2)");
                code.add("li $s0, 1");
                code.add("mtc1 $s0, $f2");
                code.add("cvt.s.w $f2, $f2");
                code.add("add.s $f0, $f0, $f2");
                code.add("s.s $f0, 0($s2)");
                break;
            default:
                ErrorLog.log(var.getName() + " is not a type that can be incremented", node.getId().getLine());
        }
    }
    
    public void caseADecupdateLoopupdate(ADecupdateLoopupdate node)
    {
        Variable var;
        String id;
        
        id = envir.getVarId(node.getId().getText());
        if(id.equals(""))
            return;
        
        var = symbolTable.get(id);
        code.add("la $s2, " + id);
        
        switch(var.getType())
        {
            case "INT":
                code.add("lw $s0, 0($s2)");
                code.add("subi $s0, $s0, 1");
                code.add("sw $s0, 0($s2)");
                break;
            case "REAL":
                code.add("l.s $f0, 0($s2)");
                code.add("li $s0, 1");
                code.add("mtc1 $s0, $f2");
                code.add("cvt.s.w $f2, $f2");
                code.add("sub.s $f0, $f0, $f2");
                code.add("s.s $f0, 0($s2)");
                break;
            default:
                ErrorLog.log(var.getName() + " is not a type that can be decremented", node.getId().getLine());
        }
    }
    
    public void caseAAssignupdateLoopupdate(AAssignupdateLoopupdate node)
    {
        String id;
        String type;
        Variable var;
        
        id = envir.getVarId(node.getId().getText());
        
        node.getLogicalexpr().apply(this);
        type = typeStack.pop();
        popRegister(0, type);
        if(id.equals(""))
            return;
        var = symbolTable.get(id);
        
        code.add("la $s2, " + id);
        if(var.getType().equals("REAL") && type.equals("REAL"))
            code.add("s.s $f0, 0($s2)");
        else if(var.getType().equals("REAL") && (type.equals("INT") || type.equals("BOOLEAN")))
        {
            code.add("mtc1 $s0, $f0");
            code.add("cvt.s.w $f0, $f0");
            code.add("s.s $f0, 0($s2)");
        }
        else if(var.getType().equals("INT") && (type.equals("INT") || type.equals("BOOLEAN")))
            code.add("sw $s0, 0($s2)");
        else if(var.getType().equals("BOOLEAN") && type.equals("BOOLEAN"))
            code.add("sw $s0, 0($s2)");
        else
            ErrorLog.log(type + " can't be stored in " + var.getType(), node.getId().getLine());
    }
    ///////////////////////////////////////////////////////////////HERE
    public void caseASwitchstmtStmt(ASwitchstmtStmt node)
    {
        inASwitchstmtStmt(node);
        
        String endLabel = "endswitch_" + getLabel();
        String fallLabel = "fallthrough_" + getLabel() + '_';
        String caseLabel = "case_" + getLabel() + '_';
        int counter = 0;
        String type;
        
        node.getLogicalexpr().apply(this);
        type = typeStack.pop();
        popRegister(0, type);
        if(!type.equals("INT") && !type.equals("BOOLEAN"))
            ErrorLog.log("Can't switch on a " + type, node.getSwitch().getLine());
        
        List<PSwitchcase> copy1 = new ArrayList<>(node.getSwitchcase());
        for(PSwitchcase e : copy1)
        {
            pushRegister(0, type);
            typeStack.push(endLabel);
            
            typeStack.push(fallLabel + counter);
            typeStack.push(caseLabel + counter);
            counter++;
            typeStack.push(fallLabel + counter);
            typeStack.push(caseLabel + counter);
            e.apply(this);
        }
        
        code.add(caseLabel + counter + ':');
        code.add(fallLabel + counter + ':');
        
        List<PStmt> copy2 = new ArrayList<>(node.getStmt());
        for(PStmt e : copy2)
            e.apply(this);
        
        code.add(endLabel + ':');
        
        outASwitchstmtStmt(node);
    }
    
    public void caseASwitchcase(ASwitchcase node)
    {
        String nextcaseLabel = typeStack.pop();
        String nextfallLabel = typeStack.pop();
        String mycaseLabel = typeStack.pop();
        String myfallLabel = typeStack.pop();
        String endLabel = typeStack.pop();
        typeStack.pop();
        popRegister(0, "INT");
        
        code.add(mycaseLabel + ':');
        code.add("li $s1, " + node.getInt().getText());
        code.add("bne $s0, $s1, " + nextcaseLabel);
        code.add(myfallLabel + ':');
        
        List<PStmt> copy = new ArrayList<>(node.getStmt());
        for(PStmt e : copy)
            e.apply(this);
        
        if(node.getSwitchbreak() != null)
            code.add("b " + endLabel);
        else
            code.add("b " + nextfallLabel);
    }
}