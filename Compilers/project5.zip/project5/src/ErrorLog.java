package Compiler;

/**
 * @author Christian
 * @version 2018.4.18
 */

import java.util.ArrayList;

public class ErrorLog
{
    private static ArrayList<String> log = new ArrayList<>();
    
    public static void log(String message, int lineNumber)
    {
        log.add(message + " : line " + lineNumber);
    }
    
    public static void log(String message)
    {
        log.add(message);
    }
    
    public static boolean isEmpty()
    {
        return log.isEmpty();
    }
    
    public static void printLog()
    {
        for(String message : log)
            System.console().writer().println(message);
    }
}
