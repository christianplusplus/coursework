package Compiler;

/**
 * @author Christian
 * @version 2018.4.18
 */

import java.util.*;

public class Closure
{
    private Closure parent;
    private ArrayList<Closure> children;
    private HashSet<String> varList;
    private int childIterator;
    
    public Closure(Closure parent)
    {
        this.parent = parent;
        children = new ArrayList<>();
        varList = new HashSet<>();
        childIterator = 0;
    }
    
    public boolean add(String var)
    {
        if(varList.contains(var))
            return false;
        varList.add(var);
        return true;
    }
    
    public Closure getParent()
    {
        return parent;
    }
    
    public Closure getNextChild()
    {
        return children.get(childIterator++);
    }
    
    public void resetIterators()
    {
        childIterator = 0;
        for(Closure child : children)
            child.resetIterators();
    }
    
    public Closure makeChild()
    {
        Closure child = new Closure(this);
        children.add(child);
        return child;
    }
    
    public boolean isInClosure(String var)
    {
        if(varList.contains(var))
            return true;
        if(parent == null)
            return false;
        return parent.isInClosure(var);
    }
    
    public String getVarId(String var)
    {
        if(varList.contains(var))
            return "V_" + getClosureAsString() + var;
        if(parent == null)
        {
            ErrorLog.log(var + " has not been declared");
            return "";
        }
        return parent.getVarId(var);
    }
    
    public String getClosureAsString()
    {
        String closure = "";
        int[] lineage = getClosureAsArray();
        for(int num : lineage)
            closure += num;
        return closure;
    }
    
    public int[] getClosureAsArray()
    {
        ArrayList<Integer> lineage = getParents(null);
        int[] lineageSequence = new int[lineage.size()];
        for(int i = 0; i < lineage.size(); i++)
            lineageSequence[i] = lineage.get(i);
        return lineageSequence;
    }
    
    private ArrayList<Integer> getParents(Closure child)
    {
        ArrayList<Integer> lineage;
        if(parent == null)
            lineage = new ArrayList<>();
        else
            lineage = parent.getParents(this);
        if(child != null)
            lineage.add(children.indexOf(child));
        return lineage;
    }
}
