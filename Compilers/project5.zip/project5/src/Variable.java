package Compiler;

/**
 * @author Christian Wendlandt
 * @version 2018.4.18
 */
public class Variable
{
    public enum Type{BOOLEAN, INT, REAL, STRING};
    private Type type;
    private String name;
    private int size;
    private int arraySize;
    private boolean stringAssigned;
    
    public Variable(Type type, String name, int arraySize)
    {
        this.type = type;
        this.name = name;
        switch(type)
        {
            case BOOLEAN:
                size = 4;
                break;
            case INT:
                size = 4;
                break;
            case REAL:
                size = 4;
                break;
            case STRING:
                size = 400;
                break;
            default:
                size = 4;
        }
        this.arraySize = arraySize;
        stringAssigned = false;
    }
    
    public String getType()
    {
        return type.toString();
    }
    
    public String getId()
    {
        return name;
    }
    
    public String getName()
    {
        return name;
    }
    
    public int getSize()
    {
        return size;
    }
    
    public int getArraySize()
    {
        return arraySize;
    }
    
    public boolean isStringAlreadyAssigned()
    {
        return stringAssigned;
    }
    
    public String memoryCode()
    {
        if(type == Type.STRING)
        {
            stringAssigned = true;
            return ": .asciiz ";
        }
        return ": .space " + size * arraySize;
    }
}
