/**
 * Creates an abstract syntax tree out of a stream of tokens.
 *
 * @author Christian Wendlandt
 * @version 2018.3.6
 */

package Project3Build;

public class Parser
{
    private StreamReader reader;
    private String token;
    private String tokenName;
    private String tokenValue;
    
    Parser()
    {
        reader = new StreamReader();
    }
	
	public String parse(String stream) throws ParseException
	{
	    reader.read(stream);
	    token = reader.next();
        tokenName = token.substring(0, token.indexOf(","));
        tokenValue = token.substring(token.indexOf(",") + 1);
		return SS();
	}
    
    private String SS() throws ParseException
    {
        switch(tokenName)
        {
            case "TId":
			case "TEcho":
				String S = S();
				if(reader.hasNext())
				{
					match("TSemicolon");
					return "new SepStmtList(new LastStmtList("+S+"), "+SS()+")";
				}
				return "new LastStmtList("+S+")";
        }
		throw new ParseException("Error: Expected id or echo. Found " +
		        tokenName.substring(1).toLowerCase() + ".");
    }
	
	private String S() throws ParseException
    {
        switch(tokenName)
        {
            case "TId":
				String id = tokenValue;
				match("TId");
				match("TAssign");
				return "new AssignStmt(\""+id+"\", "+E()+")";
			case "TEcho":
				match("TEcho");
				match("TLparen");
				String EL = EL();
				match("TRparen");
				return "new PrintStmt("+EL+")";
        }
		throw new ParseException("Error: Expected id or echo. Found " +
		        tokenName.substring(1).toLowerCase() + ".");
    }
	
	private String EL() throws ParseException
    {
        switch(tokenName)
        {
            case "TId":
			case "TNumber":
				String E = E(); 
				if(tokenName.equals("TComma"))
				{
					match("TComma");
					return "new SepExpList(new LastExpList("+E+"), "+EL()+")";
				}
				return "new LastExpList("+E+")";
        }
		throw new ParseException("Error: Expected id or number. Found " +
		        tokenName.substring(1).toLowerCase() + " instead.");
    }
	
	private String E() throws ParseException
    {
        switch(tokenName)
        {
            case "TId":
            case "TNumber":
                String T = T();
                while(tokenName.equals("TPlus") || tokenName.equals("TMinus"))
                    switch(tokenName)
                    {
                        case "TPlus":
                            match("TPlus");
                            T = "new BinOpExp("+T+", new BinOpAdd(), "+T()+")";
                            break;
                        case "TMinus":
                            match("TMinus");
                            T = "new BinOpExp("+T+", new BinOpSub(), "+T()+")";
                            break;
                    }
                return T;
        }
		throw new ParseException("Error: Expected id or number. Found " +
		        tokenName.substring(1).toLowerCase() + " instead.");
    }
    
    private String T() throws ParseException
    {
        switch(tokenName)
        {
            case "TId":
            case "TNumber":
                String F = F();
                while(tokenName.equals("TTimes") || tokenName.equals("TDiv") ||
                        tokenName.equals("TMod"))
                    switch(tokenName)
                    {
                        case "TTimes":
                            match("TTimes");
                            F = "new BinOpExp("+F+", new BinOpMult(), "+F()+")";
                            break;
                        case "TDiv":
                            match("TDiv");
                            F = "new BinOpExp("+F+", new BinOpDiv(), "+F()+")";
                            break;
                        case "TMod":
                            match("TMod");
                            F = "new BinOpExp("+F+", new BinOpMod(), "+F()+")";
                            break;
                    }
                return F;
        }
		throw new ParseException("Error: Expected id or number. Found " +
		        tokenName.substring(1).toLowerCase() + " instead.");
    }
    
    private String F() throws ParseException
    {
        switch(tokenName)
        {
            case "TId":
            case "TNumber":
                String N = N();
                while(tokenName.equals("TLshift") || tokenName.equals("TRshift"))
                    switch(tokenName)
                    {
                        case "TLshift":
                            match("TLshift");
                            N = "new UnOpExp("+N+", new UnaryOpLShift())";
                            break;
                        case "TRshift":
                            match("TRshift");
                            N = "new UnOpExp("+N+", new UnaryOpRShift())";
                            break;
                    }
                return N;
        }
		throw new ParseException("Error: Expected id or number. Found " +
		        tokenName.substring(1).toLowerCase() + " instead.");
    }
    
    private String N() throws ParseException
    {
        switch(tokenName)
        {
            case "TId":
                String id = tokenValue;
                match("TId");
                return "new IdExp(\""+id+"\")";
            case "TNumber":
                String num = tokenValue;
                match("TNumber");
                return "new NumExp("+num+")";
        }
		throw new ParseException("Error: Expected id or number. Found " +
		        tokenName.substring(1).toLowerCase() + " instead.");
    }
	
	private void match(String expectedT) throws ParseException
    {
        if(expectedT.equals(tokenName))
        {
            if(reader.hasNext())
                token = reader.next();
            else
                token = "EOL,";
            tokenName = token.substring(0, token.indexOf(","));
            tokenValue = token.substring(token.indexOf(",") + 1);
        }
        else
            throw new ParseException("Error: Expected " +
                    expectedT.substring(1).toLowerCase() + ". Found " +
                    tokenName.substring(1).toLowerCase() + " instead.");
    }
}
