/**
 * Write a description of class StreamLexer here.
 *
 * @author Christian Wendlandt
 * @version 2018.3.5
 */

package Project3Build;

public class StreamReader
{
    private String stream;
    
    StreamReader()
    {
    }
    StreamReader(String stream)
    {
        this.stream = stream;
    }
    
    public void read(String stream)
    {
        this.stream = stream;
    }
    
    public String next()
    {
        String token = "";
        int index;
        index = stream.indexOf(">");
        if(index == -1)
            return "";
        token = stream.substring(1, index);
        stream = stream.substring(index + 1);
		
        return token;
    }
	
	public boolean hasNext()
	{
		if(stream.indexOf(">") == -1)
			return false;
		return true;
	}
}
