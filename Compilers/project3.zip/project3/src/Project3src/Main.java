package Project3Build;

import Project3Build.lexer.*;
import Project3Build.node.*;
import java.io.*;

public class Main{

    public static void main(String[] args)
	{
		Lexer lexer;
		Parser parser = new Parser();
		StringBuilder tokenStream = new StringBuilder();
		PrintWriter out;
		Token token;
		String tokenName;
		String fileHeader = "package Project0Build;public class ProgExpr{private static Stmts program=";
        String fileTail = ";public static void main(String[]args){Interpreter interpreter = new Interpreter();System.out.println(\"Evaluating...\");interpreter.interpret(program);}}";
		
		try
		{
            lexer = new Lexer(
                    new PushbackReader(
                    new InputStreamReader(
                    new FileInputStream(
                    new File(args[0])))));
			
            token = lexer.next();
            while(!token.getText().equals(""))
			{
				tokenName = token.getClass().getSimpleName();
                if(!tokenName.equals("TWhitespace") && !tokenName.equals("TComments"))
				{
					tokenStream.append('<');
                    tokenStream.append(tokenName);
					tokenStream.append(',');
					if(tokenName.equals("TId") || tokenName.equals("TNumber"))
						tokenStream.append(token.getText());
					tokenStream.append('>');
				}
                token = lexer.next();
            }
            out = new PrintWriter("ProgExpr.java");
			out.println(fileHeader + parser.parse(tokenStream.toString()) + fileTail);
			out.flush();
			out.close();
        }
        catch(Exception ex){System.out.println(ex);}
    }
}
