Package Project3Build;

Helpers
    digit = ['0'..'9'];
    char = [['A'..'Z'] + ['a'..'z']];
    sp = ' ';
    lf = 10;
    cr = 13;
    any = [0..0xFFFF];
    eol = cr lf | cr | lf;
    any_but_eol = [any - [cr + lf]];
Tokens
	assign = '<--';
	echo = 'echo';
	semicolon = ';';
	comma = ',';
	lparen = '(';
	rparen = ')';
	lshift = '<<';
	rshift = '>>';
	plus = '+';
	minus = '-';
	times = '*';
	div = '/';
	mod = '%';
	number = digit+;
	id = char+;
	comments = '//' any_but_eol* eol;
	whitespace = (sp|lf|cr)+;
Ignored Tokens
    whitespace,
    comments;
