package Project0Build;

/**
 * @author Christian Wendlandt
 * @version 2018.2.12
 */

public class ProgramThree
{
    private static Stmts program = new SepStmtList(
        new LastStmtList(
            new AssignStmt(
                "four",
                new BinOpExp(
                    new NumExp(5),
                    new BinOpAdd(),
                    new NumExp(10)
                )
            )
        ),
        new SepStmtList(
            new LastStmtList(
                new AssignStmt(
                    "five",
                    new BinOpExp(
                        new NumExp(10),
                        new BinOpDiv(),
                        new NumExp(3)
                    )
                )
            ),
            new SepStmtList(
                new LastStmtList(
                    new PrintStmt(
                        new SepExpList(
                            new LastExpList(
                                new IdExp("four")
                            ),
                            new LastExpList(
                                new IdExp("five")
                            )
                        )
                    )
                ),
                new SepStmtList(
                    new LastStmtList(
                        new AssignStmt(
                            "four",
                            new UnOpExp(
                                new IdExp("four"),
                                new UnaryOpRShift()
                            )
                        )
                    ),
                    new SepStmtList(
                        new LastStmtList(
                            new PrintStmt(
                                new LastExpList(
                                    new IdExp("four")
                                )
                            )
                        ),
                        new SepStmtList(
                            new LastStmtList(
                                new AssignStmt(
                                    "five",
                                    new UnOpExp(
		                                new BinOpExp(
		                                    new UnOpExp(
		                                        new IdExp("four"),
		                                        new UnaryOpLShift()
		                                    ),
		                                    new BinOpDiv(),
		                                    new IdExp("four")
		                                ),
		                                new UnaryOpRShift()
                                    )
                                )
                            ),
                            new LastStmtList(
                                new PrintStmt(
                                    new SepExpList(
                                        new LastExpList(
                                            new IdExp("four")
                                        ),
                                        new LastExpList(
                                            new IdExp("five")
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            )
        )
    );
    
    public static void main(String[] args)
    {
        Interpreter interpreter = new Interpreter();
        System.out.println("Evaluating...");
        interpreter.interpret(program);
    }
}
