package Project0Build;

/**
 * @author Christian Wendlandt
 * @version 2018.2.12
 */

public class ProgramTwo
{
    private static Stmts program = new SepStmtList(
        new LastStmtList(
            new AssignStmt(
                "two",
                new BinOpExp(
                    new BinOpExp(
                        new NumExp(20),
                        new BinOpSub(),
                        new NumExp(10)
                    ),
                    new BinOpMult(),
                    new NumExp(5)
                )
            )
        ),
        new SepStmtList(
            new LastStmtList(
                new AssignStmt(
                    "three",
                    new BinOpExp(
                        new BinOpExp(
                            new IdExp("two"),
                            new BinOpMod(),
                            new NumExp(4)
                        ),
                        new BinOpAdd(),
                        new NumExp(6)
                    )
                )
            ),
            new LastStmtList(
                new PrintStmt(
                    new SepExpList(
                        new LastExpList(
                            new IdExp("two")
                        ),
                        new LastExpList(
                            new IdExp("three")
                        )
                    )
                )
            )
        )
    );
    
    public static void main(String[] args)
    {
        Interpreter interpreter = new Interpreter();
        System.out.println("Evaluating...");
        interpreter.interpret(program);
    }
}
