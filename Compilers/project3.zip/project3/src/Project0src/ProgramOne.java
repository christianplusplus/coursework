package Project0Build;

/**
 * @author Christian Wendlandt
 * @version 2018.2.12
 */

public class ProgramOne
{
    private static Stmts program =
        new SepStmtList(
            new LastStmtList(
                new AssignStmt(
                    "one",
                    new NumExp(30)
                )
            ),
            new LastStmtList(
                new PrintStmt(
                    new LastExpList(
                        new IdExp("one")
                    )
                )
            )
        );
    
    public static void main(String[] args)
    {
        Interpreter interpreter = new Interpreter();
        System.out.println("Evaluating...");
        interpreter.interpret(program);
    }
}
