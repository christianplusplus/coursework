package Project0Build;

/*
	You will need to add many more classes to this file to get the interpreter 
	to work. The pattern shown below for the simple example should be enough 
	to show you what to do for the remaining classes.
*/

//<Stmts> ::= <Stmt> ; <Stmts> | <Stmt>
abstract class Stmts{}

//<Stmts> ::= <Stmt> ; <Stmts>
class SepStmtList extends Stmts
{
    public LastStmtList stmt;
    public Stmts stmts;
    public SepStmtList(LastStmtList stmt, Stmts stmts)
    {
        this.stmt = stmt;
        this.stmts = stmts;
    }
}

//<Stmts> ::= <Stmt>
class LastStmtList extends Stmts
{
    public Stmt stmt;
    public LastStmtList(Stmt stmt)
    {
        this.stmt = stmt;
    }
}

//<Stmt> ::= <id> <-- <Expression> | echo ( <ExpList> )
abstract class Stmt{}

//<Stmt> ::= <id> <-- <Expression>
class AssignStmt extends Stmt
{
    public String id;
    public Expression expression;
    public AssignStmt(String id, Expression expression)
    {
        this.id = id;
        this.expression = expression;
    }
}

//<Stmt> ::= echo ( <ExpList> )
class PrintStmt extends Stmt
{
    public ExpList expList;
    public PrintStmt(ExpList expList)
    {
        this.expList = expList;
    }
}

//<Expression> ::= <id> | <number> | <Expression> <BinOp> <Expression> | <Expression> <UnaryOp>
abstract class Expression{}

//<Expression> ::= <id>
class IdExp extends Expression
{
    public String id;
    public IdExp(String id)
    {
        this.id = id;
    }
}

//<Expression> ::= <number>
class NumExp extends Expression
{
    public int num;
    public NumExp(int num)
    {
        this.num = num;
    }
}

//<Expression> ::= <Expression> <BinOp> <Expression>
class BinOpExp extends Expression
{
    public Expression expression1;
    public BinOp binOp;
    public Expression expression2;
    public BinOpExp(Expression expression1, BinOp binOp, Expression expression2)
    {
        this.expression1 = expression1;
        this.binOp = binOp;
        this.expression2 = expression2;
    }
}

//<Expression> ::= <Expression> <UnaryOp>
class UnOpExp extends Expression
{
    public Expression expression;
    public UnaryOp unaryOp;
    public UnOpExp(Expression expression, UnaryOp unaryOp)
    {
        this.expression = expression;
        this.unaryOp = unaryOp;
    }
}

//<ExpList> ::= <Expression> , <ExpList> | <Expression>
abstract class ExpList{}

//<ExpList> ::= <Expression> , <ExpList>
class SepExpList extends ExpList
{
    public LastExpList expression;
    public ExpList expList;
    public SepExpList(LastExpList expression, ExpList expList)
    {
        this.expression = expression;
        this.expList = expList;
    }
}

//<ExpList> ::= <Expression>
class LastExpList extends ExpList
{
    public Expression expression;
    public LastExpList(Expression expression)
    {
        this.expression = expression;
    }
}

//<BinOp> ::= + | - | * | / | %
abstract class BinOp{}

//<BinOp> ::= +
class BinOpAdd extends BinOp{}

//<BinOp> ::= -
class BinOpSub extends BinOp{}

//<BinOp> ::= *
class BinOpMult extends BinOp{}

//<BinOp> ::= /
class BinOpDiv extends BinOp{}

//<BinOp> ::= %
class BinOpMod extends BinOp{}

//<UnaryOp> ::= << | >>
abstract class UnaryOp{}

//<UnaryOp> ::= <<
class UnaryOpLShift extends UnaryOp{}

//<UnaryOp> ::= >>
class UnaryOpRShift extends UnaryOp{}
