/**
 * DFA for TStatic.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TStatic extends DFA
{
    public TStatic()
    {
        code = "<TStatic>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                if(character == 's')
                {
                    state = 1;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 1:
                if(character == 't')
                {
                    state = 2;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 2:
                if(character == 'a')
                {
                    state = 3;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 3:
                if(character == 't')
                {
                    state = 4;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 4:
                if(character == 'i')
                {
                    state = 5;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 5:
                state = -1;
                if(character == 'c')
                    return DFAManager.ACCEPT;
        }
        return DFAManager.REJECT;
    }
}
