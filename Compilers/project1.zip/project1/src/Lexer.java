/**
 * Driver for Lexical Analyzer.
 * 
 * @author Christian Wendlandt
 * @version 2018.2.13
 */

package LexicalAnalyzer;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Lexer
{
    public static void main(String[] args)
    {
        InputStreamReader input;
        int character;
        DFAManager dfa;
        
        try
        {
            input = new InputStreamReader(new FileInputStream(new File(args[0])));
            dfa = new DFAManager(args[1]);
            while((character = input.read()) != -1)
                dfa.offer((char)character);
            dfa.offer((char)26);
            dfa.flush();
        }
        catch(FileNotFoundException ex)
        {
            System.out.println(args[0] + " not found.");
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }
    }
}