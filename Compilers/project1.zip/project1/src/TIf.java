/**
 * DFA for TIf.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TIf extends DFA
{
    public TIf()
    {
        code = "<TIf>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                if(character == 'i')
                {
                    state = 1;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 1:
                state = -1;
                if(character == 'f')
                    return DFAManager.ACCEPT;
        }
        return DFAManager.REJECT;
    }
}
