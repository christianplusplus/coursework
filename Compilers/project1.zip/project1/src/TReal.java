/**
 * DFA for TReal.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TReal extends DFA
{
    public TReal()
    {
        code = "<TReal>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                if(Character.isDigit(character))
                {
                    state = 1;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 1:
                if(Character.isDigit(character))
                    return DFAManager.OK;
                if(character == '.')
                {
                    state = 2;
                    return DFAManager.ACCEPT;
                }
                state = -1;
                break;
            case 2:
                if(Character.isDigit(character))
                    return DFAManager.ACCEPT;
                state = -1;
        }
        return DFAManager.REJECT;
    }
}
