/**
 * DFA for TPeriod.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TPeriod extends DFA
{
    public TPeriod()
    {
        code = "<TPeriod>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                state = -1;
                if(character == '.')
                    return DFAManager.ACCEPT;
        }
        return DFAManager.REJECT;
    }
}
