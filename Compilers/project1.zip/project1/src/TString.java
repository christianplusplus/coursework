/**
 * DFA for TString.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TString extends DFA
{
    public TString()
    {
        code = "<TString>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                if(character == 'S')
                {
                    state = 1;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 1:
                if(character == 't')
                {
                    state = 2;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 2:
                if(character == 'r')
                {
                    state = 3;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 3:
                if(character == 'i')
                {
                    state = 4;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 4:
                if(character == 'n')
                {
                    state = 5;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 5:
                state = -1;
                if(character == 'g')
                    return DFAManager.ACCEPT;
        }
        return DFAManager.REJECT;
    }
}
