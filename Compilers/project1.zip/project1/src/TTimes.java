/**
 * DFA for TTimes.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;
 
public class TTimes extends DFA
{
    public TTimes()
    {
        code = "<TTimes>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                state = -1;
                if(character == '*')
                    return DFAManager.ACCEPT;
        }
        return DFAManager.REJECT;
    }
}
