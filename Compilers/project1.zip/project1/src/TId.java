/**
 * DFA for TId.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TId extends DFA
{
    public TId()
    {
        code = "<TId>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                if(Character.isLetter(character))
                {
                    state = 1;
                    return DFAManager.ACCEPT;
                }
                state = -1;
                break;
            case 1:
                if(Character.isLetterOrDigit(character) ||
                        character == '_')
                    return DFAManager.ACCEPT;
                state = -1;
        }
        return DFAManager.REJECT;
    }
}