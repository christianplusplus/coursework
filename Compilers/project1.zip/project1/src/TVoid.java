/**
 * DFA for TVoid.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TVoid extends DFA
{
    public TVoid()
    {
        code = "<TVoid>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                if(character == 'v')
                {
                    state = 1;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 1:
                if(character == 'o')
                {
                    state = 2;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 2:
                if(character == 'i')
                {
                    state = 3;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 3:
                state = -1;
                if(character == 'd')
                    return DFAManager.ACCEPT;
        }
        return DFAManager.REJECT;
    }
}
