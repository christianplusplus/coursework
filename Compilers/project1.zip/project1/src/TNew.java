/**
 * DFA for TNew.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TNew extends DFA
{
    public TNew()
    {
        code = "<TNew>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                if(character == 'n')
                {
                    state = 1;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 1:
                if(character == 'e')
                {
                    state = 2;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 2:
                state = -1;
                if(character == 'w')
                    return DFAManager.ACCEPT;
        }
        return DFAManager.REJECT;
    }
}
