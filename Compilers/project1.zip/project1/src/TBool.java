/**
 * DFA for TBool.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TBool extends DFA
{
    public TBool()
    {
        code = "<TBool>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                if(character == 'b')
                {
                    state = 1;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 1:
                if(character == 'o')
                {
                    state = 2;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 2:
                if(character == 'o')
                {
                    state = 3;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 3:
                if(character == 'l')
                {
                    state = 4;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 4:
                if(character == 'e')
                {
                    state = 5;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 5:
                if(character == 'a')
                {
                    state = 6;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 6:
                state = -1;
                if(character == 'n')
                    return DFAManager.ACCEPT;
        }
        return DFAManager.REJECT;
    }
}
