/**
 * DFA for TMain.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TMain extends DFA
{
    public TMain()
    {
        code = "<TMain>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                if(character == 'm')
                {
                    state = 1;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 1:
                if(character == 'a')
                {
                    state = 2;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 2:
                if(character == 'i')
                {
                    state = 3;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 3:
                state = -1;
                if(character == 'n')
                    return DFAManager.ACCEPT;
        }
        return DFAManager.REJECT;
    }
}
