/**
 * Write a description of class DFA here.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;
import java.io.*;
import java.util.LinkedList;
import java.util.Arrays;

public class DFAManager
{
    public final String NOTOKEN = "<noSuchToken>";
    public final String COMMENT = "<Tcomment>";
    public static final int OK = 0;
    public static final int ACCEPT = 1;
    public static final int REJECT = 2;
    private PrintWriter output;
    private LinkedList<DFA> validDFAs;
    private String token;
    
    public DFAManager(String outputFileName) throws IOException
    {
        output = new PrintWriter(new File(outputFileName));
        reset();
    }
    
    public void offer(char character)
    {
        int response;
        
        do
        {
            LinkedList<DFA> newList = new LinkedList<>();
            for(DFA dfa: validDFAs)
            {
                response = dfa.offer(character);
                if(response == OK)
                    newList.add(dfa);
                else if(response == ACCEPT)
                {
                    newList.add(dfa);
                    token = dfa.getCode();
                }
                //else if(response == REJECT) do nothing;
            }
            validDFAs = newList;
            if(!validDFAs.isEmpty())
                return;
            if(token.equals(NOTOKEN))
            {
                reset();
                return;
            }
            else
            {
                output.write(token);
                reset();
            }
        }while(true);
    }
    
    public void flush()
    {
        output.flush();
        output.close();
    }
    
    private void reset()
    {
        validDFAs = new LinkedList<>();
        validDFAs.add(new TComments());
        validDFAs.add(new TId());
        validDFAs.add(new TNumber());
        validDFAs.add(new TReal());
        validDFAs.add(new TLbracket());
        validDFAs.add(new TLcurly());
        validDFAs.add(new TLparen());
        validDFAs.add(new TRbracket());
        validDFAs.add(new TRcurly());
        validDFAs.add(new TRparen());
        validDFAs.add(new TAnd());
        validDFAs.add(new TComma());
        validDFAs.add(new TEqual());
        validDFAs.add(new TLt());
        validDFAs.add(new TMinus());
        validDFAs.add(new TExc());
        validDFAs.add(new TPeriod());
        validDFAs.add(new TPlus());
        validDFAs.add(new TSemicolon());
        validDFAs.add(new TTimes());
        validDFAs.add(new TString());
        validDFAs.add(new TPrint());
        validDFAs.add(new TBool());
        validDFAs.add(new TClass());
        validDFAs.add(new TElse());
        validDFAs.add(new TExtends());
        validDFAs.add(new TFalse());
        validDFAs.add(new TIf());
        validDFAs.add(new TInt());
        validDFAs.add(new TLength());
        validDFAs.add(new TMain());
        validDFAs.add(new TNew());
        validDFAs.add(new TPublic());
        validDFAs.add(new TReturn());
        validDFAs.add(new TStatic());
        validDFAs.add(new TThis());
        validDFAs.add(new TTrue());
        validDFAs.add(new TVoid());
        validDFAs.add(new TWhile());
        token = NOTOKEN;
    }
}