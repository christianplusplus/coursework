/**
 * DFA for TExtends.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TExtends extends DFA
{
    public TExtends()
    {
        code = "<TExtends>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                if(character == 'e')
                {
                    state = 1;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 1:
                if(character == 'x')
                {
                    state = 2;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 2:
                if(character == 't')
                {
                    state = 3;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 3:
                if(character == 'e')
                {
                    state = 4;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 4:
                if(character == 'n')
                {
                    state = 5;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 5:
                if(character == 'd')
                {
                    state = 6;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 6:
                state = -1;
                if(character == 's')
                    return DFAManager.ACCEPT;
        }
        return DFAManager.REJECT;
    }
}
