/**
 * DFA for TLt.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TLt extends DFA
{
    public TLt()
    {
        code = "<TLt>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                state = -1;
                if(character == '<')
                    return DFAManager.ACCEPT;
        }
        return DFAManager.REJECT;
    }
}
