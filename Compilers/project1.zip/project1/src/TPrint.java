/**
 * DFA for TPrint.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TPrint extends DFA
{
    public TPrint()
    {
        code = "<TPrint>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                if(character == 'S')
                {
                    state = 1;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 1:
                if(character == 'y')
                {
                    state = 2;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 2:
                if(character == 's')
                {
                    state = 3;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 3:
                if(character == 't')
                {
                    state = 4;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 4:
                if(character == 'e')
                {
                    state = 5;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 5:
                if(character == 'm')
                {
                    state = 6;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 6:
                if(character == '.')
                {
                    state = 7;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 7:
                if(character == 'o')
                {
                    state = 8;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 8:
                if(character == 'u')
                {
                    state = 9;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 9:
                if(character == 't')
                {
                    state = 10;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 10:
                if(character == '.')
                {
                    state = 11;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 11:
                if(character == 'p')
                {
                    state = 12;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 12:
                if(character == 'r')
                {
                    state = 13;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 13:
                if(character == 'i')
                {
                    state = 14;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 14:
                if(character == 'n')
                {
                    state = 15;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 15:
                if(character == 't')
                {
                    state = 16;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 16:
                if(character == 'l')
                {
                    state = 17;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 17:
                state = -1;
                if(character == 'n')
                    return DFAManager.ACCEPT;
        }
        return DFAManager.REJECT;
    }
}
