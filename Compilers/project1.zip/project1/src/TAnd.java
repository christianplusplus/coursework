/**
 * DFA for TAnd.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TAnd extends DFA
{
    public TAnd()
    {
        code = "<TAnd>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                if(character == '&')
                {
                    state = 1;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 1:
                state = -1;
                if(character == '&')
                    return DFAManager.ACCEPT;
        }
        return DFAManager.REJECT;
    }
}
