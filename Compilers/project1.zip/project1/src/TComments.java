/**
 * DFA for TComments.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TComments extends DFA
{
    public TComments()
    {
        code = "<TComments>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                if(character == '/')
                {
                    state = 1;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 1:
                if(character == '/')
                {
                    state = 2;
                    return DFAManager.OK;
                }
                if(character == '*')
                {
                    state = 3;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 2:
                if(character == '\n' || character == '\r')
                {
                    state = -1;
                    return DFAManager.ACCEPT;
                }
                return DFAManager.OK;
            case 3:
                if(character == '*')
                {
                    state = 4;
                    return DFAManager.OK;
                }
                return DFAManager.OK;
            case 4:
                if(character == '/')
                {
                    state = -1;
                    return DFAManager.ACCEPT;
                }
                state = 3;
                return DFAManager.OK;
        }
        return DFAManager.REJECT;
    }
}