/**
 * DFA for TNumber.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TNumber extends DFA
{
    public TNumber()
    {
        code = "<TNumber>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                if(Character.isDigit(character))
                    return DFAManager.ACCEPT;
                state = -1;
        }
        return DFAManager.REJECT;
    }
}