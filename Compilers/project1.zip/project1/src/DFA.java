/**
 * Abstract class DFA - write a description of the class here
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */
 
package LexicalAnalyzer;
 
public abstract class DFA
{
    public String code;
    public int state = 0;
    
    abstract public int offer(char character);
    
    public String getCode()
    {
        return code;
    }
}