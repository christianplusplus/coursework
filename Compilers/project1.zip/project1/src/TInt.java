/**
 * DFA for TInt.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TInt extends DFA
{
    public TInt()
    {
        code = "<TInt>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                if(character == 'i')
                {
                    state = 1;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 1:
                if(character == 'n')
                {
                    state = 2;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 2:
                state = -1;
                if(character == 't')
                    return DFAManager.ACCEPT;
        }
        return DFAManager.REJECT;
    }
}
