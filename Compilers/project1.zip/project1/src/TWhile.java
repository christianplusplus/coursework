/**
 * DFA for TWhile.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TWhile extends DFA
{
    public TWhile()
    {
        code = "<TWhile>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                if(character == 'w')
                {
                    state = 1;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 1:
                if(character == 'h')
                {
                    state = 2;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 2:
                if(character == 'i')
                {
                    state = 3;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 3:
                if(character == 'l')
                {
                    state = 4;
                    return DFAManager.OK;
                }
                state = -1;
                break;
            case 4:
                state = -1;
                if(character == 'e')
                    return DFAManager.ACCEPT;
        }
        return DFAManager.REJECT;
    }
}
