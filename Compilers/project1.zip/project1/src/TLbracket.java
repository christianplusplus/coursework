/**
 * DFA for TLbracket.
 *
 * @author Christian Wendlandt
 * @version 2018.2.16
 */

package LexicalAnalyzer;

public class TLbracket extends DFA
{
    public TLbracket()
    {
        code = "<TLbracket>";
    }

    public int offer(char character)
    {
        switch(state)
        {
            case 0:
                state = -1;
                if(character == '[')
                    return DFAManager.ACCEPT;
        }
        return DFAManager.REJECT;
    }
}
