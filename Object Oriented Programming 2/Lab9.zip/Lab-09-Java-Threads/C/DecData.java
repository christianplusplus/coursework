/**
 * thread class to decrement data
 * 
 * @author (George) 
 * @version (January 09)
 */
public class DecData implements Runnable
{
    private Data d ;
    private int times ;

    /**
     * Constructor for objects of class IncData
     */
    public DecData(Data nD, int t)
    {
        d = nD;
        times = t ;
    }

    public void run()
    {
        for(int i = 0 ; i < times ; i++)
        {
            d.decX() ;

            try {
                Thread.sleep(1000);
//               Thread.yield(); 
            } catch (Exception ex) {}

            System.out.println("Thread decremented") ;
        }
        System.out.println("Decrement thread executed " + times + " times") ;
    }
}