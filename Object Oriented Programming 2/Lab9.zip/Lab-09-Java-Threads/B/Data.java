
/**
 * Data class for thread example
 * 
 * @author (George) 
 * @version (Version 1, January 09)
 */
public class Data
{   private int x;

    public Data()
    {       x = 0;
    }

    public synchronized void incX()
    {       
        int tmp ;
        tmp = x ;
        tmp++ ;
        

        try {
                Thread.sleep(1000);

        } catch (Exception ex) {}   
        
        x = tmp ;
    }
    public synchronized void decX()
    {       
        int tmp ;
        tmp = x ;
        tmp-- ;
        

        try {
                Thread.sleep(1000);

        } catch (Exception ex) {}      
        
        x = tmp ;
    }
    public int getX()
    {
        return x ;
    }
}
