
/**
 * Data class for thread example
 * 
 * @author (George) 
 * @version (Version 1, January 09)
 */
public class Data
{   private int x;

    public Data()
    {       x = 0;
    }

    public void incX()
    {       
        int tmp ;
        tmp = x ;
        tmp++ ;
        
        try {
                Thread.sleep(1000);
//            Thread.yield(); 
        } catch (Exception ex) {}   
        
        x = tmp ;
    }
    public void decX()
    {       
        int tmp ;
        tmp = x ;
        tmp-- ;
        
        try {
                Thread.sleep(1000);
//            Thread.yield(); 
        } catch (Exception ex) {}      
        
        x = tmp ;
    }
    public int getX()
    {
        return x ;
    }
}
