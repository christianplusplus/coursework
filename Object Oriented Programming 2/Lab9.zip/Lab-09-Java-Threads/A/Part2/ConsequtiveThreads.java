
/**
 * Write a description of class ConsequtiveThreads here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ConsequtiveThreads
{
	public static void main(String[] args) throws Exception
	{
		int t = 10 ;
		
		Data d = new Data();
		IncData tr1 = new IncData(d, t);
		DecData tr2 = new DecData(d, t) ;
		
		tr1.start();
		

		tr2.start();
		
		tr1.join() ;
		tr2.join() ;
		
		System.out.println("data = " + d.getX()) ;		
	}
}
