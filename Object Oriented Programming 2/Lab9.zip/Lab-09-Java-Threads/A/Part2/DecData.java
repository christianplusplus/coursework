/**
 * thread class to decrement data
 * 
 * @author (George) 
 * @version (January 06)
 */
public class DecData extends Thread
{
    private Data d ;
    private int times ;

    /**
     * Constructor for objects of class IncData
     */
    public DecData(Data nD, int t)
    {
        d = nD;
        times = t ;
    }

    public void run()
    {   int temp ;
        for(int i = 0 ; i < times ; i++)
        {
            temp = d.getX() ;
            temp--;
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {}
            d.setX(temp);
            System.out.println("Thread decremented") ;
        }
        System.out.println("Decrement thread executed " + times + " times") ;
    }
}