
/**
 * Data class for thread example
 * 
 * @author (George) 
 * @version (Version 1, January 06)
 */
public class Data
{	private int x;

	public Data()
	{		x = 0;
	}

	public int getX()
	{		return x ;
	}
	public void setX(int nX)
	{	    x = nX ;
	}
}
