
/**
 * Write a description of class ConcurentThreads here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ConcurentThreads
{
    public static void main(String[] args) throws Exception
    {
        int t = 10 ;
        
        Data d = new Data();
        IncData iD = new IncData(d, t);
        DecData dD = new DecData(d, t) ;
        
        Thread tr1 = new Thread(iD) ;
        Thread tr2 = new Thread(dD) ;
        
        tr1.start();
        tr2.start();
    
//        tr1.interrupt() ;
        
        tr1.join() ;        
        tr2.join() ;
        
        System.out.println("data = " + d.getX()) ;      
    }
}
