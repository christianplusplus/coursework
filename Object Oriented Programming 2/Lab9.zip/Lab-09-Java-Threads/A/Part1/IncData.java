/**
 * thread class to increment data
 * 
 * @author (George) 
 * @version (January 09)
 */
public class IncData implements Runnable
{
    private Data d ;
    private int times ;

    /**
     * Constructor for objects of class IncData
     */
    public IncData(Data nD, int t)
    {
        d = nD;
        times = t ;
    }

    public void run()
    {   int temp ;
        for(int i = 0 ; i < times ; i++)
        {
            d.incX() ;

            try {
                Thread.sleep(1000);
            } catch (Exception ex) {}

            System.out.println("Thread incremented") ;
        }
        System.out.println("Increment thread executed " + times + " times" ); 
    }
}
