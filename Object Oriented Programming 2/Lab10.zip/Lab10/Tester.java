/**
 * Tester for DataSetFileIO<E>.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/18/17)
 */
import java.io.FileNotFoundException;
public class Tester
{
    public static void main(String[] args)
    {
        String fileName1 = "cool_double_file.txt";
        String fileName2 = "cool_integer_file.txt";
        DataSetFileIO<Double> doubleSet1 = new DataSetFileIO<>();
        DataSetFileIO<Double> doubleSet2 = new DataSetFileIO<>();
        DataSetFileIO<Integer> integerSet1 = new DataSetFileIO<>();
        DataSetFileIO<Integer> integerSet2 = new DataSetFileIO<>();
        
        try
        {
            doubleSet1.add(4.5);
            doubleSet1.add(4./3);
            doubleSet1.add(0.);
            doubleSet1.writeToFile(fileName1);
            doubleSet2.readFromFile(fileName1);
            System.out.println(doubleSet2.toString());
            
            integerSet1.add(8);
            integerSet1.add(10);
            integerSet1.add(3);
            integerSet1.writeToFile(fileName2);
            integerSet2.readFromFile(fileName2);
            System.out.println(integerSet2.toString());
        }
        catch(FileNotFoundException ex){}
    }
}