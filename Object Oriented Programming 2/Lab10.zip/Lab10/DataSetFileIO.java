/**
 * Produces a set of Numbers with regular and IO methods to manipulate data.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/18/17)
 */
import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
public class DataSetFileIO<E extends Number> extends DataSet<E>
{
    public boolean readFromFile(String fileName) throws FileNotFoundException
    {
        File inFile;
        Scanner input;
        String line;
        Number num;
        
        inFile = new File(fileName);
        input = new Scanner(inFile);
        while(input.hasNext())
        {
            line = input.next();
            num = Double.parseDouble(line);
            add((E)num);
        }
        input.close();
        
        return true;
    }
    
    public boolean writeToFile(String fileName) throws FileNotFoundException
    {
        File outFile;
        PrintWriter output;
        if(count > 0)
        {
            outFile = new File(fileName);
            output = new PrintWriter(outFile);
            for(int i = 0; i < count; i++)
            {
                output.println(get(i));
            }
            output.close();
        }
        
        return true;
    }
}