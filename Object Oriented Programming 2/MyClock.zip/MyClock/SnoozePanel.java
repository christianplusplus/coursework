/**
 * Provides snooze options GUI.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/25/17)
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.* ;
import javax.sound.sampled.*;
import java.net.URL;
public class SnoozePanel extends JFrame
{
    private SnoozePanel thisPanel;
    private AlarmPanel parent;
    private JTextField minuteTextField;
    private JButton upUp;
    private JButton downDown;
    private JButton up;
    private JButton down;
    private JButton snooze;
    private JButton wakeUp;
    private Clip clip;
    private final int MINUTES_IN_AN_HOUR_OR_SECONDS_IN_A_MINUTE = 60;
    
    public SnoozePanel(AlarmPanel parent)
    {
        super("Snooze Button");
        thisPanel = this;
        this.parent = parent;
        
        JPanel panel = new JPanel(new GridLayout(0, 1));
        add(panel);
        
        JPanel controls = new JPanel();
        minuteTextField = new JTextField(10);
        minuteTextField.setText("5:00 min");
        minuteTextField.setEditable(false);
        JPanel grid = new JPanel(new GridLayout(2, 2));
        controls.add(minuteTextField);
        controls.add(grid);
        panel.add(controls);
        
        upUp = new JButton("+10");
        downDown = new JButton("-10");
        up = new JButton("+1");
        down = new JButton("-1");
        grid.add(upUp);
        grid.add(downDown);
        grid.add(up);
        grid.add(down);
        
        snooze = new JButton("SNOOZE");
        panel.add(snooze);
        
        wakeUp = new JButton("WAKE UP");
        panel.add(wakeUp);
        
        EventHandler handler = new EventHandler();
        upUp.addActionListener(handler);
        downDown.addActionListener(handler);
        up.addActionListener(handler);
        down.addActionListener(handler);
        snooze.addActionListener(handler);
        wakeUp.addActionListener(handler);
        
        try
        {
            URL url = this.getClass().getClassLoader().getResource("murloc.wav");
            AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);
            clip = AudioSystem.getClip();
            clip.open(audioIn);
            clip.loop(Clip.LOOP_CONTINUOUSLY);
            clip.start();
        }
        catch(UnsupportedAudioFileException e){}
        catch(IOException e){}
        catch(LineUnavailableException e){}
        catch(IllegalArgumentException e){}
        
        setSize(300, 300);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocation(parent.getX() + parent.getWidth() / 2, parent.getY() + parent.getWidth() / 2);
    }
    
    public int getMinute()
    {
        int minute;
        String string = minuteTextField.getText();
        
        string = string.substring(0, minuteTextField.getText().indexOf(':'));
        minute = Integer.parseInt(string);
        
        return minute;
    }
    public void changeMinute(int minutes)
    {
        int minute = getMinute();
        
        minute += minutes;
        minute %= MINUTES_IN_AN_HOUR_OR_SECONDS_IN_A_MINUTE;
        if(minute < 1)
        {
            minute += MINUTES_IN_AN_HOUR_OR_SECONDS_IN_A_MINUTE;
        }
        minuteTextField.setText(String.format("%d:00 min", minute));
    }
    
    public void snooze()
    {
        clip.stop();
        parent.snooze(getMinute());
        dispose();
    }
    
    public void wakeUp()
    {
        clip.stop();
        dispose();
    }
    
    private class EventHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            if(e.getSource() == upUp)
            {
                changeMinute(10);
            }
            else if(e.getSource() == downDown)
            {
                changeMinute(-10);
            }
            else if(e.getSource() == up)
            {
                changeMinute(1);
            }
            else if(e.getSource() == down)
            {
                changeMinute(-1);
            }
            else if(e.getSource() == snooze)
            {
                snooze();
            }
            else if(e.getSource() == wakeUp)
            {
                wakeUp();
            }
        }
    }
}