/**
 * Provides controls and an interface for each alarm.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/25/17)
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class AlarmPanel extends JPanel
{
    private AlarmPanel thisPanel;
    private AlarmControl parent;
    private JTextField timeText;
    private JButton setBtn;
    private JButton removeBtn;
    private JCheckBox checkBox;
    private AlarmPanelSettings alarmSettingsFrame;
    private int weekday;
    private int hour;
    private int minute;
    private int second;
    private int meridiem;
    private boolean active;
    private final int THURSDAY = 0;
    private final int FRIDAY = 1;
    private final int SATURDAY = 2;
    private final int SUNDAY = 3;
    private final int MONDAY = 4;
    private final int TUESDAY = 5;
    private final int WEDNESDAY = 6;
    private final int AM = 0;
    private final int PM = 1;
    private final int SECONDS_IN_A_MERIDIEM = 43200;
    private final int SECONDS_IN_AN_HOUR = 3600;
    private final int SECONDS_IN_A_MINUTE = 60;
    
    public AlarmPanel(AlarmControl parent)
    {
        thisPanel = this;
        setLayout(new BorderLayout());
        this.parent = parent;
        
        timeText = new JTextField("Sunday 00:00:00 am");
        timeText.setEditable(false);
        weekday = SUNDAY;
        hour = 0;
        minute = 0;
        second = 0;
        meridiem = AM;
        active = false;
        add(timeText, BorderLayout.CENTER);
        
        JPanel eastSide = new JPanel();
        add(eastSide, BorderLayout.EAST);
        
        setBtn = new JButton("SET");
        eastSide.add(setBtn);
        
        removeBtn = new JButton("REMOVE");
        eastSide.add(removeBtn);
        
        checkBox = new JCheckBox();
        add(checkBox, BorderLayout.WEST);
        
        EventHandler handler = new EventHandler();
        setBtn.addActionListener(handler);
        removeBtn.addActionListener(handler);
        checkBox.addActionListener(handler);
        
        alarmSettingsFrame = new AlarmPanelSettings(this);
    }
    
    public void setWeekday(int weekday)
    {
        this.weekday = weekday;
    }
    public int getWeekday()
    {
        return weekday;
    }
    public String weekdayToString()
    {
        String string;
        
        switch(weekday)
        {
            case SUNDAY:
                string = "Sunday";
                break;
            case MONDAY:
                string = "Monday";
                break;
            case TUESDAY:
                string = "Tuesday";
                break;
            case WEDNESDAY:
                string = "Wednesday";
                break;
            case THURSDAY:
                string = "Thursday";
                break;
            case FRIDAY:
                string = "Friday";
                break;
            case SATURDAY:
                string = "Saturday";
                break;
            default:
                string = "oops!";
        }
        
        return string;
    }
    
    public void setHour(int hour)
    {
        this.hour = hour;
    }
    public int getHour()
    {
        return hour;
    }
    
    public void setMinute(int minute)
    {
        this.minute = minute;
    }
    public int getMinute()
    {
        return minute;
    }
    
    public void setSecond(int second)
    {
        this.second = second;
    }
    public int getSecond()
    {
        return second;
    }
    
    public void setMeridiem(int meridiem)
    {
        this.meridiem = meridiem;
    }
    public int getMeridiem()
    {
        return meridiem;
    }
    public String meridiemToString()
    {
        String string = meridiem == AM ? "am" : "pm";
        
        return string;
    }
    
    public boolean isActive()
    {
        return active;
    }
    
    public int getTime()
    {
        int time = meridiem * SECONDS_IN_A_MERIDIEM +
                hour * SECONDS_IN_AN_HOUR + minute * SECONDS_IN_A_MINUTE + second;
        
        return time;
    }
    
    public void updateText()
    {
        timeText.setText(String.format("%s %02d:%02d:%02d %s", weekdayToString(),
                getHour(), getMinute(), getSecond(), meridiemToString()));
    }
    
    public void wakeUp()
    {
        checkBox.setSelected(false);
        active = false;
        SnoozePanel snooze = new SnoozePanel(this);
    }
    
    public void snooze(int minutes)
    {
        int hours = (minute + minutes) / 60;
        int meridiem = (hour + hours) / 12;
        
        meridiem %= 2;
        hours %= 12;
        minutes %= 60;
        
        if(meridiem == 1)
        {
            alarmSettingsFrame.swapMeridiem();
        }
        alarmSettingsFrame.changeHour(hours);
        alarmSettingsFrame.changeMinute(minutes);
        
        alarmSettingsFrame.setAlarm();
        
        checkBox.setSelected(true);
        active = true;
    }
    
    public class EventHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            if(e.getSource() == setBtn)
            {
                alarmSettingsFrame.setLocation(parent.getX() + parent.getWidth(), parent.getY());
                alarmSettingsFrame.setVisible(true);
            }
            else if(e.getSource() == removeBtn)
            {
                alarmSettingsFrame.dispose();
                parent.removeAlarmPanel(thisPanel);
            }
            else if(e.getSource() == checkBox)
            {
                if(checkBox.isSelected())
                {
                    active = true;
                }
                else
                {
                    active = false;
                }
            }
        }
    }
}