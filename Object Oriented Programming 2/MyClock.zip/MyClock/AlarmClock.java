/**
 * Keeps track of time and offers a multitude of time retrieval methods. Also stors alarm methods.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/25/17)
 */
import java.util.Date;
import java.util.ArrayList;
public class AlarmClock extends WorldTime
{
    private ArrayList<AlarmTimer> alarmTimers;
    private static final int MILISECONDS_TO_SECONDS = 1000;
    private String cutout = " CDT";
    private final int SECONDS_IN_A_DAY = 86400;
    
    public AlarmClock()
    {
        alarmTimers = new ArrayList<AlarmTimer>();
    }
    
    public synchronized void clearAlarmTimers()
    {
        while(alarmTimers.size() > 0)
        {
            alarmTimers.remove(0);
        }
    }
    public synchronized void addAlarmTimer(int weekday, int time)
    {
        alarmTimers.add(new AlarmTimer(weekday, time));
    }
    public synchronized ArrayList<AlarmTimer> getAlarmTimers()
    {
        return alarmTimers;
    }
    
    public synchronized int getDayOfTheWeek()
    {
        int day = (int)((getLocalTime() - 21600) / SECONDS_IN_A_DAY % 7);
        
        return day;
    }
    
    @Override
    public String toString()
    {
        String string;
        String dateString;
        String firstHalf;
        String secondHalf;
        
        dateString = (new Date(getLocalTime() * MILISECONDS_TO_SECONDS)).toString();
        firstHalf = dateString.substring(0, dateString.indexOf(cutout));
        secondHalf = dateString.substring(dateString.indexOf(cutout));
        secondHalf = secondHalf.substring(cutout.length());
        string = firstHalf + secondHalf;
        
        return string;
    }
}