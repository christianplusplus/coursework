/**
 * Holds time of the week data.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/25/17)
 */
public class AlarmTimer
{
    private int weekday;
    private int time; //in seconds.
    
    public AlarmTimer(int weekday, int time)
    {
        this.weekday = weekday;
        this.time = time;
    }
    
    public int getWeekday()
    {
        return weekday;
    }
    
    public int getTime()
    {
        return time;
    }
}