/**
 * Frame for setting alarms.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/25/17)
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class AlarmPanelSettings extends JFrame
{
    private AlarmPanel parent;
    private JComboBox<String> daySelector;
    private JTextField hourTextField;
    private JButton hourUp;
    private JButton hourDown;
    private JTextField minuteTextField;
    private JButton minuteUp;
    private JButton minuteUpUp;
    private JButton minuteDown;
    private JButton minuteDownDown;
    private JTextField secondTextField;
    private JButton secondUp;
    private JButton secondUpUp;
    private JButton secondDown;
    private JButton secondDownDown;
    private JButton meridiem;
    private final int AM = 0;
    private final int PM = 1;
    private int meridiemValue;
    private JButton setBtn;
    private final int HOURS_IN_A_HALF_DAY = 12;
    private final int MINUTES_IN_AN_HOUR_OR_SECONDS_IN_A_MINUTE = 60;
    private final int THURSDAY = 0;
    private final int FRIDAY = 1;
    private final int SATURDAY = 2;
    private final int SUNDAY = 3;
    private final int MONDAY = 4;
    private final int TUESDAY = 5;
    private final int WEDNESDAY = 6;
    
    public AlarmPanelSettings(AlarmPanel parent)
    {
        super("Alarm Setter");
        this.parent = parent;
        
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        JPanel topPanel = new JPanel();
        JPanel mid1Panel = new JPanel();
        JPanel mid2Panel = new JPanel();
        JPanel bottomPanel = new JPanel();
        topPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        mid1Panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        mid2Panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        bottomPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(topPanel);
        mainPanel.add(mid1Panel);
        mainPanel.add(mid2Panel);
        mainPanel.add(bottomPanel);
        add(mainPanel);
        
        JPanel panel1 = new JPanel();
        JPanel panel2 = new JPanel();
        JPanel panel3 = new JPanel();
        JPanel panel4 = new JPanel(new GridLayout(1, 2));
        JPanel panel5 = new JPanel();
        JPanel panel6 = new JPanel();
        JPanel panel7 = new JPanel(new GridLayout(2, 2));
        JPanel panel8 = new JPanel();
        JPanel panel9 = new JPanel();
        JPanel panel10 = new JPanel(new GridLayout(2, 2));
        JPanel panel11 = new JPanel();
        JPanel panel12 = new JPanel();
        
        topPanel.add(panel1);
        mid1Panel.add(panel2);
        mid1Panel.add(panel3);
        mid1Panel.add(panel4);
        mid2Panel.add(panel5);
        mid2Panel.add(panel6);
        mid2Panel.add(panel7);
        bottomPanel.add(panel8);
        bottomPanel.add(panel9);
        bottomPanel.add(panel10);
        topPanel.add(panel11);
        topPanel.add(panel12);
        
        daySelector = new JComboBox<String>(new String[]{"Sunday", "Monday", "Tuesday",
                "Wednesday", "Thursday", "Friday", "Saturday"});
        daySelector.setSelectedIndex(0);
        panel1.add(daySelector);
        
        JLabel hourLabel = new JLabel("Hour:");
        hourTextField = new JTextField("00");
        hourTextField.setEditable(false);
        hourUp = new JButton("+1");
        hourDown = new JButton("-1");
        panel2.add(hourLabel);
        panel3.add(hourTextField);
        panel4.add(hourUp);
        panel4.add(hourDown);
        
        JLabel minuteLabel = new JLabel("Minute:");
        minuteTextField = new JTextField("00");
        minuteTextField.setEditable(false);
        minuteUpUp = new JButton("+10");
        minuteDownDown = new JButton("-10");
        minuteUp = new JButton("+1");
        minuteDown = new JButton("-1");
        panel5.add(minuteLabel);
        panel6.add(minuteTextField);
        panel7.add(minuteUpUp);
        panel7.add(minuteDownDown);
        panel7.add(minuteUp);
        panel7.add(minuteDown);
        
        JLabel secondLabel = new JLabel("Second:");
        secondTextField = new JTextField("00");
        secondTextField.setEditable(false);
        secondUpUp = new JButton("+10");
        secondDownDown = new JButton("-10");
        secondUp = new JButton("+1");
        secondDown = new JButton("-1");
        panel8.add(secondLabel);
        panel9.add(secondTextField);
        panel10.add(secondUpUp);
        panel10.add(secondDownDown);
        panel10.add(secondUp);
        panel10.add(secondDown);
        
        meridiem = new JButton("AM");
        panel11.add(meridiem);
        meridiemValue = AM;
        
        setBtn = new JButton("SET");
        panel12.add(setBtn);
        
        EventHandler handler = new EventHandler();
        daySelector.addActionListener(handler);
        hourUp.addActionListener(handler);
        hourDown.addActionListener(handler);
        minuteUpUp.addActionListener(handler);
        minuteDownDown.addActionListener(handler);
        minuteUp.addActionListener(handler);
        minuteDown.addActionListener(handler);
        secondUpUp.addActionListener(handler);
        secondDownDown.addActionListener(handler);
        secondUp.addActionListener(handler);
        secondDown.addActionListener(handler);
        meridiem.addActionListener(handler);
        setBtn.addActionListener(handler);
        
        setSize(280, 260);
        setVisible(false);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
    }
    
    public int getWeekday()
    {
        int weekday;
        
        switch((String)daySelector.getSelectedItem())
        {
            case "Sunday":
                weekday = SUNDAY;
                break;
            case "Monday":
                weekday = MONDAY;
                break;
            case "Tuesday":
                weekday = TUESDAY;
                break;
            case "Wednesday":
                weekday = WEDNESDAY;
                break;
            case "Thursday":
                weekday = THURSDAY;
                break;
            case "Friday":
                weekday = FRIDAY;
                break;
            case "Saturday":
                weekday = SATURDAY;
                break;
            default:
                weekday = -1;
        }
        
        return weekday;
    }
    
    public int getHour()
    {
        int hour = Integer.parseInt(hourTextField.getText());
        
        return hour;
    }
    public void changeHour(int hours)
    {
        int hour = getHour();
        
        hour += hours;
        hour %= HOURS_IN_A_HALF_DAY;
        if(hour < 0)
        {
            hour += HOURS_IN_A_HALF_DAY;
        }
        hourTextField.setText(String.format("%02d", hour));
    }
    
    public int getMinute()
    {
        int minute = Integer.parseInt(minuteTextField.getText());
        
        return minute;
    }
    public void changeMinute(int minutes)
    {
        int minute = getMinute();
        
        minute += minutes;
        minute %= MINUTES_IN_AN_HOUR_OR_SECONDS_IN_A_MINUTE;
        if(minute < 0)
        {
            minute += MINUTES_IN_AN_HOUR_OR_SECONDS_IN_A_MINUTE;
        }
        minuteTextField.setText(String.format("%02d", minute));
    }
    
    public int getSecond()
    {
        int second = Integer.parseInt(secondTextField.getText());
        
        return second;
    }
    public void changeSecond(int seconds)
    {
        int second = getSecond();
        
        second += seconds;
        second %= MINUTES_IN_AN_HOUR_OR_SECONDS_IN_A_MINUTE;
        if(second < 0)
        {
            second += MINUTES_IN_AN_HOUR_OR_SECONDS_IN_A_MINUTE;
        }
        secondTextField.setText(String.format("%02d", second));
    }
    
    public int getMeridiem()
    {
        return meridiemValue;
    }
    public void swapMeridiem()
    {
        if(meridiemValue == 0)
        {
            meridiemValue = 1;
            meridiem.setText("PM");
        }
        else //if(meridiemValue == 1)
        {
            meridiemValue = 0;
            meridiem.setText("AM");
        }
    }
    
    public void setAlarm()
    {
        parent.setWeekday(getWeekday());
        parent.setHour(getHour());
        parent.setMinute(getMinute());
        parent.setSecond(getSecond());
        parent.setMeridiem(getMeridiem());
        parent.updateText();
        setVisible(false);
    }
    
    private class EventHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            if(e.getSource() == hourUp)
            {
                changeHour(1);
            }
            else if(e.getSource() == hourDown)
            {
                changeHour(-1);
            }
            else if(e.getSource() == minuteUpUp)
            {
                changeMinute(10);
            }
            else if(e.getSource() == minuteDownDown)
            {
                changeMinute(-10);
            }
            else if(e.getSource() == minuteUp)
            {
                changeMinute(1);
            }
            else if(e.getSource() == minuteDown)
            {
                changeMinute(-1);
            }
            else if(e.getSource() == secondUpUp)
            {
                changeSecond(10);
            }
            else if(e.getSource() == secondDownDown)
            {
                changeSecond(-10);
            }
            else if(e.getSource() == secondUp)
            {
                changeSecond(1);
            }
            else if(e.getSource() == secondDown)
            {
                changeSecond(-1);
            }
            else if(e.getSource() == meridiem)
            {
                swapMeridiem();
            }
            else if(e.getSource() == setBtn)
            {
                setAlarm();
            }
        }
    }
}