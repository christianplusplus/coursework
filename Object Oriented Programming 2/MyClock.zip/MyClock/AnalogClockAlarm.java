/**
 * Panel for displaying an analog clock.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/25/17)
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.*;
import java.io.IOException;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;
public class AnalogClockAlarm extends JPanel
{
    private AlarmClock timekeeper;
    private ArrayList<AlarmTimer> alarmTimers;
    private String backgroundFileName = "clockBackground.png";
    private String handFileName = "hand.png";
    private String skullFileName = "skull.png";
    private String redSkullFileName = "redSkull.png";
    private BufferedImage background;
    private BufferedImage hand;
    private BufferedImage skull;
    private BufferedImage redSkull;
    private int handCenterX = 846;
    private int handCenterY = 1655;
    private int skullCenterX;
    private int skullCenterY;
    private double secondHandWidth = .2;
    private double secondHandLength = .5;
    private double minuteHandWidth = .3;
    private double minuteHandLength = .4;
    private double hourHandWidth = .4;
    private double hourHandLength = .3;
    private double skullSize = .1;
    private double skullDistance = .32;
    private final double twelveHoursInSecondsToRadians = Math.PI / 21600;
    private final int SECONDS_IN_A_MERIDIEM = 43200;
    
    public AnalogClockAlarm(AlarmClock timekeeper)
    {
        this.timekeeper = timekeeper;
        try
        {
            background = ImageIO.read(new File(backgroundFileName));
            hand = ImageIO.read(new File(handFileName));
            skull = ImageIO.read(new File(skullFileName));
            redSkull = ImageIO.read(new File(redSkullFileName));
            skullCenterX = skull.getWidth() / 2;
            skullCenterY = skull.getHeight() / 2;
        }
        catch(IOException ex){}
    }
    
    @Override
    public void paintComponent(Graphics g)
    {
        int diameter = Math.min(getWidth(), getHeight());
        int origin = diameter / 2;
        double scaleX = (double)diameter / hand.getWidth();
        double scaleY = (double)diameter / hand.getHeight();
        double scaleSkull = (double)diameter / skull.getWidth();
        alarmTimers = timekeeper.getAlarmTimers();
        
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D)g;
        
        g.drawImage(background, 0, 0, diameter, diameter, null);
        
        for(int i = 0; i < alarmTimers.size(); i++)
        {
            int time = alarmTimers.get(i).getTime() % SECONDS_IN_A_MERIDIEM;
            AffineTransform ati = new AffineTransform();
            ati.translate(origin, origin);
            ati.rotate(time * twelveHoursInSecondsToRadians);
            ati.translate(0, -skullDistance * scaleSkull * skull.getWidth());
            ati.rotate(-time * twelveHoursInSecondsToRadians);
            ati.scale(skullSize * scaleSkull, skullSize * scaleSkull);
            ati.translate(-skullCenterX, -skullCenterY);
            if(timekeeper.getDayOfTheWeek() == alarmTimers.get(i).getWeekday() &&
                    (timekeeper.getLocalTime() - 18000) % 86400 < alarmTimers.get(i).getTime())
            {
                g2d.drawImage(redSkull, ati, null);
            }
            else
            {
                g2d.drawImage(skull, ati, null);
            }
        }
        
        AffineTransform ats = new AffineTransform();
        ats.translate(origin, origin);
        ats.rotate(timekeeper.getSeconds() * twelveHoursInSecondsToRadians * 720);
        ats.scale(secondHandWidth * scaleX, secondHandLength * scaleY);
        ats.translate(-handCenterX, -handCenterY);
        g2d.drawImage(hand, ats, null);
        
        AffineTransform atm = new AffineTransform();
        atm.translate(origin, origin);
        atm.rotate(timekeeper.getSecondsForMinutes() * twelveHoursInSecondsToRadians * 12);
        atm.scale(minuteHandWidth * scaleX, minuteHandLength * scaleY);
        atm.translate(-handCenterX, -handCenterY);
        g2d.drawImage(hand, atm, null);
        
        AffineTransform ath = new AffineTransform();
        ath.translate(origin, origin);
        ath.rotate(timekeeper.getSecondsForHours() * twelveHoursInSecondsToRadians);
        ath.scale(hourHandWidth * scaleX, hourHandLength * scaleY);
        ath.translate(-handCenterX, -handCenterY);
        g2d.drawImage(hand, ath, null);
    }
}