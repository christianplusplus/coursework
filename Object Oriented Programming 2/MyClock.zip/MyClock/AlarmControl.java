/**
 * Controls various alarm clock elements.
 * 
 * @author (Chrisitan Wendlandt) 
 * @version (04/25/17)
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
public class AlarmControl extends JPanel implements Runnable
{
    private AlarmClock timekeeper;
    private AlarmControl thisPanel;
    private ArrayList<AlarmPanel> alarmPanels;
    private JButton newAlarmBtn;
    private final int MAX_ALARMS = 10;
    private final int MILLISECONDS_IN_A_SECOND = 1000;
    
    public AlarmControl(AlarmClock timekeeper)
    {
        thisPanel = this;
        this.timekeeper = timekeeper;
        setLayout(new GridLayout(MAX_ALARMS, 1));
        alarmPanels = new ArrayList<AlarmPanel>();
        
        newAlarmBtn = new JButton("NEW ALARM");
        add(newAlarmBtn);
        
        EventHandler handler = new EventHandler();
        newAlarmBtn.addActionListener(handler);
    }
    
    @Override
    public void run()
    {
        while(true)
        {
            for(int i = 0; i < alarmPanels.size(); i++)
            {
                if(alarmPanels.get(i).isActive() &&
                        (timekeeper.getLocalTime() - 18000) % 86400 ==
                        alarmPanels.get(i).getTime())
                {
                    alarmPanels.get(i).wakeUp();
                }
            }
            timekeeper.clearAlarmTimers();
            for(int i = 0; i < alarmPanels.size(); i++)
            {
                if(alarmPanels.get(i).isActive())
                {
                    timekeeper.addAlarmTimer(alarmPanels.get(i).getWeekday(),
                            alarmPanels.get(i).getTime());
                }
            }
            try
            {
                Thread.sleep(MILLISECONDS_IN_A_SECOND);
            }catch(InterruptedException ex){}
        }
    }
    
    public void removeAlarmPanel(AlarmPanel panel)
    {
        alarmPanels.remove(panel);
        revalidateAlarmPanels();
    }
    
    private void revalidateAlarmPanels()
    {
        removeAll();
        for(int i = 0; i < alarmPanels.size(); i++)
        {
            add(alarmPanels.get(i));
        }
        if(alarmPanels.size() < MAX_ALARMS)
        {
            add(newAlarmBtn);
        }
        revalidate();
    }
    
    public class EventHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            if(e.getSource() == newAlarmBtn)
            {
                alarmPanels.add(new AlarmPanel(thisPanel));
                revalidateAlarmPanels();
            }
        }
    }
}