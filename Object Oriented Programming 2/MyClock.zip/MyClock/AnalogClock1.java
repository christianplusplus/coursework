/**
 * Analog clock component.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/19/17)
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.*;
import java.io.IOException;
import java.awt.geom.AffineTransform;
public class AnalogClock1 extends JPanel
{
    private WorldTime worldTime;
    private BufferedImage background;
    private String backgroundFileName = "clockBackground.png";
    private BufferedImage hand;
    private String handFileName = "hand.png";
    private int handCenterX = 846;
    private int handCenterY = 1655;
    private double secondHandWidth = .2;
    private double secondHandLength = .5;
    private double minuteHandWidth = .3;
    private double minuteHandLength = .4;
    private double hourHandWidth = .4;
    private double hourHandLength = .3;
    private final double twelveHoursInSecondsToRadians = Math.PI / 21600;
    
    public AnalogClock1(WorldTime worldTime)
    {
        this.worldTime = worldTime;
        try
        {
            background = ImageIO.read(new File(backgroundFileName));
            hand = ImageIO.read(new File(handFileName));
        }
        catch(IOException ex){}
    }
    
    @Override
    public void paintComponent(Graphics g)
    {
        int diameter = Math.min(getWidth(), getHeight());
        int origin = diameter / 2;
        double scaleX = (double)diameter / hand.getWidth();
        double scaleY = (double)diameter / hand.getHeight();
        
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D)g;
        
        g.drawImage(background, 0, 0, diameter, diameter, null);
        
        AffineTransform ats = new AffineTransform();
        ats.translate(origin, origin);
        ats.rotate(worldTime.getSeconds() * twelveHoursInSecondsToRadians * 720);
        ats.scale(secondHandWidth * scaleX, secondHandLength * scaleY);
        ats.translate(-handCenterX, -handCenterY);
        g2d.drawImage(hand, ats, null);
        
        AffineTransform atm = new AffineTransform();
        atm.translate(origin, origin);
        atm.rotate(worldTime.getSecondsForMinutes() * twelveHoursInSecondsToRadians * 12);
        atm.scale(minuteHandWidth * scaleX, minuteHandLength * scaleY);
        atm.translate(-handCenterX, -handCenterY);
        g2d.drawImage(hand, atm, null);
        
        AffineTransform ath = new AffineTransform();
        ath.translate(origin, origin);
        ath.rotate(worldTime.getSecondsForHours() * twelveHoursInSecondsToRadians);
        ath.scale(hourHandWidth * scaleX, hourHandLength * scaleY);
        ath.translate(-handCenterX, -handCenterY);
        g2d.drawImage(hand, ath, null);
    }
}