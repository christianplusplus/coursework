/**
 * Frame for choosing time zone options.
 * 
 * @author (Christian Wendladt) 
 * @version (04/24/17)
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class TimeZoneSettings extends JFrame
{
    private TimeZoneSettings thisFrame;
    private ClockGUIAlarm parentPanel;
    private JButton setZone;
    private JTextField timeText;
    private JRadioButton[] timeZoneBtns;
    private JCheckBox dst;
    private int timeZone;
    
    public TimeZoneSettings(ClockGUIAlarm parentPanel)
    {
        super("Time Zone Options");
        
        thisFrame = this;
        this.parentPanel = parentPanel;
        
        JPanel controls = new JPanel();
        controls.setLayout(new GridLayout(1, 2));
        JPanel leftControls = new JPanel(new GridLayout(0, 1));
        controls.add(leftControls);
        JPanel rightControls = new JPanel(new GridLayout(0, 1));
        controls.add(rightControls);
        add(controls);
        
        setZone = new JButton("SET");
        leftControls.add(setZone);
        
        dst = new JCheckBox("Daylight Savings");
        
        timeZoneBtns = new JRadioButton[]{
                new JRadioButton("Midway Islands Time[-11:00]"),
                new JRadioButton("Hawaii Standard Time[-10:00]"),
                new JRadioButton("Alaska Standard Time[-9:00]"),
                new JRadioButton("Pacific Standard Time[-8:00]"),
                new JRadioButton("Mountain Standard Time[-7:00]"),
                new JRadioButton("Central Standard Time[-6:00]"),
                new JRadioButton("Eastern Standard Time[-5:00]"),
                new JRadioButton("Virgin Islands Time[-4:00]"),
                new JRadioButton("Canada Newfoundland Time[-3:00]"),
                new JRadioButton("Brasilia Summer Time[-2:00]"),
                new JRadioButton("Central African Time[-1:00]"),
                new JRadioButton("Greenwich Mean Time[+0:00]"),
                new JRadioButton("European Central Time[+1:00]"),
                new JRadioButton("Egypt Standard Time[+2:00]"),
                new JRadioButton("Eastern Afraican Time[+3:00]"),
                new JRadioButton("Near East Time[+4:00]"),
                new JRadioButton("Pakistan Lahore Time[+5:00]"),
                new JRadioButton("Bangladesh Standard Time[+6:00]"),
                new JRadioButton("Vietnam Standard Time[+7:00]"),
                new JRadioButton("China Taiwan Time[+8:00]"),
                new JRadioButton("Japan Standard Time[+9:00]"),
                new JRadioButton("Australia Eastern Time[+10:00]"),
                new JRadioButton("Solomon Standard Time[+11:00]"),
                new JRadioButton("New Zealand Standard Time[+12:00]")
                };
        ButtonGroup group = new ButtonGroup();
        for(int i = 0; i < timeZoneBtns.length; i++)
        {
            group.add(timeZoneBtns[i]);
            if(i == 12)
            {
                rightControls.add(dst);
            }
            if(i < 12)
            {
                leftControls.add(timeZoneBtns[i]);
            }
            else
            {
                rightControls.add(timeZoneBtns[i]);
            }
        }
        
        EventHandler handler = new EventHandler();
        setZone.addActionListener(handler);
        
        setSize(540, 400);
        setVisible(false);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
    }
    
    public void setButtonPressed()
    {
        int dst = this.dst.isSelected() ? 1 : 0;
        timeZoneBtns[parentPanel.getParsedTimeZoneText() + 11 - dst].setSelected(true);
    }
    
    private class EventHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            if(e.getSource() == setZone)
            {
                int dst = thisFrame.dst.isSelected() ? 1 : 0;
                int index = 0;
                
                while(!timeZoneBtns[index].isSelected())
                {
                    index++;
                }
                parentPanel.setTimeZone(index - 11 + dst);
                thisFrame.setVisible(false);
            }
        }
    }
}