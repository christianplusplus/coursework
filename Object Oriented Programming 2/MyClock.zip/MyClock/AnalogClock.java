
/**
 * Write a description of class AnalogClock here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.* ;

public class AnalogClock extends JPanel 
{
   private WorldTime worldTime ;
    
   public AnalogClock(WorldTime worldTime)
   {
       this.worldTime = worldTime ;
    }
   
   
        @Override
     public void paintComponent(Graphics g) 
     {
        double minsecdeg = (double)Math.PI / 30;
        double hrdeg = (double)Math.PI / 6 ;
        int tx, ty ;
        int xpoints[] = new int[3];
        int ypoints[] = new int[3]; 
         
         
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setColor(Color.WHITE);
        g.fillOval(5, 5,480,480);
        g.setColor(Color.BLACK);
        g.fillOval(10, 10,470,470);
        g.setColor(Color.WHITE);
        g.fillOval(237,237,15,15);
        g.setFont(g.getFont().deriveFont(Font.BOLD,32));

        for(int i=1 ; i<=12 ; i++)
            g.drawString(Integer.toString(i),240-(i/12)*11+(int)(210*Math.sin(i*Math.PI/6)),253-(int)(210*Math.cos(i*Math.PI/6)));


 
       //second hand
        tx = 245 + (int)(210 * Math.sin(worldTime.getSeconds() * minsecdeg));
        ty = 245 - (int)(210 * Math.cos(worldTime.getSeconds() * minsecdeg));
        g.drawLine(245, 245 , tx, ty);

        //minute hand
        tx = 245 + (int)(190 * Math.sin(worldTime.getMinutes() * minsecdeg));
        ty = 245 - (int)(190 * Math.cos(worldTime.getMinutes() * minsecdeg));
        xpoints[0] = 245;
        xpoints[1] = tx + 2 ;
        xpoints[2] = tx - 2 ;
        ypoints[0] = 245 ;
        ypoints[1] = ty + 2 ;
        ypoints[2] = ty - 2 ;
        g.fillPolygon(xpoints, ypoints, 3) ;

        //hour hand
        tx = 245 + (int)(160 * Math.sin(worldTime.getHours() % 12 * hrdeg + worldTime.getMinutes() * Math.PI / 360)) ;
        ty = 245 - (int)(160 * Math.cos(worldTime.getHours() % 12 * hrdeg + worldTime.getMinutes() * Math.PI / 360)) ;
        xpoints[1] = tx + 4 ;
        xpoints[2] = tx - 4 ;
        ypoints[1] = ty - 4 ;
        ypoints[2] = ty + 4 ;
        g.fillPolygon(xpoints, ypoints, 3);

    }  // emd paintComponent()


    
}
