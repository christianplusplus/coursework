/**
 * Produces a graphic user interface with controls for an alarm clock.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/24/17)
 */
import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class ClockGUIAlarm extends JPanel implements Runnable
{
    private JFrame mainFrame;
    private TimeZoneSettings timeZoneFrame;
    private AlarmClock timekeeper;
    private JTextField dateAndTime;
    private JButton timeZoneBtn;
    private JTextField timeZoneTxt;
    private long totalSeconds;
    private final int MILLISECONDS_IN_A_SECOND = 1000;
    private final int FIVE_HOURS_IN_A_SECONDS = 18000;
    
    public ClockGUIAlarm(JFrame mainFrame)
    {
        this.mainFrame = mainFrame;
        timekeeper = new AlarmClock();
        
        setLayout(new GridLayout(0, 2));
        
        JPanel clockDisplay = new JPanel();
        clockDisplay.setLayout(new BorderLayout());
        add(clockDisplay);
        
        AlarmControl alarmControl = new AlarmControl(timekeeper);
        Thread alarmThread = new Thread(alarmControl);
        alarmThread.start();
        add(alarmControl);
        
        dateAndTime = new JTextField(20);
        dateAndTime.setEditable(false);
        clockDisplay.add(dateAndTime, BorderLayout.NORTH);
        
        AnalogClockAlarm analogClock = new AnalogClockAlarm(timekeeper);
        clockDisplay.add(analogClock, BorderLayout.CENTER);
        
        JPanel displayControls = new JPanel();
        timeZoneBtn = new JButton("Set Time Zone");
        timeZoneTxt = new JTextField(4);
        timeZoneTxt.setText("+0:00");
        timeZoneTxt.setEditable(false);
        displayControls.add(timeZoneBtn);
        displayControls.add(timeZoneTxt);
        clockDisplay.add(displayControls, BorderLayout.SOUTH);
        
        EventHandler handler = new EventHandler();
        timeZoneBtn.addActionListener(handler);
        
        timeZoneFrame = new TimeZoneSettings(this);
    }
    
    public void setTimeZone(int timeZone)
    {
        if(timeZone >= 0)
        {
            timeZoneTxt.setText("+" + timeZone + ":00");
        }
        else
        {
            timeZoneTxt.setText(timeZone + ":00");
        }
        timekeeper.setTimeZone(timeZone);
    }
    public int getParsedTimeZoneText()
    {
        int num;
        String string = timeZoneTxt.getText();
        
        string = string.substring(0, string.indexOf(':'));
        num = Integer.parseInt(string);
        
        return num;
    }
    
    @Override
    public void run()
    {
        while(true)
        {
            totalSeconds = (new Date()).getTime() / MILLISECONDS_IN_A_SECOND + FIVE_HOURS_IN_A_SECONDS;
            AlarmClock.setTotalSeconds(totalSeconds);
            dateAndTime.setText(timekeeper.toString());
            repaint();
            try
            {
                Thread.sleep(MILLISECONDS_IN_A_SECOND);
            }catch(InterruptedException ex){}
        }
    }
    
    private class EventHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            if(e.getSource() == timeZoneBtn)
            {
                timeZoneFrame.setLocation(mainFrame.getX(), mainFrame.getY() + mainFrame.getHeight());
                timeZoneFrame.setVisible(true);
                timeZoneFrame.setButtonPressed();
            }
        }
    }
}