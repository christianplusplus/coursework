// Fig. 10.4: Employee.java
// Employee abstract superclass.
import java.lang.IllegalArgumentException;
public abstract class Employee 
{
    private String firstName;
    private String lastName;
    private int[] SSN;
    
    protected Employee(String firstName, String lastName, String SSN)
    {
        setFirstName(firstName);
        setLastName(lastName);
        setSSN(SSN);
    }
    
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }
    public String getFirstName()
    {
         return firstName;
    }
    
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }
    public String getLastName()
    {
        return lastName;
    }
    
    public void setSSN(String SSN)
    {
        int[] arr = new int[9];
        String digits = SSN.replaceAll("[^0-9]", "");
        
        if(digits.length() < 9)
        {
            throw new IllegalArgumentException();
        }
        for(int i = 0; i < 9; i++)
        {
            arr[i] = Character.getNumericValue(digits.charAt(i));
        }
        
        this.SSN = arr;
    }
    public String getSSN()
    {
        String SSN = "" +
                     this.SSN[0] +
                     this.SSN[1] +
                     this.SSN[2] +
                     '-' +
                     this.SSN[3] +
                     this.SSN[4] +
                     '-' +
                     this.SSN[5] +
                     this.SSN[6] +
                     this.SSN[7] +
                     this.SSN[8];
        
        return SSN;
    }
    
    public abstract double earnings();
    
    @Override
    public String toString()
    {
        String string = getFirstName() + ' ' + getLastName() + '\n' +
                        "social security number: " + getSSN();
        
        return string;
    }
} // end abstract class Employee