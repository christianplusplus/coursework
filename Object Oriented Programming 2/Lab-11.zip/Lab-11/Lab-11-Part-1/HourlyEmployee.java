// Fig. 10.6: HourlyEmployee.java
// HourlyEmployee class extends Employee.
import java.lang.IllegalArgumentException;
public class HourlyEmployee extends Employee 
{
    private double wage;
    private double hours;
    
    public HourlyEmployee(String firstName, String lastName, String SSN, double wage,
            double hours)
    {
        super(firstName, lastName, SSN);
        setWage(wage);
        setHours(hours);
    }
    
    public void setWage(double wage)
    {
        if(wage < 0)
        {
            throw new IllegalArgumentException();
        }
        this.wage = wage;
    }
    public double getWage()
    {
        return wage;
    }
    
    public void setHours(double hours)
    {
        if(hours < 0)
        {
            throw new IllegalArgumentException();
        }
        this.hours = hours;
    }
    public double getHours()
    {
        return hours;
    }
    
    @Override
    public double earnings()
    {
        double earnings;
        
        if(hours <= 40)
        {
            earnings = getWage() * getHours();
        }
        else //if(hours > 40)
        {
            earnings = 40 * getWage() + (getHours() - 40) * getWage() * 1.5;
        }
        
        return earnings;
    }
    
    @Override
    public String toString()
    {
        String string = String.format("hourly employee: %s %s\nsocial security number: %s\nhourly wage: $%,.2f; hours worked: %.2f",
                getFirstName(), getLastName(), getSSN(), getWage(), getHours());
        
        return string;
    }
} // end class HourlyEmployee