// Fig. 10.5: SalariedEmployee.java
// SalariedEmployee concrete class extends abstract class Employee.
import java.lang.IllegalArgumentException;
public class SalariedEmployee extends Employee 
{
    private double salary;
    
    public SalariedEmployee(String firstName, String lastName, String SSN, double salary)
    {
        super(firstName, lastName, SSN);
        setSalary(salary);
    }
    
    public void setSalary(double salary)
    {
        if(salary < 0)
        {
            throw new IllegalArgumentException();
        }
        this.salary = salary;
    }
    public double getSalary()
    {
        return salary;
    }
    
    @Override
    public double earnings()
    {
        return getSalary();
    }
    
    @Override
    public String toString()
    {
        String string = String.format("salaried employee: %s %s\nsocial security number: %s\nweekly salary: $%,.2f",
                getFirstName(), getLastName(), getSSN(), getSalary());
        return string;
    }
} // end class SalariedEmployee

