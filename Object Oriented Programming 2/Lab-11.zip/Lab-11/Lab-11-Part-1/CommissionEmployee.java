// Fig. 10.7: CommissionEmployee.java
// CommissionEmployee class extends Employee.
import java.lang.IllegalArgumentException;
public class CommissionEmployee extends Employee 
{
    private double grossSales;
    private double commissionRate;
    
    public CommissionEmployee(String firstName, String lastName, String SSN,
            double grossSales, double commissionRate)
    {
        super(firstName, lastName, SSN);
        setGrossSales(grossSales);
        setCommissionRate(commissionRate);
    }
    
    public void setGrossSales(double grossSales)
    {
        if(grossSales < 0)
        {
            throw new IllegalArgumentException();
        }
        this.grossSales = grossSales;
    }
    public double getGrossSales()
    {
        return grossSales;
    }
    
    public void setCommissionRate(double commissionRate)
    {
        if(commissionRate < 0)
        {
            throw new IllegalArgumentException();
        }
        this.commissionRate = commissionRate;
    }
    public double getCommissionRate()
    {
        return commissionRate;
    }
    
    @Override
    public double earnings()
    {
        double earnings = getCommissionRate() * getGrossSales();
        
        return earnings;
    }
    
    @Override
    public String toString()
    {
        String string = String.format("commission employee: %s %s\nsocial security number: %s\ngross sales: $%,.2f; commission rate: %.2f",
                getFirstName(), getLastName(), getSSN(), getGrossSales(), getCommissionRate());
        
        return string;
    }
} // end class CommissionEmployee