/**
 * Custom exception for use by DataSet<E>.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/07/17)
 */
public class CustomNoSuchElementException extends RuntimeException
{
    public CustomNoSuchElementException()
    {
    }
}