/**
 * Driver for DataSet<E> IO processes.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/26/17)
 */
public class Driver
{
    public static void main(String[] args)
    {
        DataSet<Double> doubleSet1 = new DataSet<>();
        DataSet<Double> doubleSet2 = new DataSet<>();
        DataSet<Double> doubleSet3 = new DataSet<>();
        DataSet<String> stringSet1 = new DataSet<>();
        DataSet<String> stringSet2 = new DataSet<>();
        DataSet<String> stringSet3 = new DataSet<>();
        DataSet<Person> personSet1 = new DataSet<>();
        DataSet<Person> personSet2 = new DataSet<>();
        DataSet<Person> personSet3 = new DataSet<>();
        String doubleFile = "doubles.txt";
        String stringFile = "strings.txt";
        String personFile = "persons.txt";
        
        doubleSet1.add(Math.PI);
        doubleSet1.add(1/3.);
        doubleSet1.add(-9.6);
        
        stringSet1.add("Cool String!");
        stringSet1.add("Let loose the dogs of war.");
        stringSet1.add("I can't think of a better example.");
        
        personSet1.add(new Person("Christian Wendlandt", 26, "male"));
        personSet1.add(new Person());
        personSet1.add(new Person("Johnny mcJohnjohn", 69, "Attack Helicopter"));
        
        System.out.println(doubleSet1.writeDataToFile(doubleFile));
        System.out.println(stringSet1.writeDataToFile(stringFile));
        System.out.println(personSet1.writeDataToFile(personFile));
        
        System.out.println(doubleSet2.readDataFromFile(doubleFile));
        System.out.println(stringSet2.readDataFromFile(stringFile));
        System.out.println(personSet2.readDataFromFile(personFile));
        
        doubleSet3 = (DataSet<Double>)doubleSet2.clone();
        stringSet3 = (DataSet<String>)stringSet2.clone();
        personSet3 = (DataSet<Person>)personSet2.clone();
        
        System.out.println("First sets:");
        System.out.println(doubleSet1);
        System.out.println(stringSet1);
        System.out.println(personSet1);
        
        System.out.println("Second sets copied from first set via binary IO:");
        System.out.println(doubleSet2);
        System.out.println(stringSet2);
        System.out.println(personSet2);
        
        System.out.println("Third sets cloned from second set:");
        System.out.println(doubleSet3);
        System.out.println(stringSet3);
        System.out.println(personSet3);
        
        System.out.println("Element at 0 index removed from each the second sets.");
        doubleSet2.remove(0);
        stringSet2.remove(0);
        personSet2.remove(0);
        
        System.out.println("Second sets copied from first set via binary IO:");
        System.out.println(doubleSet2);
        System.out.println(stringSet2);
        System.out.println(personSet2);
        
        System.out.println("Third sets cloned from second set:");
        System.out.println(doubleSet3);
        System.out.println(stringSet3);
        System.out.println(personSet3);
        
        doubleSet1.storeDSetObjectToFile(doubleFile);
        stringSet1.storeDSetObjectToFile(stringFile);
        personSet1.storeDSetObjectToFile(personFile);
        
        doubleSet2 = doubleSet1.loadDSetObjectFromFile(doubleFile);
        stringSet2 = stringSet1.loadDSetObjectFromFile(stringFile);
        personSet2 = personSet1.loadDSetObjectFromFile(personFile);
        
        System.out.println("First sets again:");
        System.out.println(doubleSet1);
        System.out.println(stringSet1);
        System.out.println(personSet1);
        
        System.out.println("Second sets copied from first set via object serialization:");
        System.out.println(doubleSet2);
        System.out.println(stringSet2);
        System.out.println(personSet2);
    }
}