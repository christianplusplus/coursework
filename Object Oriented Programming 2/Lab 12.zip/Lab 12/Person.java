import java.io.Serializable;
public class Person implements Serializable 
{
    // instance variables - replace the example below with your own
    private String name ;
    private int age ;
    private String gender ;
    
    /**
    * Constructor for objects of class Person
    */
    public Person()
    {
        name = "UNKNOWN" ;
        age = 0 ;
        gender = "" ;
    }
    
    public Person(String name, int age, String gender)
    {
        this.name = name ;
        this.age = age ;
        this.gender = gender ;
    }
    
    /**
    * @param y a sample parameter for a method
    * @return the sum of x and y 
    */
    public int getAge()
    { 
        return age;
    }
    
    public String getName()
    {
        return name ;
    }
    
    public String getGender()
    {
        return gender ;
    }
    
    public void setName(String name)
    {
        this.name = name ;
    }
    
    public void setAge(int age)
    {
        this.age = age ;
    }
    
    public void setGender(String gender)
    {
        this.gender = gender ;
    }
    
    public String toString()
    {
        return (name + " age " + age + " gender " + gender);
    }
}