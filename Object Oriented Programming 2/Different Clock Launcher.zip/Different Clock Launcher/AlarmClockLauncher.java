/**
 * Launcher for ClockGUIAlarm.
 * 
 * @author (Christian Wendlandt)
 * @version (04/28/17)
 */
import javax.swing.*;
public class AlarmClockLauncher
{
    private final static int NUMBER_OF_CLOCKS = 5;
    
    public static void main(String[] args)
    {
        JFrame frame = new JFrame("Alarm Clock");
        JPanel panel = new JPanel();
        frame.add(panel);
        
        for(int i = 0; i < NUMBER_OF_CLOCKS; i++)
        {
            ClockGUIAlarm alarmGUI = new ClockGUIAlarm(frame);
            Thread gui = new Thread(alarmGUI);
            gui.start();
            panel.add(alarmGUI);
        }
        
        frame.setSize(1600, 440);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}