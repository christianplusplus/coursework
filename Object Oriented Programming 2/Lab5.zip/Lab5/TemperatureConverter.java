/**
 * Application that converts between Fahrenheit and Celsius.
 * 
 * @author (Christian Wendlandt) 
 * @version (03/05/17)
 */
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
public class TemperatureConverter extends JFrame
{
    private final JTextField textField1;
    private final JTextField textField2;
    private final JButton button1;
    private final JButton button2;
    private final JLabel label1;
    private final JLabel label2;

    public TemperatureConverter()
    {
        super("TemperatureConverter");
        setLayout(new FlowLayout());
        
        label1 = new JLabel("Fahrenheit:");
        add(label1);

        textField1 = new JTextField(10);
        add(textField1);
        
        label2 = new JLabel("Celsius:");
        add(label2);

        textField2 = new JTextField(10);
        add(textField2);
      
        button1 = new JButton("Fahrenheit to Celsius");
        add(button1);
      
        button2 = new JButton("Celsius to Fahrenheit");
        add(button2);

        TextFieldHandler handler = new TextFieldHandler();
        textField1.addActionListener(handler);
        textField2.addActionListener(handler);
        button1.addActionListener(handler);
        button2.addActionListener(handler);
    }

    private class TextFieldHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent event)
        {
            double f, c;
            try
            {
                f = Double.parseDouble(textField1.getText());
            }
            catch(NumberFormatException e)
            {
                f = 0;
            }
            try
            {
                c = Double.parseDouble(textField2.getText());
            }
            catch(NumberFormatException e)
            {
                c = 0;
            }
            
            if(event.getSource() == textField1)
                textField2.setText(String.format("%.2f", 5. * (f - 32.) / 9.));
            else if(event.getSource() == textField2)
                textField1.setText(String.format("%.2f", 9. * c / 5. + 32.));
            else if(event.getSource() == button1)
                textField2.setText(String.format("%.2f", 5. * (f - 32.) / 9.));
            else if(event.getSource() == button2)
                textField1.setText(String.format("%.2f", 9. * c / 5. + 32.));
        }
    }
}