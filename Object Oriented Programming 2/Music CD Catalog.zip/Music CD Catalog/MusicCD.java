/**
 * CD object with title, artist, and date instance variables.
 * 
 * @author (Christian Wendlandt) 
 * @version (03/07/17)
 */
public class MusicCD
{
    private String title;
    private String artist;
    private int date;
    
    public MusicCD()
    {
        setTitle("");
        setArtist("");
        setDate(0);
    }
    public MusicCD(String title, String artist, int date)
    {
        setTitle(title);
        setArtist(artist);
        setDate(date);
    }
    
    public void setTitle(String title)
    {
        this.title = title;
    }
    public String getTitle()
    {
        return title;
    }
    
    public void setArtist(String artist)
    {
        this.artist = artist;
    }
    public String getArtist()
    {
        return artist;
    }
    
    public void setDate(int date)
    {
        this.date = date;
    }
    public int getDate()
    {
        return date;
    }
    
    public String toString()
    {
        String string = "\"" + getTitle() + "\" \"" + getArtist() + "\" " + getDate();
        
        return string;
    }
}