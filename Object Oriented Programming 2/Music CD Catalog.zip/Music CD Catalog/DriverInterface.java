/**
 * Driver to test CDCatalog and provide user interface.
 * 
 * @author (Christian Wendlandt) 
 * @version (03/03/17)
 */
import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.*;
public class DriverInterface
{
    public static void main(String[] args) throws IOException
    {
        CDCollection cdCollection = new CDCollection();
        boolean run = true;
        
        do
        {
            System.out.println("Menu: Enter a command. - READ file\n"
                             + "CLEAR collection - WRITE output - QUIT\n");
            switch(askMenu())
            {
                case "READ":
                    cdCollection.readCD();
                    break;
                case "CLEAR":
                    cdCollection.clearList();
                    break;
                case "WRITE":
                    cdCollection.writeCD();
                    break;
                case "QUIT":
                    System.out.print("Thank you.");
                    run = false;
                    break;
            }
        } while(run);
    }
    
    private static String askMenu()
    {
        Scanner scan = new Scanner(System.in);
        String input;
        
        do
        {
            System.out.print(">");
            input = scan.nextLine().toUpperCase();
            System.out.println();
            
            if(        input.equals("READ")
                    || input.equals("CLEAR")
                    || input.equals("WRITE")
                    || input.equals("QUIT"))
            {
                break;
            }
            System.out.println("Invalid input. Enter the capitalized letters of the command you want to execute.\nInput is case-insensitive.\n");
        } while(true);
        
        return input;
    }
}