/**
 * Reads, Writes, and stores CDs on a list.
 * 
 * @author (Christian Wendlandt) 
 * @version (03/07/17)
 */
import java.util.Scanner;
import java.io.*;
import javax.swing.*;
public class CDCollection
{
    private MusicCD[] list;
    private int count;
    
    public CDCollection()
    {
        list = new MusicCD[3];
        count = 0;
    }
    
    public void readCD() throws IOException
    {
        File inFile;
        Scanner input;
        String signature;
        String title;
        String artist;
        int year;
        
        try
        {
            inFile = openInputFile();
            input = new Scanner(inFile);
            while(input.hasNext())
            {
                signature = input.nextLine();
                title = parseTitle(signature);
                artist = parseArtist(signature);
                year = parseYear(signature);
                insert(new MusicCD(title, artist, year));
            }
            input.close();
            System.out.println("You've added \"" + inFile.getName() + "\" to your collection.\n");
        }
        catch(Exception e)
        {
            System.out.println("Not a valid file.\n");
        }
    }
    
    private File openInputFile()
    {
        int returnVal;
        File file;
        
        JFileChooser chooser = new JFileChooser(System.getProperty("user.dir"));
        returnVal = chooser.showOpenDialog(null);
        if(returnVal == JFileChooser.APPROVE_OPTION)
        {
            file = chooser.getSelectedFile();
        }
        else
        {
            file = null;
        }
        
        return file;
    }
    
    private String parseTitle(String signature) throws IndexOutOfBoundsException
    {
        String string;
        int index1 = 0;
        int index2;
        
        while(signature.charAt(index1++) != '"');
        index2 = index1;
        while(signature.charAt(index2++) != '"');
        string = signature.substring(index1, --index2).trim();
        
        return string;
    }
    
    private String parseArtist(String signature) throws IndexOutOfBoundsException
    {
        String string;
        int index1 = 0;
        int index2 ;
        
        while(signature.charAt(index1++) != '"');
        while(signature.charAt(index1++) != '"');
        while(signature.charAt(index1++) != '"');
        index2 = signature.lastIndexOf('"');
        string = signature.substring(index1, index2).trim();
        
        return string;
    }
    
    private int parseYear(String signature)
    {
        String string;
        int index;
        int year;
        
        index = signature.lastIndexOf('"') + 1;
        string = signature.substring(index).trim();
        year = Integer.parseInt(string);
        
        return year;
    }
    
    public void clearList()
    {
        list = new MusicCD[3];
        count = 0;
        System.out.println("Your collection has been cleared.\n");
    }
    
    public void writeCD() throws IOException
    {
        File outFile;
        PrintWriter output;
        
        try
        {
            outFile = openOutputFile();
            output = new PrintWriter(outFile);
            output.print(toString());
            output.close();
            System.out.println("You've written your collection to \"" + outFile.getName() + "\".\n");
        }
        catch(Exception e)
        {
            System.out.println("File not selected.\n");
        }
    }
    
    private File openOutputFile()
    {
        int returnVal;
        File file;
        
        JFileChooser chooser = new JFileChooser(System.getProperty("user.dir"));
        returnVal = chooser.showSaveDialog(null);
        if(returnVal == JFileChooser.APPROVE_OPTION)
        {
            file = chooser.getSelectedFile();
        }
        else
        {
            file = null;
        }
        
        return file;
    }
    
    private boolean isFull()
    {
        boolean check = count >= list.length ? true : false;
        
        return check;
    }
    
    private void insert(MusicCD song)
    {
        int index = count - 1;
        MusicCD temp;
        
        if(isFull())
        {
            makeListBigger();
        }
        list[count++] = song;
        if(count > 1)
        {
            while(compareMusicCD(index) && index > - 1)
            {
                temp = list[index];
                list[index] = list[index + 1];
                list[index-- + 1] = temp;
            }
        }
    }
    
    private void makeListBigger()
    {
        MusicCD[] newList = new MusicCD[list.length * 2 + 1];
        
        for(int i = 0; i < count; i++)
        {
            newList[i] = list[i];
        }
        list = newList;
    }
    
    private boolean compareMusicCD(int index)//returns true if list[i] > list[i + 1].
    {
        boolean check = false;
        if(index > -1)
        {
            if(list[index].getArtist().compareTo(list[index + 1].getArtist()) > 0)
            {
                check = true;
            }
            else if(list[index].getArtist().compareTo(list[index + 1].getArtist()) == 0)
            {
                if(list[index].getDate() > list[index + 1].getDate())
                {
                    check = true;
                }
                else if(list[index].getDate() == list[index + 1].getDate())
                {
                    if(list[index].getTitle().compareTo(list[index + 1].getTitle()) > 0)
                    {
                        check = true;
                    }
                }
            }
        }
        return check;
    }
    
    public String toString()
    {
        String string = "";
        
        for(int i = 0; i < count; i++)
        {
            string += list[i].toString() + "\r\n";
        }
        
        return string;
    }
}