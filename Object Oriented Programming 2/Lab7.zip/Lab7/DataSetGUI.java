/**
 * Provides a graphics user interface for producing and manipulating a data set.
 * 
 * @author (Christian Wendlandt) 
 * @version (03/31/17)
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class DataSetGUI
{
    private DataSet<Integer> data;
    
    private JFrame frame;
    
    private JPanel controls;
        private JButton add1;
            private JTextField add1Input;
        private JButton add2;
            private JTextField add2Input1;
            private JTextField add2Input2;
        private JButton get;
            private JTextField getInput;
        private JButton set;
            private JTextField setInput1;
            private JTextField setInput2;
        private JButton remove1;
            private JTextField remove1Input;
        private JButton remove2;
            private JTextField remove2Input;
        private JButton indexOf;
            private JTextField indexOfInput;
        private JButton contains;
            private JTextField containsInput;
        private JButton clear;
        private JButton isEmpty;
        private JButton toString;
    
    private JPanel display;
        private JTextArea textDisplay;
    
    private JTextField status;
    public DataSetGUI()
    {
        data = new DataSet<>();
        
        
        
        frame = new JFrame("Data Set Control Panel");
        frame.setLayout(new BorderLayout());
        
        
        
        controls = new JPanel(new GridLayout(0, 3, 5, 5));
        controls.setSize(300, 100);
        frame.add(controls, BorderLayout.WEST);
        
        add1 = new JButton("add(element)");
        controls.add(add1);
        
        add1Input = new JTextField(6);
        controls.add(add1Input);
        
        controls.add(new JPanel());
        
        add2 = new JButton("add(element, index)");
        controls.add(add2);
        
        add2Input1 = new JTextField(6);
        controls.add(add2Input1);
        
        add2Input2 = new JTextField(6);
        controls.add(add2Input2);
        
        get = new JButton("get(index)");
        controls.add(get);
        
        getInput = new JTextField(6);
        controls.add(getInput);
        
        controls.add(new JPanel());
        
        set = new JButton("set(index, element)");
        controls.add(set);
        
        setInput1 = new JTextField(6);
        controls.add(setInput1);
        
        setInput2 = new JTextField(6);
        controls.add(setInput2);
        
        remove1 = new JButton("remove(index)");
        controls.add(remove1);
        
        remove1Input = new JTextField(6);
        controls.add(remove1Input);
        
        controls.add(new JPanel());
        
        remove2 = new JButton("remove(element)");
        controls.add(remove2);
        
        remove2Input = new JTextField(6);
        controls.add(remove2Input);
        
        controls.add(new JPanel());
        
        indexOf = new JButton("indexOf(element)");
        controls.add(indexOf);
        
        indexOfInput = new JTextField(6);
        controls.add(indexOfInput);
        
        controls.add(new JPanel());
        
        contains = new JButton("contains(element)");
        controls.add(contains);
        
        containsInput = new JTextField(6);
        controls.add(containsInput);
        
        controls.add(new JPanel());
        
        clear = new JButton("clear()");
        controls.add(clear);
        
        controls.add(new JPanel());
        
        controls.add(new JPanel());
        
        isEmpty = new JButton("isEmpty()");
        controls.add(isEmpty);
        
        controls.add(new JPanel());
        
        controls.add(new JPanel());
        
        toString = new JButton("toString()");
        controls.add(toString);
        
        
        
        display = new JPanel();
        frame.add(display, BorderLayout.EAST);
        
        textDisplay = new JTextArea(10, 20);
        textDisplay.setEditable(false);
        display.add(new JScrollPane(textDisplay));
        
        
        
        status = new JTextField(20);
        status.setEditable(false);
        frame.add(status, BorderLayout.SOUTH);
        
        
        
        EventHandler handler = new EventHandler();
        add1.addActionListener(handler);
        add2.addActionListener(handler);
        get.addActionListener(handler);
        set.addActionListener(handler);
        remove1.addActionListener(handler);
        remove2.addActionListener(handler);
        indexOf.addActionListener(handler);
        contains.addActionListener(handler);
        clear.addActionListener(handler);
        isEmpty.addActionListener(handler);
        toString.addActionListener(handler);
        
        
        
        frame.setSize(700,500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    
    private class EventHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            Integer element = 0;
            int index = -1;
            boolean check = true;
            
            status.setText("");
            if(e.getSource() == add1)
            {
                try
                {
                    element = Integer.parseInt(add1Input.getText());
                }
                catch(Exception ex)
                {
                    status.setText("Error. Not an Integer.");
                    check = false;
                }
                if(check)
                {
                    data.add(element);
                    textDisplay.setText(data.toString());
                    status.setText(element + " added to set.");
                }
            }
            else if(e.getSource() == add2)
            {
                try
                {
                    element = Integer.parseInt(add2Input1.getText());
                    index = Integer.parseInt(add2Input2.getText());
                    if(index < 0 || index > data.size())
                    {
                        throw new Exception();
                    }
                }
                catch(Exception ex)
                {
                    status.setText("Error. Either not an Integer or Index out of Bounds.");
                    check = false;
                }
                if(check)
                {
                    data.add(element, index);
                    textDisplay.setText(data.toString());
                    status.setText(element + " added to set at index " + index + ".");
                }
            }
            else if(e.getSource() == get)
            {
                try
                {
                    index = Integer.parseInt(getInput.getText());
                    if(index < 0 || index >= data.size())
                    {
                        throw new Exception();
                    }
                }
                catch(Exception ex)
                {
                    status.setText("Error. Index out of Bounds.");
                    check = false;
                }
                if(check)
                {
                    textDisplay.setText(Integer.toString(data.get(index)));
                    status.setText(index + " found.");
                }
            }
            else if(e.getSource() == set)
            {
                try
                {
                    index = Integer.parseInt(setInput1.getText());
                    element = Integer.parseInt(setInput2.getText());
                    if(index < 0 || index >= data.size())
                    {
                        throw new Exception();
                    }
                }
                catch(Exception ex)
                {
                    status.setText("Error. Either not an Integer or Index out of Bounds.");
                    check = false;
                }
                if(check)
                {
                    data.set(index, element);
                    textDisplay.setText(data.toString());
                    status.setText("Element at " + index + " was set to " + element + ".");
                }
            }
            else if(e.getSource() == remove1)
            {
                try
                {
                    index = Integer.parseInt(remove1Input.getText());
                    if(index < 0 || index >= data.size())
                    {
                        throw new Exception();
                    }
                }
                catch(Exception ex)
                {
                    status.setText("Error. Index out of Bounds.");
                    check = false;
                }
                if(check)
                {
                    data.remove(index);
                    textDisplay.setText(data.toString());
                    status.setText("Element at " + index + " was removed.");
                }
            }
            else if(e.getSource() == remove2)
            {
                try
                {
                    element = Integer.parseInt(remove2Input.getText());
                }
                catch(Exception ex)
                {
                    status.setText("Error. Not an Integer.");
                    check = false;
                }
                if(check)
                {
                    data.remove(element);
                    textDisplay.setText(data.toString());
                    status.setText(element + " was removed.");
                }
            }
            else if(e.getSource() == indexOf)
            {
                try
                {
                    element = Integer.parseInt(indexOfInput.getText());
                }
                catch(Exception ex)
                {
                    status.setText("Error. Not an Integer.");
                    check = false;
                }
                if(check)
                {
                    textDisplay.setText(Integer.toString(data.indexOf(element)));
                    status.setText("Index was found.");
                }
            }
            else if(e.getSource() == contains)
            {
                try
                {
                    element = Integer.parseInt(containsInput.getText());
                }
                catch(Exception ex)
                {
                    status.setText("Error. Not an Integer.");
                    check = false;
                }
                if(check)
                {
                    textDisplay.setText(Boolean.toString(data.contains(element)));
                    status.setText("Element was found.");
                }
            }
            else if(e.getSource() == clear)
            {
                data.clear();
                textDisplay.setText(data.toString());
                status.setText("Set was cleared.");
            }
            else if(e.getSource() == isEmpty)
            {
                textDisplay.setText(Boolean.toString(data.isEmpty()));
                status.setText("Set was checked.");
            }
            else if(e.getSource() == toString)
            {
                textDisplay.setText(data.toString());
                status.setText("Set displayed.");
            }
        }
    }
}