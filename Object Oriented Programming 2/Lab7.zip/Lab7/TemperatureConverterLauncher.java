/**
 * Launcher for initializing TemperatureConverter.
 * 
 * @author (Christian Wendlandt) 
 * @version (03/28/17)
 */
public class TemperatureConverterLauncher
{
    public static void main(String[] args)
    {
        TemperatureConverter temperatureConverter = new TemperatureConverter();
    }
}