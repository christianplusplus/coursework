/**
 * Application that converts between Fahrenheit and Celsius.
 * 
 * @author (Christian Wendlandt) 
 * @version (03/31/17)
 */
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class TemperatureConverter
{
    private final JFrame frame;
    private final JTextField textField1;
    private final JTextField textField2;
    private final JButton button1;
    private final JButton button2;
    private final JLabel label1;
    private final JLabel label2;

    public TemperatureConverter()
    {
        frame = new JFrame("Temperature Converter");
        frame.setLayout(new FlowLayout());
        
        label1 = new JLabel("Fahrenheit: ", SwingConstants.RIGHT);
        frame.add(label1);
        
        textField1 = new JTextField(10);
        frame.add(textField1);
      
        button1 = new JButton("Fahrenheit to Celsius");
        frame.add(button1);
      
        button2 = new JButton("Celsius to Fahrenheit");
        frame.add(button2);
        
        label2 = new JLabel("Celsius: ", SwingConstants.RIGHT);
        frame.add(label2);
        
        textField2 = new JTextField(10);
        frame.add(textField2);
        
        TextFieldHandler handler = new TextFieldHandler();
        Temperature temperature = new Temperature();
        textField1.addActionListener(handler);
        textField2.addActionListener(handler);
        button1.addActionListener(handler);
        button2.addActionListener(handler);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 120);
        frame.setVisible(true);
    }

    private class TextFieldHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent event)
        {   
            if(event.getSource() == textField1)
            {
                Temperature temperature = new Temperature(getTempFromText(textField1));
                
                textField2.setText(String.format("%.2f", temperature.toCelsius()));
            }
            else if(event.getSource() == textField2)
            {
                Temperature temperature = new Temperature(getTempFromText(textField2));
                
                textField1.setText(String.format("%.2f", temperature.toFahrenheit()));
            }
            else if(event.getSource() == button1)
            {
                Temperature temperature = new Temperature(getTempFromText(textField1));
                
                textField2.setText(String.format("%.2f", temperature.toCelsius()));
            }
            else if(event.getSource() == button2)
            {
                Temperature temperature = new Temperature(getTempFromText(textField2));
                
                textField1.setText(String.format("%.2f", temperature.toFahrenheit()));
            }
        }
    }
    
    public double getTempFromText(JTextField textField)
    {
        double temperature;
        
        try
        {
            temperature = Double.parseDouble(textField.getText());
        }
        catch(NumberFormatException e)
        {
            temperature = 0;
        }
        
        return temperature;
    }
}