/**
 * Holds a temperature value and can convert it from celsius to fahrenheit or vise versa.
 * 
 * @author (Christian Wendlandt) 
 * @version (03/15/17)
 */
public class Temperature
{
    private double temperature;
    
    public Temperature()
    {
        temperature = 0;
    }
    public Temperature(double temperature)
    {
        this.temperature = temperature;
    }
    
    public double getTemperature()
    {
        return temperature;
    }
    
    public void setTemperature(double temperature)
    {
        this.temperature = temperature;
    }
    
    public double toFahrenheit()
    {
        double fahrenheit = temperature * 9 / 5 + 32;
        
        return fahrenheit;
    }
    
    public double toCelsius()
    {
        double celsius = (temperature - 32) * 5 / 9;
        
        return celsius;
    }
}