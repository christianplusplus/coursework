/**
 * Launches DataSetGUI.
 * 
 * @author (Christian Wendlandt) 
 * @version (03/31/17)
 */
public class GUILauncher
{
    public static void main(String[] args)
    {
        DataSetGUI gui = new DataSetGUI();
    }
}