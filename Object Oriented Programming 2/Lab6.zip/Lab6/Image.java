/**
 * Image for Temperature Converter.
 * 
 * @author (Christian Wendlandt) 
 * @version (03/16/17)
 */
import java.awt.*;
import javax.swing.JPanel;
public class Image extends JPanel
{
    private int howFull;
    
    public Image()
    {
        howFull = 80;
    }
    
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        
        g.setColor(Color.BLACK);
        g.drawOval(35, 70, 30, 30);
        g.drawRoundRect(45, 0, 10, 90, 10, 10);
        
        g.setColor(Color.RED);
        g.fillOval(35, 70, 30, 30);
        g.fillRoundRect(45, 70 - howFull * 7 / 10, 10, 20 + howFull * 7 / 10, 10, 10);
    }
    
    public void setHowFull(double celsius)
    {
        if(celsius > 100)
        {
            howFull = 100;
        }
        else if(celsius < 0)
        {
            howFull = 0;
        }
        else
        {
            howFull = (int)celsius;
        }
    }
}