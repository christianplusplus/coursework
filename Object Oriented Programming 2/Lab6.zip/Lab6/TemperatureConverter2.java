/**
 * Application that converts between Fahrenheit and Celsius.
 * 
 * @author (Christian Wendlandt) 
 * @version (03/16/17)
 */
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class TemperatureConverter2 extends JFrame
{
    private final JTextField textField1;
    private final JTextField textField2;
    private final JButton button1;
    private final JButton button2;
    private final JLabel label1;
    private final JLabel label2;

    public TemperatureConverter2()
    {
        super("TemperatureConverter");
        setLayout(new GridLayout(3, 2));

        label1 = new JLabel("Fahrenheit: ", SwingConstants.RIGHT);
        add(label1);
        
        textField1 = new JTextField(10);
        add(textField1);
      
        button1 = new JButton("Fahrenheit to Celsius");
        add(button1);
      
        button2 = new JButton("Celsius to Fahrenheit");
        add(button2);
        
        label2 = new JLabel("Celsius: ", SwingConstants.RIGHT);
        add(label2);
        
        textField2 = new JTextField(10);
        add(textField2);
        
        TextFieldHandler handler = new TextFieldHandler();
        Temperature temperature = new Temperature();
        textField1.addActionListener(handler);
        textField2.addActionListener(handler);
        button1.addActionListener(handler);
        button2.addActionListener(handler);
    }

    private class TextFieldHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent event)
        {   
            if(event.getSource() == textField1)
            {
                Temperature temperature = new Temperature(getTempFromText(textField1));
                
                textField2.setText(String.format("%.2f", temperature.toCelsius()));
            }
            else if(event.getSource() == textField2)
            {
                Temperature temperature = new Temperature(getTempFromText(textField2));
                
                textField1.setText(String.format("%.2f", temperature.toFahrenheit()));
            }
            else if(event.getSource() == button1)
            {
                Temperature temperature = new Temperature(getTempFromText(textField1));
                
                textField2.setText(String.format("%.2f", temperature.toCelsius()));
            }
            else if(event.getSource() == button2)
            {
                Temperature temperature = new Temperature(getTempFromText(textField2));
                
                textField1.setText(String.format("%.2f", temperature.toFahrenheit()));
            }
        }
    }
    
    public double getTempFromText(JTextField textField)
    {
        double temperature;
        
        try
        {
            temperature = Double.parseDouble(textField.getText());
        }
        catch(NumberFormatException e)
        {
            temperature = 0;
        }
        
        return temperature;
    }
}