/**
 * Driver and frame for TemperatureConverter2.
 * 
 * @author (Chrisitan Wendlandt) 
 * @version (03/16/17)
 */
import javax.swing.JFrame;
public class TemperatureConverterDriver2
{
   public static void main(String[] args)
   { 
      TemperatureConverter2 temperatureConverter = new TemperatureConverter2(); 
      temperatureConverter.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      temperatureConverter.setSize(400, 100); 
      temperatureConverter.setVisible(true); 
   }
}