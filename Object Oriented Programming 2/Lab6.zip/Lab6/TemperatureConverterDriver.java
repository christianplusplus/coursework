/**
 * Driver and frame for TemperatureConverter.
 * 
 * @author (Chrisitan Wendlandt) 
 * @version (03/16/17)
 */
import javax.swing.JFrame;
public class TemperatureConverterDriver
{
   public static void main(String[] args)
   { 
      TemperatureConverter temperatureConverter = new TemperatureConverter(); 
      temperatureConverter.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      temperatureConverter.setSize(400, 200); 
      temperatureConverter.setVisible(true); 
   }
}