/**
 * Application that converts between Fahrenheit and Celsius.
 * 
 * @author (Christian Wendlandt) 
 * @version (03/16/17)
 */
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;

public class TemperatureConverter extends JFrame
{
    private final JTextField textField1;
    private final JTextField textField2;
    private final JButton button1;
    private final JButton button2;
    private final Image image;

    public TemperatureConverter()
    {
        super("TemperatureConverter");
        setLayout(new BorderLayout(5, 5));

        textField1 = new JTextField(10);
        add(textField1, BorderLayout.NORTH);

        textField2 = new JTextField(10);
        add(textField2, BorderLayout.SOUTH);
      
        button1 = new JButton("<html>Fahrenheit<br>||<br>||<br>||<br>V<br>Celsius</html>");
        add(button1, BorderLayout.WEST);
      
        button2 = new JButton("<html>Fahrenheit<br>^<br>||<br>||<br>||<br>Celsius</html>");
        add(button2, BorderLayout.CENTER);
        
        image = new Image();
        image.setPreferredSize(new Dimension(105, 100));
        add(image, BorderLayout.EAST);
        
        Temperature temperature = new Temperature();
        
        TextFieldHandler handler = new TextFieldHandler();
        textField1.addActionListener(handler);
        textField2.addActionListener(handler);
        button1.addActionListener(handler);
        button2.addActionListener(handler);
    }

    private class TextFieldHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent event)
        {   
            if(event.getSource() == textField1)
            {
                Temperature temperature = new Temperature(getTempFromText(textField1));
                
                textField2.setText(String.format("%.2f", temperature.toCelsius()));
                
                image.setHowFull(getTempFromText(textField2));
                repaint();
            }
            else if(event.getSource() == textField2)
            {
                Temperature temperature = new Temperature(getTempFromText(textField2));
                
                textField1.setText(String.format("%.2f", temperature.toFahrenheit()));
                
                image.setHowFull(getTempFromText(textField2));
                repaint();
            }
            else if(event.getSource() == button1)
            {
                Temperature temperature = new Temperature(getTempFromText(textField1));
                
                textField2.setText(String.format("%.2f", temperature.toCelsius()));
                
                image.setHowFull(getTempFromText(textField2));
                repaint();
            }
            else if(event.getSource() == button2)
            {
                Temperature temperature = new Temperature(getTempFromText(textField2));
                
                textField1.setText(String.format("%.2f", temperature.toFahrenheit()));
                
                image.setHowFull(getTempFromText(textField2));
                repaint();
            }
        }
    }
    
    public double getTempFromText(JTextField textField)
    {
        double temperature;
        
        try
        {
            temperature = Double.parseDouble(textField.getText());
        }
        catch(NumberFormatException e)
        {
            temperature = 0;
        }
        
        return temperature;
    }
}