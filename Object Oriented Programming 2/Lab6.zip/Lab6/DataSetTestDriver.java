/**
 * Driver to test DataSet and provide user interface.
 * 
 * @author (Christian Wendlandt) 
 * @version (03/08/17)
 */
import java.util.InputMismatchException;
import java.util.Scanner;
public class DataSetTestDriver
{
    public static void main(String[] args)
    {
        DataSet data = new DataSet();
        DataSet data2 = new DataSet();
        
        data.addItem(7);
        data.addItem(2);
        data.addItem(1);
        data.addItem(5);
        data.addItem(3);
        data.addItem(8);
        data.addItem(9);
        data.addItem(0);
        data.addItem(4);
        data.addItem(6);
        data.display();
        
        System.out.println(data.toString());
        
        System.out.println(data.getSetShuffled().toString());
        System.out.println(data.getSetShuffled().toString());
        
        System.out.println(data.getSetSorted().toString());
        
        data.insert(70, 3);
        data.display();
        
        data.remove(3);
        data.display();
        
        System.out.println(data.getMin());
        
        System.out.println(data.getMax());
        
        System.out.println(data.getAvg());
        
        System.out.println(data.getStdDev());
        
        data2.addItem(7);
        data2.addItem(2);
        data2.addItem(1);
        data2.addItem(5);
        data2.addItem(3);
        System.out.println(data.equals(data2));
        
        data2.addItem(8);
        data2.addItem(9);
        data2.addItem(0);
        data2.addItem(4);
        data2.addItem(66);
        System.out.println(data.equals(data2));
        System.out.println(data2.contains(6));
        
        data2.remove(9);
        data2.insert(6, 9);
        System.out.println(data.equals(data2));
        System.out.println(data2.contains(6));
        
        data.clear();
        data.display();
        data2.display();
    }
}
