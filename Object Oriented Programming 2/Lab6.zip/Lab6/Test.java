/**
 * Tester for BasePlusCommissionEmployee.
 * 
 * @author (Christian Wendlandt) 
 * @version (03/15/17)
 */
public class Test
{
    public static void main(String[] args)
    {
        BasePlusCommissionEmployee salesman = new BasePlusCommissionEmployee("Bob", "Funsy", "955-44-6321", 4545, .6, 102);
        
        System.out.println(salesman.getFirstName());
        System.out.println(salesman.getLastName());
        System.out.println(salesman.getSocialSecurityNumber());
        System.out.println(salesman.getGrossSales());
        System.out.println(salesman.getCommissionRate());
        System.out.println(salesman.getBaseSalary());
        
        salesman.setBaseSalary(1000);
        
        System.out.println(salesman.toString());
    }
}