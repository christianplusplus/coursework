/**
 * Produces a set of integers with methods to return information on the set.
 * 
 * @author (Christian Wendlandt) 
 * @version (03/08/17)
 */
import java.util.ArrayList;
import java.util.Collections;
public class DataSet
{
    private ArrayList<Integer> dataSet;
    private int count;
    
    public DataSet()
    {
        dataSet = new ArrayList<>();
    }
    public DataSet(int size)
    {
        dataSet = new ArrayList<>(size);
    }
    
    public int getMin()
    {
        int min = Collections.min(dataSet);
        
        return min;
    }
    
    public int getMax()
    {
        int max = Collections.max(dataSet);
        
        return max;
    }
    
    public double getAvg()
    {
        double avg = 0;
        
        for(int i = 0; i < dataSet.size(); i++)
        {
            avg += dataSet.get(i);
        }
        avg /= dataSet.size();
        
        return avg;
    }
    
    public double getStdDev()
    {
        double stdDev = 0;
        double avg = getAvg();
        
        for(int i = 0; i < dataSet.size(); i++)
        {
            stdDev += (dataSet.get(i) - avg) * (dataSet.get(i) - avg);
        }
        stdDev /= dataSet.size() - 1;
        stdDev = Math.sqrt(stdDev);
        
        return stdDev;
    }
    
    public void addItem(Integer datum)
    {
        dataSet.add(datum);
    }
    
    public void remove(int index)
    {
        dataSet.remove(index);
    }
    
    public void display()
    {
        String string = "";
        
        for(int i = 0; i < dataSet.size(); i++)
        {
            string += dataSet.get(i) + ", ";
        }
        
        System.out.println(string);
    }
    
    public void clear()
    {
        dataSet.clear();
    }
    
    public void insert(Integer datum, int index)
    {
        dataSet.add(index, datum);
    }
    
    public boolean isEmpty()
    {
        boolean check = dataSet.isEmpty();
        
        return check;
    }
    
    public DataSet getSetShuffled()
    {
        DataSet shuffledDataSet = new DataSet(dataSet.size());
        
        for(int i = 0; i < dataSet.size(); i++)
        {
            shuffledDataSet.addItem(dataSet.get(i));
        }
        Collections.shuffle(shuffledDataSet.dataSet);
        
        return shuffledDataSet;
    }
    
    public DataSet getSetSorted()
    {
        DataSet sortedDataSet = new DataSet(dataSet.size());
        
        for(int i = 0; i < dataSet.size(); i++)
        {
            sortedDataSet.addItem(dataSet.get(i));
        }
        Collections.sort(sortedDataSet.dataSet);
        
        return sortedDataSet;
    }
    
    public boolean contains(Integer datum)
    {
        boolean check = false;
        
        if(dataSet.contains(datum))
        {
            check = true;
        }
        
        return check;
    }

    public boolean equals(Object o)
    {
        boolean check = true;
        
        if(getClass() == o.getClass())
        {
            if(((DataSet)o).dataSet.size() == dataSet.size())
            {
                for(int i = 0; i < dataSet.size(); i++)
                {
                    if(((DataSet)o).dataSet.get(i) != dataSet.get(i))
                    {
                        check = false;
                        break;
                    }
                }
            }
            else
            {
                check = false;
            }
        }
        else
        {
            check = false;
        }
        
        return check;
    }
        
    public String toString()
    {
        String string = "";
        
        for(int i = 0; i < dataSet.size(); i++)
        {
            string += dataSet.get(i) + ", ";
        }
        
        return string;
    }
}