/**
 * Subclass of CommissionEmployee.
 * 
 * @author (Christian Wendlandt) 
 * @version (03/15/17)
 */
public class BasePlusCommissionEmployee extends CommissionEmployee
{
    private double baseSalary;
    
    public BasePlusCommissionEmployee(String firstName, String lastName,
            String socialSecurityNumber, double grossSales,
            double commissionRate, double baseSalary)
    {
        super(firstName, lastName, socialSecurityNumber, grossSales, commissionRate);
        if(baseSalary < 0)
        {
            throw new IllegalArgumentException("Base salary must be >= 0");
        }
        this.baseSalary = baseSalary;
    }
    
    public void setBaseSalary(double baseSalary)
    {
        if(baseSalary < 0)
        {
            throw new IllegalArgumentException("Base salary must be >= 0");
        }
        
        this.baseSalary = baseSalary;
    }
    
    public double getBaseSalary()
    {
        return baseSalary;
    }
    
    @Override
    public double earnings()
    {
        double earnings = baseSalary + (getCommissionRate() * getGrossSales());
        
        return earnings;
    }
    
    @Override 
    public String toString()
    {
        String string = String.format(
                "base-salaried commission employee: %s %s\n" +
                "social security number: %s\n" +
                "gross sales: %.2f\n" +
                "commission rate: %.2f\n" +
                "base salary: %.2f\n",
                getFirstName(), getLastName(), getSocialSecurityNumber(),
                getGrossSales(), getCommissionRate(), getBaseSalary());
        
        return string;
    }
}