/**
 * Gives players options for Nim game and initializes the match.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/05/17)
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class GameMenu extends JPanel
{
    private JButton start;
    private JButton cancel;
    private JButton upArrowRounds;
    private JButton downArrowRounds;
    private JButton upArrowSticks;
    private JButton downArrowSticks;
    private JRadioButton easy;
    private JRadioButton hard;
    private JRadioButton random;
    private JRadioButton human;
    private JRadioButton computer;
    private JTextField numberOfRoundsText;
    private JTextField numberOfSticksText;
    
    private NimGameGUI frame;
    private GameMenu menu;
    private NimMatch match;
    
    private int rounds;
    private int startingSticks;
    private int difficulty;
    private int goesFirst;
    
    public GameMenu(NimGameGUI frame)
    {
        this.frame = frame;
        menu = this;
        frame.add(menu);
        
        rounds = 3;
        startingSticks = 15;
        difficulty = Constants.EASY_DIFFICULTY;
        goesFirst = Math.random() >= .5 ?
                Constants.HUMAN_PLAYER : Constants.COMPUTER_PLAYER;
        //****************************************
        setLayout(new BorderLayout());
        add(new JPanel(), BorderLayout.NORTH);
        add(new JPanel(), BorderLayout.CENTER);
        add(new JPanel(), BorderLayout.SOUTH);
        
        JPanel controls = new JPanel(new GridLayout(0, 1, 5, 5));
        controls.setPreferredSize(new Dimension(200, 100));
        add(controls, BorderLayout.WEST);
        
        controls.add(new JPanel());
        controls.add(new JPanel());
        
        start = new JButton("START");
        controls.add(start);
        
        cancel = new JButton("CANCEL");
        controls.add(cancel);
        
        for(int i = 0; i < 4; i++)
        {
            controls.add(new JPanel());
        }
        
        JPanel options = new JPanel(new GridLayout(0, 4, 5, 5));
        options.setPreferredSize(new Dimension(400, 100));
        add(options, BorderLayout.EAST);
        
        options.add(new JLabel("ROUNDS:"));
        
        numberOfRoundsText = new JTextField("3");
        numberOfRoundsText.setEditable(false);
        options.add(numberOfRoundsText);
        
        JPanel upDownArrowsRounds = new JPanel();
        upDownArrowsRounds.setLayout(new BoxLayout(upDownArrowsRounds,
                BoxLayout.Y_AXIS));
        options.add(upDownArrowsRounds);
        
        upArrowRounds = new JButton("^");
        upDownArrowsRounds.add(upArrowRounds);
        
        downArrowRounds = new JButton("v");
        upDownArrowsRounds.add(downArrowRounds);
        
        options.add(new JPanel());
        
        options.add(new JLabel("STICKS:"));
        
        numberOfSticksText = new JTextField("15");
        numberOfSticksText.setEditable(false);
        options.add(numberOfSticksText);
        
        JPanel upDownArrowsSticks = new JPanel();
        upDownArrowsSticks.setLayout(new BoxLayout(upDownArrowsSticks,
                BoxLayout.Y_AXIS));
        options.add(upDownArrowsSticks);
        
        upArrowSticks = new JButton("^");
        upDownArrowsSticks.add(upArrowSticks);
        
        downArrowSticks = new JButton("v");
        upDownArrowsSticks.add(downArrowSticks);
        
        options.add(new JPanel());
        
        options.add(new JLabel("DIFFICULTY:"));
        
        easy = new JRadioButton("EASY", true);
        options.add(easy);
        
        hard = new JRadioButton("HARD", false);
        options.add(hard);
        
        ButtonGroup difficultyButtons = new ButtonGroup();
        difficultyButtons.add(easy);
        difficultyButtons.add(hard);
        
        options.add(new JPanel());
        
        options.add(new JLabel("GOES FIRST:"));
        
        random = new JRadioButton("RANDOM", true);
        options.add(random);
        
        human = new JRadioButton("PLAYER", false);
        options.add(human);
        
        computer = new JRadioButton("COMPUTER", false);
        options.add(computer);
        
        ButtonGroup goesFirstButtons = new ButtonGroup();
        goesFirstButtons.add(random);
        goesFirstButtons.add(human);
        goesFirstButtons.add(computer);
        
        for(int i = 0; i < 12; i++)
        {
            options.add(new JPanel());
        }
        
        EventHandler handler = new EventHandler();
        start.addActionListener(handler);
        cancel.addActionListener(handler);
        upArrowRounds.addActionListener(handler);
        downArrowRounds.addActionListener(handler);
        upArrowSticks.addActionListener(handler);
        downArrowSticks.addActionListener(handler);
        easy.addActionListener(handler);
        hard.addActionListener(handler);
        random.addActionListener(handler);
        human.addActionListener(handler);
        computer.addActionListener(handler);
    }
    
    public int getRounds()
    {
        return rounds;
    }
    public void setRounds(int rounds)
    {
        this.rounds = rounds;
    }
    
    public int getStartingSticks()
    {
        return startingSticks;
    }
    public void setStartingSticks(int startingSticks)
    {
        this.startingSticks = startingSticks;
    }
    
    public int getDifficulty()
    {
        return difficulty;
    }
    public void setDifficulty(int difficulty)
    {
        this.difficulty = difficulty;
    }
    
    public int getGoesFirst()
    {
        return goesFirst;
    }
    public void setGoesFirst(int goesFirst)
    {
        this.goesFirst = goesFirst;
    }
    
    private class EventHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            if(e.getSource() == start)
            {
                setVisible(false);
                match = new NimMatch(frame, menu);
            }
            else if(e.getSource() == cancel)
            {
                frame.getCanvas().setVisible(true);
                frame.remove(menu);
            }
            else if(e.getSource() == upArrowRounds)
            {
                rounds++;
                numberOfRoundsText.setText(Integer.toString(rounds));
            }
            else if(e.getSource() == downArrowRounds)
            {
                if(rounds > 1)
                {
                    rounds--;
                }
                numberOfRoundsText.setText(Integer.toString(rounds));
            }
            else if(e.getSource() == upArrowSticks)
            {
                startingSticks++;
                numberOfSticksText.setText(Integer.toString(startingSticks));
            }
            else if(e.getSource() == downArrowSticks)
            {
                if(startingSticks > 1)
                {
                    startingSticks--;
                }
                numberOfSticksText.setText(Integer.toString(startingSticks));
            }
            else if(e.getSource() == easy)
            {
                difficulty = Constants.EASY_DIFFICULTY;
            }
            else if(e.getSource() == hard)
            {
                difficulty = Constants.HARD_DIFFICULTY;
            }
            else if(e.getSource() == random)
            {
                goesFirst = Math.random() >= .5 ?
                        Constants.HUMAN_PLAYER : Constants.COMPUTER_PLAYER;
            }
            else if(e.getSource() == human)
            {
                goesFirst = Constants.HUMAN_PLAYER;
            }
            else if(e.getSource() == computer)
            {
                goesFirst = Constants.COMPUTER_PLAYER;
            }
        }
    }
}