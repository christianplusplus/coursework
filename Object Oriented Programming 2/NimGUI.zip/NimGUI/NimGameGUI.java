/**
 * Starting screen for player. Is expandable for more games.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/05/17)
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class NimGameGUI extends JFrame
{
    private JPanel canvas;
    private JButton play;
    private JButton quit;
    
    private NimGameGUI frame;
    private GameMenu menu;
    public NimGameGUI()
    {
        super("Nim");
        frame = this;
        
        canvas = new JPanel();
        add(canvas);
        
        canvas.setLayout(new BorderLayout());
        canvas.add(new JPanel(), BorderLayout.NORTH);
        canvas.add(new JPanel(), BorderLayout.CENTER);
        canvas.add(new JPanel(), BorderLayout.EAST);
        canvas.add(new JPanel(), BorderLayout.SOUTH);
        
        JPanel grid = new JPanel(new GridLayout(0, 1, 5, 5));
        grid.setPreferredSize(new Dimension(200, 100));
        canvas.add(grid, BorderLayout.WEST);
        
        play = new JButton("PLAY NIM");
        grid.add(play);
        
        quit = new JButton("QUIT");
        grid.add(quit);
        
        for(int i = 0; i < 6; i++)
        {
            grid.add(new JPanel());
        }
        
        EventHandler handler = new EventHandler();
        play.addActionListener(handler);
        quit.addActionListener(handler);
        
        setSize(800,480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    
    public JPanel getCanvas()
    {
        return canvas;
    }
    
    private class EventHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            if(e.getSource() == play)
            {
                canvas.setVisible(false);
                menu = new GameMenu(frame);
            }
            else if(e.getSource() == quit)
            {
                System.exit(0);
            }
        }
    }
}