/**
 * Stores commonly used variables as contants for use by all classes.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/05/17)
 */
import java.awt.Font;
public class Constants
{
    public static final int EASY_DIFFICULTY = 0;
    public static final int HARD_DIFFICULTY = 1;
    public static final int HUMAN_PLAYER = 0;
    public static final int COMPUTER_PLAYER = 1;
    public static final int WIN = 1;
    public static final int LOSE = -1;
    public static final int TIE = 0;
    public static final Font coolFont = new Font(
            "Serif",
            Font.BOLD + Font.ITALIC,
            20);
}