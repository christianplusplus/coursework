/**
 * Keeps track of games and picks a winner at the end.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/05/17)
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class NimMatch extends JPanel
{
    private JPanel controls;
    private JButton next;
    private JButton concede;
    private JPanel display;
    private JLabel round;
    private JLabel roundChar;
    private JLabel wins;
    private JLabel winsChar;
    private JLabel losses;
    private JLabel lossesChar;
    private JTextArea status;
    
    private NimGameGUI frame;
    private GameMenu menu;
    private NimMatch match;
    private NimGame game;
    
    private int humanScore;
    private int computerScore;
    private int gameNumber;
    public NimMatch(NimGameGUI frame, GameMenu menu)
    {
        this.frame = frame;
        this.menu = menu;
        match = this;
        frame.add(match);
        
        humanScore = 0;
        computerScore = 0;
        gameNumber = 1;
        //****************************************
        setLayout(new BorderLayout());
        add(new JPanel(), BorderLayout.NORTH);
        add(new JPanel(), BorderLayout.CENTER);
        
        controls = new JPanel(new GridLayout(0, 1, 5, 5));
        controls.setPreferredSize(new Dimension(200, 100));
        add(controls, BorderLayout.WEST);
        
        for(int i = 0; i < 4; i++)
        {
            controls.add(new JPanel());
        }
        
        next = new JButton("NEXT ROUND");
        controls.add(next);
        
        concede = new JButton("CONCEDE");
        controls.add(concede);
        
        controls.add(new JPanel());
        controls.add(new JPanel());
        
        display = new JPanel(new GridLayout(0, 2, 5, 5));
        display.setPreferredSize(new Dimension(200, 100));
        add(display, BorderLayout.EAST);
        
        round = new JLabel("ROUND:");
        round.setFont(Constants.coolFont);
        display.add(round);
        
        roundChar = new JLabel(
                Integer.toString(gameNumber) +
                "/" + 
                Integer.toString(menu.getRounds()));
        roundChar.setFont(Constants.coolFont);
        display.add(roundChar);
        
        wins = new JLabel("WINS:");
        wins.setFont(Constants.coolFont);
        display.add(wins);
        
        winsChar = new JLabel(Integer.toString(humanScore));
        winsChar.setFont(Constants.coolFont);
        display.add(winsChar);
        
        losses = new JLabel("LOSSES:");
        losses.setFont(Constants.coolFont);
        display.add(losses);
        
        lossesChar = new JLabel(Integer.toString(computerScore));
        lossesChar.setFont(Constants.coolFont);
        display.add(lossesChar);
        
        status = new JTextArea();
        status.setEditable(false);
        status.setText("You've challenge the computer to a game of Nim. " +
                "Hit next round to start.");
        add(status, BorderLayout.SOUTH);
        
        EventHandler handler = new EventHandler();
        next.addActionListener(handler);
        concede.addActionListener(handler);
    }
    
    public int getHumanScore()
    {
        return humanScore;
    }
    public void setHumanScore(int humanScore)
    {
        this.humanScore = humanScore;
    }
    public void humanWins()
    {
        humanScore++;
        gameNumber++;
        updateDisplays();
        status.setText("You won the previous round!");
        checkVictory();
    }
    
    public int getComputerScore()
    {
        return computerScore;
    }
    public void setComputerScore()
    {
        this.computerScore = computerScore;
    }
    public void computerWins()
    {
        computerScore++;
        gameNumber++;
        updateDisplays();
        status.setText("You lost the previous round.");
        checkVictory();
    }
    
    public int getGameNumber()
    {
        return gameNumber;
    }
    public void setGameNumber()
    {
        this.gameNumber = gameNumber;
    }
    
    public GameMenu getMenu()
    {
        return menu;
    }
    
    private void checkVictory()
    {
        int condition;
        
        if(gameNumber > menu.getRounds())
        {
            if(humanScore > computerScore)
            {
                condition = Constants.WIN;
            }
            else if(humanScore < computerScore)
            {
                condition = Constants.LOSE;
            }
            else //if(humanScore == computerScore)
            {
                condition = Constants.TIE;
            }
            GameOverScreen gameOverScreen = new GameOverScreen(menu, frame, condition);
            frame.add(gameOverScreen);
            frame.remove(match);
        }
    }
    
    private void updateDisplays()
    {
        roundChar.setText(Integer.toString(gameNumber) +
                "/" + 
                Integer.toString(menu.getRounds()));
        winsChar.setText(Integer.toString(humanScore));
        lossesChar.setText(Integer.toString(computerScore));
    }
    
    private class EventHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            if(e.getSource() == next)
            {
                setVisible(false);
                game = new NimGame(frame, match);
            }
            else if(e.getSource() == concede)
            {
                setVisible(false);
                GameOverScreen gameOverScreen = new GameOverScreen(menu, frame,
                        Constants.LOSE);
                frame.add(gameOverScreen);
                frame.remove(match);
            }
        }
    }
}