/**
 * Launches the game GUI.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/05/17)
 */
public class Launcher
{
    public static void main(String[] args)
    {
        NimGameGUI game = new NimGameGUI();
    }
}