/**
 * Game over screen for when match fininishes. Returns to menu.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/05/17)
 */
import java.io.*;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class GameOverScreen extends JPanel
{
    private Image image;
    private GameMenu menu;
    private NimGameGUI frame;
    private JPanel screen;
    
    public GameOverScreen(GameMenu menu, NimGameGUI frame, int condition)
    {
        screen = this;
        this.menu = menu;
        this.frame = frame;
        
        try
        {
            if(condition == Constants.WIN)
            {
                image = ImageIO.read(new File("win.png"));
            }
            else if(condition == Constants.LOSE)
            {
                image = ImageIO.read(new File("lose.png"));
            }
            else if(condition == Constants.TIE)
            {
                image = ImageIO.read(new File("tie.png"));
            }
        }
        catch(IOException ex)
        {
        }
        MouseHandler handler = new MouseHandler();
        screen.addMouseListener(handler);
    }
    
    @Override
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        g.drawImage(image, 0, 0, this.getWidth(), this.getHeight(), null);
    }
    
    private class MouseHandler implements MouseListener
    {
        @Override
        public void mouseClicked(MouseEvent e)
        {
            if(e.getSource() == screen)
            {
                menu.setVisible(true);
                frame.remove(screen);
            }
        }
        
        //Won't compile unless these are overriden.
        @Override
        public void mousePressed(MouseEvent e)
        {
        }
        @Override
        public void mouseReleased(MouseEvent e)
        {
        }
        @Override
        public void mouseEntered(MouseEvent e)
        { 
        }
        @Override
        public void mouseExited(MouseEvent e)
        {
        }
    }
}