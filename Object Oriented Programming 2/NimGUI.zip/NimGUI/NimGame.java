/**
 * Main UI and driver for Nim game.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/05/17)
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
public class NimGame extends JPanel
{
    private JPanel grid;
    private JButton pickUp1;
    private JButton pickUp2;
    private JButton pickUp3;
    private JButton concede;
    private JTextPane humanDisplay;
    private JTextPane middleDisplay;
    private JTextPane computerDisplay;
    private JTextArea status;
    
    private NimGameGUI frame;
    private NimMatch match;
    private NimGame game;
    
    private int unclaimedSticks;
    private int playerSticks;
    private int computerSticks;
    private int difficulty;
    private int goesFirst;
    public NimGame(NimGameGUI frame, NimMatch match)
    {
        this.frame = frame;
        this.match = match;
        game = this;
        frame.add(this);
        
        unclaimedSticks = match.getMenu().getStartingSticks();
        playerSticks = 0;
        computerSticks = 0;
        difficulty = match.getMenu().getDifficulty();
        initGoesFirst();
        //****************************************
        setLayout(new BorderLayout());
        
        JPanel controls = new JPanel(new GridLayout(1, 0, 5, 5));
        add(controls, BorderLayout.NORTH);
        
        pickUp1 = new JButton("TAKE 1");
        pickUp1.setEnabled(unclaimedSticks >= 1);
        controls.add(pickUp1);
        
        pickUp2 = new JButton("TAKE 2");
        pickUp2.setEnabled(unclaimedSticks >= 2);
        controls.add(pickUp2);
        
        pickUp3 = new JButton("TAKE 3");
        pickUp3.setEnabled(unclaimedSticks >= 3);
        controls.add(pickUp3);
        
        controls.add(new JPanel());
        controls.add(new JPanel());
        controls.add(new JPanel());
        
        concede = new JButton("CONCEDE");
        controls.add(concede);
        
        SimpleAttributeSet alignCenter = new SimpleAttributeSet();
        StyleConstants.setAlignment(alignCenter, StyleConstants.ALIGN_CENTER);
        
        humanDisplay = new JTextPane();
        humanDisplay.setPreferredSize(new Dimension(150, 300));
        humanDisplay.setText("PLAYER");
        StyledDocument doc1 = humanDisplay.getStyledDocument();
        doc1.setParagraphAttributes(0, doc1.getLength(), alignCenter, false);
        humanDisplay.setFont(Constants.coolFont);
        humanDisplay.setEditable(false);
        add(humanDisplay, BorderLayout.WEST);
        
        middleDisplay = new JTextPane();
        middleDisplay.setText(getUnclaimedSticksAsString());
        StyledDocument doc2 = middleDisplay.getStyledDocument();
        doc2.setParagraphAttributes(0, doc2.getLength(), alignCenter, false);
        middleDisplay.setFont(Constants.coolFont);
        middleDisplay.setEditable(false);
        add(middleDisplay, BorderLayout.CENTER);
        
        computerDisplay = new JTextPane();
        computerDisplay.setPreferredSize(new Dimension(150, 300));
        computerDisplay.setText("COMPUTER");
        StyledDocument doc3 = computerDisplay.getStyledDocument();
        doc3.setParagraphAttributes(0, doc3.getLength(), alignCenter, false);
        computerDisplay.setFont(Constants.coolFont);
        computerDisplay.setEditable(false);
        add(computerDisplay, BorderLayout.EAST);
        
        status = new JTextArea();
        status.setEditable(false);
        status.setText("There are " + unclaimedSticks + " sticks left.\n");
        JScrollPane scroll = new JScrollPane(status);
        scroll.setPreferredSize(new Dimension(0, 100));
        add(scroll, BorderLayout.SOUTH);
        
        EventHandler handler = new EventHandler();
        pickUp1.addActionListener(handler);
        pickUp2.addActionListener(handler);
        pickUp3.addActionListener(handler);
        concede.addActionListener(handler);
        //****************************************
        if(goesFirst == Constants.COMPUTER_PLAYER)
        {
            computerMoves();
        }
    }
    
    private void initGoesFirst()
    {
        int currentRound = match.getGameNumber();
        int startedMatchFirst = match.getMenu().getGoesFirst();
        
        goesFirst = 1 - (currentRound - startedMatchFirst) % 2;
    }
    
    public int getUnclaimedSticks()
    {
        return unclaimedSticks;
    }
    public String getUnclaimedSticksAsString()
    {
        String string = "";
        
        for(int i = 0; i < unclaimedSticks; i++)
        {
            string += " | ";
        }
        
        return string;
    }
    public void setUnclaimedSticks(int unclaimedSticks)
    {
        this.unclaimedSticks = unclaimedSticks;
    }
    
    public int getPlayerSticks()
    {
        return playerSticks;
    }
    public String getPlayerSticksAsString()
    {
        String string = "";
        
        for(int i = 0; i < playerSticks; i++)
        {
            string += " | ";
        }
        
        return string;
    }
    public void setPlayerSticks(int playerSticks)
    {
        this.playerSticks = playerSticks;
    }
    
    public int getComputerSticks()
    {
        return computerSticks;
    }
    public String getComputerSticksAsString()
    {
        String string = "";
        
        for(int i = 0; i < computerSticks; i++)
        {
            string += " | ";
        }
        
        return string;
    }
    public void setComputerSticks(int computerSticks)
    {
        this.computerSticks = computerSticks;
    }
    
    private void computerMoves()
    {
        int maximumSticks = Math.min(3, unclaimedSticks);
        
        if(difficulty == Constants.HARD_DIFFICULTY && (unclaimedSticks - 1) % 4 != 0)
        {
            computerClaimsSticks((unclaimedSticks - 1) % 4);
        }
        else //if(difficulty == Constants.EASY_DIFFICULTY)
        {
            computerClaimsSticks((int)(Math.random() * maximumSticks + 1));
        }
    }
    
    private void checkHumanLoses()
    {
        if(unclaimedSticks == 0)
        {
            match.computerWins();
            match.setVisible(true);
            frame.remove(game);
        }
    }
    
    private void checkComputerLoses()
    {
        if(unclaimedSticks == 0)
        {
            match.humanWins();
            match.setVisible(true);
            frame.remove(game);
        }
    }
    
    private void humanClaimsSticks(int claimed)
    {
        playerSticks += claimed;
        unclaimedSticks -= claimed;
        updateDisplays();
        updateButtons();
        status.append("You took " + claimed + " sticks.\n" +
                "There are " + unclaimedSticks + " sticks left.\n");
        checkHumanLoses();
    }
    
    private void computerClaimsSticks(int claimed)
    {
        computerSticks += claimed;
        unclaimedSticks -= claimed;
        updateDisplays();
        updateButtons();
        status.append("The computer took " + claimed + " sticks.\n" +
                "There are " + unclaimedSticks + " sticks left.\n");
        checkComputerLoses();
    }
    
    private void updateDisplays()
    {
        humanDisplay.setText("HUMAN\n" + getPlayerSticksAsString());
        middleDisplay.setText(getUnclaimedSticksAsString());
        computerDisplay.setText("COMPUTER\n" + getComputerSticksAsString());
    }
    
    private void updateButtons()
    {
        pickUp1.setEnabled(unclaimedSticks >= 1);
        pickUp2.setEnabled(unclaimedSticks >= 2);
        pickUp3.setEnabled(unclaimedSticks >= 3);
    }
    
    private class EventHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            if(e.getSource() == pickUp1)
            {
                humanClaimsSticks(1);
                computerMoves();
            }
            else if(e.getSource() == pickUp2)
            {
                humanClaimsSticks(2);
                computerMoves();
            }
            else if(e.getSource() == pickUp3)
            {
                humanClaimsSticks(3);
                computerMoves();
            }
            else if(e.getSource() == concede)
            {
                match.computerWins();
                match.setVisible(true);
                frame.remove(game);
            }
        }
    }
}