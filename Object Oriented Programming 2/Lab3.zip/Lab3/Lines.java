/**
 * Class for line objects.
 * 
 * @author (Christian Wendlandt/Copied from Pearson Education) 
 * @version (02/20/17)
 */
import java.awt.Color;
import java.awt.Graphics;
public class Lines
{
   private int x1;
   private int y1;
   private int x2;
   private int y2;
   private Color color;

   public Lines(double x1, double y1, double x2, double y2, Color color)
   {
      this.x1 = (int)x1; 
      this.y1 = (int)y1; 
      this.x2 = (int)x2; 
      this.y2 = (int)y2; 
      this.color = color; 
   } 
   
   public void draw(Graphics g)
   {
      g.setColor(color);
      g.drawLine(x1, y1, x2, y2);
   }
}