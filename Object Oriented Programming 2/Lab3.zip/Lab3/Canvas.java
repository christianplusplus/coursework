/**
 * Creates a painted canvas.
 * 
 * @author (Christian Wendlandt) 
 * @version (02/20/17)
 */
import java.awt.*;
import javax.swing.JPanel;
public class Canvas extends JPanel
{
    private Lines[] lines;
    
    public Canvas()
    {
        setBackground(Color.WHITE);
        
        lines = new Lines[100];
        
        //Drawing some tangent lines of the function y=x^3-2x^2-5x+6.
        double x;
        double displayX;
        double y;
        double displayY;
        double dydx; //dydx is the slope of the tangent lines.
        for(int i = 0; i < lines.length; i++)
        {
            Color customColor = new Color((int)(Math.random()*255), (int)(Math.random()*255), (int)(Math.random()*255));
            
            x = i / 5. - 10;
            y = x * x * x - 2 * x * x - 5 * x + 6;
            dydx = 3 * x * x - 4 * x - 5;  //Using calculus and mapping to construct these formulas.
            displayX = x * 25 + 250;
            displayY = (250 - 20*y);
            lines[i] = new Lines(displayX - 15,
                                 displayY + 15 * dydx,
                                 displayX + 15,
                                 displayY - 15 * dydx,
                                 customColor);
        }
    }
    
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        
        for(Lines line: lines)
            line.draw(g);
    }
}