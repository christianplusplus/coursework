/**
 * Driver to test DataSet and provide user interface.
 * 
 * @author (Christian Wendlandt) 
 * @version (02/17/17)
 */
import java.util.InputMismatchException;
import java.util.Scanner;
public class DataSetTestDriver
{
    public static void main(String[] args)
    {
        DataSet data = new DataSet(1);
        boolean run = true;
        
        do
        {
            System.out.println("Menu: Enter a command. - ADD data item - DELETE data item\n"
                             + "DISPLAY data set - CLEAR data set - INSERT data item - QUIT\n");
            switch(askMenu())
            {
                case "ADD":
                    System.out.println("Enter an integer.\n");
                    data.addDatum(askNumber());
                    break;
                case "DELETE":
                    System.out.println("Enter an index.\n");
                    data.deleteDatumAt(askDeleteIndex(data));
                    break;
                case "DISPLAY":
                    data.display();
                    break;
                case "CLEAR":
                    System.out.println("Data set cleared.\n");
                    data.clear();
                    break;
                case "INSERT":
                    System.out.println("Enter an integer, then an index.\n");
                    data.insert(askNumber(), askInsertIndex(data));
                    break;
                case "QUIT":
                    System.out.print("Thank you.");
                    run = false;
                    break;
            }
        } while (run);
    }
    
    private static String askMenu()
    {
        Scanner scan = new Scanner(System.in);
        String input;
        
        do
        {
            System.out.print(">");
            input = scan.next().toUpperCase();
            System.out.println();
            
            if(        input.equals("ADD")
                    || input.equals("DELETE")
                    || input.equals("DISPLAY")
                    || input.equals("CLEAR")
                    || input.equals("INSERT")
                    || input.equals("QUIT"))
                break;
            System.out.println("Invalid input. Enter the first word of the command you want to execute.\nThis is case-insensitive.\n");
        } while(true);
        
        return input;
    }
    
    private static int askNumber()
    {
        Scanner scan = new Scanner(System.in);
        int input = 0;
        boolean validInput;
        
        do
        {
            System.out.print(">");
            try
            {
                input = scan.nextInt();
                validInput = true;
            }
            catch(InputMismatchException e)
            {
                validInput = false;
                scan.nextLine();
            }
            System.out.println();
            if(validInput)
                break;
            System.out.println("Invalid input. Enter an integer.\n");
        } while(true);
        
        return input;
    }
    
    private static int askDeleteIndex(DataSet data)
    {
        Scanner scan = new Scanner(System.in);
        int input = 0;
        boolean validInput = false;
        
        do
        {
            System.out.print(">");
            try
            {
                input = scan.nextInt();
                if(input >= 0 && input < data.getCount())
                    validInput = true;
            }
            catch(InputMismatchException e)
            {
                validInput = false;
                scan.nextLine();
            }
            System.out.println();
            if(validInput)
                break;
            System.out.println("Invalid input. Enter an integer from 0 to " + (data.getCount() - 1) + ".\n");
        } while(true);
        
        return input;
    }
    
    private static int askInsertIndex(DataSet data)
    {
        Scanner scan = new Scanner(System.in);
        int input = 0;
        boolean validInput = false;
        
        do
        {
            System.out.print(">");
            try
            {
                input = scan.nextInt();
                if(input >= 0 && input <= data.getCount())
                    validInput = true;
            }
            catch(InputMismatchException e)
            {
                validInput = false;
                scan.nextLine();
            }
            System.out.println();
            if(validInput)
                break;
            System.out.println("Invalid input. Enter an integer from 0 to " + data.getCount() + ".\n");
        } while(true);
        
        return input;
    }
}
