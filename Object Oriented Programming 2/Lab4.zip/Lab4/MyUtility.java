/**
 * Utility class for sorting arrays.
 * 
 * @author (Christian Wendlandt) 
 * @version (02/27/17)
 */
public class MyUtility
{
    public static int[] bubbleSort(int[] dataSet, int count)
    {
        int[] sortedSet = new int[count];
        boolean wasSwapped = false;
        int temp;
        
        for(int i = 0; i < count; i++)
        {
            sortedSet[i] = dataSet[i];
        }
        
        for(int i = count - 1; i > 0; i--)
        {
            for(int j = 0; j < i; j++)
            {
                if(sortedSet[j] > sortedSet[j + 1])
                {
                    temp = sortedSet[j + 1];
                    sortedSet[j + 1] = sortedSet[j];
                    sortedSet[j] = temp;
                    wasSwapped = true;
                }
            }
            if(!wasSwapped)
            {
                break;
            }
        }
        
        return sortedSet;
    }
    
    public static int[] selectionSort(int[] dataSet, int count)
    {
        int[] sortedSet = new int[count];
        int minIndex;
        int temp;
        int j;
        
        for(int i = 0; i < count; i++)
        {
            sortedSet[i] = dataSet[i];
        }
        
        for(int i = 0; i < count - 1; i++)
        {
            minIndex = i;
            for(j = i + 1; j < count; j++)
            {
                if(sortedSet[minIndex] > sortedSet[j])
                {
                    minIndex = j;
                }
            }
            temp = sortedSet[minIndex];
            sortedSet[minIndex] = sortedSet[i];
            sortedSet[i] = temp;
        }
        
        return sortedSet;
    }
    
    public static int[] insertionSort(int[] dataSet, int count)
    {
        int[] sortedSet = new int[count];
        int temp;
        
        for(int i = 0; i < count; i++)
        {
            sortedSet[i] = dataSet[i];
        }
        
        int index;
        for(int i = 1; i < count; i++)
        {
            index = i;
            while(index > 0 && sortedSet[index] < sortedSet[index - 1])
            {
                temp = sortedSet[index];
                sortedSet[index] = sortedSet[index - 1];
                sortedSet[index-- - 1] = temp;
            }
        }
        
        return sortedSet;
    }
    
    public static int sequentialSearch(int[] array, int item, int count)
    {
        int index = -1;
        
        for(int i = 0; i < count; i++)
        {
            if(array[i] == item)
            {
                index = i;
                break;
            }
        }
        
        return index;
    }
    
    public static int binarySearch(int[] array, int item, int count)
    {
        int index = -1;
        int low = 0;
        int high = count - 1;
        int mid;
        
        while(low <= high)
        {
            mid = low + (high - low) / 2;
            if(array[mid] == item)
            {
                index = mid;
                break;
            }
            else if(array[mid] < item)
            {
                low = mid + 1;
            }
            else
            {
                high = mid - 1;
            }
        }
        
        return index;
    }
}