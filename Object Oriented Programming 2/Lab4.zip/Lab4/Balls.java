/**
 * Class for ball objects.
 * 
 * @author (Christian Wendlandt/Copied from Pearson Education) 
 * @version (02/27/17)
 */
import java.awt.*;
public class Balls
{
   private int x;
   private int y;
   private int radius;
   private Color color;

   public Balls(double x, double y, double radius, Color color)
   {
      this.x = (int)x; 
      this.y = (int)y; 
      this.radius = (int)radius;
      this.color = color; 
   }
   public Balls(double x, double y, double radius)
   {
      this.x = (int)x; 
      this.y = (int)y; 
      this.radius = (int)radius;
      this.color = new Color((int)(Math.random()*255), (int)(Math.random()*255), (int)(Math.random()*255));
   }
   
   public void draw(Graphics2D g2d)
   {
      g2d.setColor(color);
      g2d.fillOval(x, y, radius, radius);
   }
}