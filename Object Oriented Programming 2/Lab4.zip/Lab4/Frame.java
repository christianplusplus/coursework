/**
 * Attaches painted canvas to frame.
 * 
 * @author (Christian Wendlandt) 
 * @version (02/27/17)
 */
import javax.swing.JFrame;
public class Frame
{
    public static void main(String[] args)
    {
        Canvas canvas = new Canvas();
        JFrame frame = new JFrame();
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(canvas);
        frame.setSize(500, 500);
        frame.setVisible(true);
    }
}