/**
 * Creates a painted canvas.
 * 
 * @author (Christian Wendlandt) 
 * @version (02/27/17)
 */
import java.awt.*;
import javax.swing.JPanel;
public class Canvas extends JPanel
{
    private Balls[] balls;
    
    public Canvas()
    {
        setBackground(Color.WHITE);
        
        balls = new Balls[100];
        
        double radius;
        double x;
        double displayX;
        double y;
        double displayY;
        for(int i = 0; i < balls.length; i++)
        {
            //Color customColor = new Color((int)(Math.random()*255), (int)(Math.random()*255), (int)(Math.random()*255));
            
            x = i / 5.;
            if(x < Math.sqrt(15/4.9))
                y = 15 - 4.9 * x * x;
            else if(x < 3 * Math.sqrt(15/4.9))
                y = 7.5 - 4.9 * (x - 2 * Math.sqrt(15/4.9)) * (x - 2 * Math.sqrt(15/4.9));
            else if(x < 5 * Math.sqrt(15/4.9))
                y = 3.75 - 4.9 * (x - 4 * Math.sqrt(15/4.9)) * (x - 4 * Math.sqrt(15/4.9));
            else if(x < 7 * Math.sqrt(15/4.9))
                y = 1.875 - 4.9 * (x - 6 * Math.sqrt(15/4.9)) * (x - 6 * Math.sqrt(15/4.9));
            else if(x < 9 * Math.sqrt(15/4.9))
                y = .9375 - 4.9 * (x - 8 * Math.sqrt(15/4.9)) * (x - 8 * Math.sqrt(15/4.9));
            else if(x < 11 * Math.sqrt(15/4.9))
                y = .46875 - 4.9 * (x - 10 * Math.sqrt(15/4.9)) * (x - 10 * Math.sqrt(15/4.9));
            else
                y = 234375 - 4.9 * (x - 12 * Math.sqrt(15/4.9)) * (x - 12 * Math.sqrt(15/4.9));
            
            displayX = x * 25;
            displayY = (400 - 25*y);
            balls[i] = new Balls(displayX,
                                 displayY,
                                 20);//Overloaded the constructor so that the color is defaulted to random.
        }
    }
    
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        
        for(Balls ball: balls)
        {
            ball.draw(g2d);
        }
    }
}