/**
 * Produces a set of integers with methods to return information on the set.
 * 
 * @author (Christian Wendlandt) 
 * @version (02/27/17)
 */
public class DataSet
{
    private int[] dataSet;
    private int count;
    
    public DataSet()
    {
        dataSet = new int[100];
    }
    public DataSet(int size)
    {
        dataSet = new int[size];
    }
    
    public int getDatum(int index)
    {
        return dataSet[index];
    }
    
    public void setDataSet(int[] dataSet)
    {
        this.dataSet = dataSet;
    }
    
    public int getCount()
    {
        return count;
    }
    public void setCount(int count)
    {
        this.count = count;
    }
    
    public int getMin()
    {
        int min = Integer.MAX_VALUE;
        
        for(int i = 0; i < count; i++)
        {
            if(dataSet[i] < min)
            {
                min = dataSet[i];
            }
        }
        
        return min;
    }
    
    public int getMax()
    {
        int max = Integer.MIN_VALUE;
        
        for(int i = 0; i < count; i++)
        {
            if(dataSet[i] > max)
            {
                max = dataSet[i];
            }
        }
        
        return max;
    }
    
    public double getAvg()
    {
        double avg = 0;
        
        for(int i = 0; i < count; i++)
        {
            avg += dataSet[i];
        }
        avg /= count;
        
        return avg;
    }
    
    public double getStdDev()
    {
        double stdDev = 0;
        double avg = getAvg();
        
        for(int i = 0; i < count; i++)
        {
            stdDev += (dataSet[i] - avg) * (dataSet[i] - avg);
        }
        stdDev = Math.sqrt(stdDev / count);
        
        return stdDev;
    }
    
    public void addDatum(int datum)
    {
        if(isFull())
        {
            makeDataSetBigger();
        }
        dataSet[count] = datum;
        count++;
    }
    
    public void deleteDatumAt(int index)
    {
        for(int i = index; i < count - 1; i++)
        {
            dataSet[i] = dataSet[i + 1];
        }
        count--;
    }
    
    public void display()
    {
        if(count <= 0)
        {
            System.out.println("Nothing to display.\n");
        }
        else
        {
            for(int i = 0; i < count; i++)
            {
                if(i % 5 == 0) //Left brackets.
                {
                    System.out.print("[");
                }
                System.out.printf("[%4d]", dataSet[i]); //The data.
                if(i % 5 != 4) //Formats end of cells.
                {
                    if(i < count - 1) //Commas.
                    {
                        System.out.print(",");
                    }
                }
                else
                {
                    System.out.print("]"); //Right brackets.
                    if(i < count - 1)
                    {
                        System.out.println();
                    }
                }
            }
            
            if(count % 5 != 0 && count > 5) //Fills out first row if it's too short.
            {
                for(int i = 0; i < (5 - count % 5); i++)
                {
                    System.out.print(",[    ]"); //Extra cells.
                }
                System.out.print("]"); //Last bracket.
            }
            else if(count % 5 != 0 && count < 5)
            {
                System.out.print("]"); //Last bracket.
            }
            
            System.out.printf("\n\n"           //Formats print underneath table.
                             + "Minimum: %d\n"
                             + "Maximum: %d\n"
                             + "Average: %.4f\n"
                             + "Standard Deviation: %.4f\n\n",
                             getMin(), getMax(), getAvg(), getStdDev());
        }
    }
    
    public void clear()
    {
        count = 0;
    }
    
    public void insert(int datum, int index)
    {
        if(isFull())
        {
            makeDataSetBigger();
        }
        for(int i = count; i > index; i--)
        {
            dataSet[i] = dataSet[i - 1];
        }
        dataSet[index] = datum;
        count++;
    }
    
    private void makeDataSetBigger()
    {
        int[] newSet = new int[dataSet.length * 2 + 1];
        
        for(int i = 0; i < count; i++)
        {
            newSet[i] = dataSet[i];
        }
        dataSet = newSet;
    }
    
    public boolean isEmpty()
    {
        boolean check = count <= 0 ? true : false;
        
        return check;
    }
    
    public boolean isFull()
    {
        boolean check = count >= dataSet.length ? true : false;
        
        return check;
    }
    
    public DataSet shuffle()
    {
        DataSet shuffledSet = new DataSet(count);
        
        for(int i = 0; i < count; i++)
        {
            shuffledSet.insert(dataSet[i], (int) (Math.random() * (shuffledSet.getCount() + 1)));
        }
        
        return shuffledSet;
    }
    
    public DataSet getSetBubbleSorted()
    {
        DataSet sortedSet = new DataSet(count);
        
        sortedSet.setCount(count);
        sortedSet.setDataSet(MyUtility.bubbleSort(dataSet, count));
        
        return sortedSet;
    }
    
    public DataSet getSetSelectionSorted()
    {
        DataSet sortedSet = new DataSet(count);
        
        sortedSet.setCount(count);
        sortedSet.setDataSet(MyUtility.selectionSort(dataSet, count));
        
        return sortedSet;
    }
    
    public DataSet getSetInsertionSorted()
    {
        DataSet sortedSet = new DataSet(count);
        
        sortedSet.setCount(count);
        sortedSet.setDataSet(MyUtility.insertionSort(dataSet, count));
        
        return sortedSet;
    }
    
    public int contains(int item)
    {
        return MyUtility.sequentialSearch(dataSet, item, count);
    }

    public boolean equals(Object o)
    {
        boolean check = false;
        
        if(o instanceof DataSet)
        {
            check = true;
            DataSet dataSet = (DataSet) o;
            if(count == dataSet.getCount())
            {
                for(int i = 0; i < count; i++)
                {
                    check = check && this.dataSet[i] == dataSet.getDatum(i);
                }
            }
            else
            {
                check = false;
            }
        }
        
        return check;
    }
        
    public String toString()
    {
        String str = "";
        
        for(int i = 0; i < count; i++)
        {
            str += String.valueOf(dataSet[i]);
            if(i % 5 != 4 && i != count - 1)
            {
                str += ", ";
            }
            if(i % 5 == 4 && i != count - 1)
            {
                str += "\n";
            }
        }
        
        return str;
    }
}