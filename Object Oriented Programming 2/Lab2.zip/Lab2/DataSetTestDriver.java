/**
 * Driver to test DataSet.
 * 
 * @author (Christian Wendlandt) 
 * @version (02/07/17)
 */
import java.util.InputMismatchException;
import java.util.Scanner;
public class DataSetTestDriver
{
    public static void main(String[] args)
    {
        DataSet data = new DataSet(3);
        Scanner scan = new Scanner(System.in);
        boolean inputValid = false;
        int input = 1;
        
        while(input != 0)
        {
            if(inputValid)
                data.addDatum(input);
            System.out.print(">");
            try
            {
                input = scan.nextInt();
                System.out.println();
                inputValid = true;
            }
            catch(InputMismatchException e)
            {
                System.out.println("Not an integer.");
                scan.nextLine();
                inputValid = false;
            }
        }
        if(data.getCount() > 0)
        {
            System.out.println("Max: " + data.getMin());
            System.out.println("Minimum: " + data.getMax());
            System.out.println("Average: " + data.getAvg());
            System.out.println("Standard Deviation: " + data.getStdDev());
        }
        else
            System.out.println("No data entered.");
    }
}
