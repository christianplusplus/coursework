/**
 * Driver to test DataSet.
 * 
 * @author (Christian Wendlandt) 
 * @version (02/08/17)
 */
public class MagicSquareTestDriver
{
    public static void main(String[] args)
    {
        int[][] array1 = {{1,15,15,4},
                         {12,6,7,9},
                         {8,10,11,5},
                         {13,3,2,16}};
        System.out.println(MagicSquare.toString(array1));
        System.out.println("Is array1 a magic square? " + MagicSquare.isMagic(array1));
        System.out.println();
        
        int[][] array2 = {{11,10,4,23,17},
                          {18,12,6,5,24},
                          {25,19,13,7,1},
                          {2,21,20,14,8},
                          {9,3,22,16,15}};
        System.out.println(MagicSquare.toString(array2));
        System.out.println("Is array2 a magic square? " + MagicSquare.isMagic(array2));
    }
}