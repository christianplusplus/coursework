/**
 * Returns true if an array of integers is a "Magic Square".
 * 
 * @author (Christian Wendlandt) 
 * @version (02/10/17)
 */
public class MagicSquare
{
    public static boolean isMagic(int[][] array)
    {
        boolean check;
        int sum = 0;
        
        check = isSquare(array);
        if(check)
        {
            for(int i : array[0]) //Finds the sum of the first row;
                sum += i;
            check = check
                    && equalRows(sum, array)
                    && equalColumns(sum, array)
                    && equalMainDiagonal(sum, array)
                    && equalOffDiagonal(sum, array);
        }
        
        return check;
    }
    
    private static boolean isSquare(int[][] array)
    {
        boolean check = true;
        
        for(int[] row : array)
            check = check && row.length == array.length;
        
        return check;
    }
    
    private static boolean equalRows(int sum, int[][] array) //The first row sum is given.
    {
        boolean check = true;
        int newSum;
        
        for(int i = 1; i < array.length; i++)
        {
            newSum = 0;
            for(int j : array[i])
                newSum += j;
            check = check && sum == newSum;
        }
        
        return check;
    }
    
    private static boolean equalColumns(int sum, int[][] array)
    {
        boolean check = true;
        int newSum;
        
        for(int i = 0; i < array.length; i++)
        {
            newSum = 0;
            for(int j = 0; j < array.length; j++)
                newSum += array[j][i];
            check = check && sum == newSum;
        }
        
        return check;
    }
    
    private static boolean equalMainDiagonal(int sum, int[][] array)
    {
        boolean check;
        int newSum = 0;
        
        for(int i = 0; i < array.length; i++)
            newSum += array[i][i];
        check = sum == newSum;
        
        return check;
    }
    
    private static boolean equalOffDiagonal(int sum, int[][] array)
    {
        boolean check;
        int newSum = 0;
        
        for(int i = 0; i < array.length; i++)
            newSum += array[array.length - i -1][i];
        check = sum == newSum;
        
        return check;
    }
    
    public static String toString(int[][] array)
    {
        String str = "";
        
        for(int[] row : array)
        {
            for(int j : row)
                str += String.format("%3d", j);
            str += "\n";
        }
        
        return str;
    }
}