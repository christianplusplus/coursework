/**
 * Creates a painted canvas.
 * 
 * @author (Christian Wendlandt) 
 * @version (02/10/17)
 */
import java.awt.*;
import javax.swing.JPanel;
public class Canvas extends JPanel
{
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        
        double leftBound = -1; //The Domain of the function.
        double rightBound = 1;
        
        double lowerBound = -2.5; //(upperBound - lowerBound)*scale should typically be the size of your frame.
        double upperBound = 2.5;
        
        double equationSplit = 1; //The location of the sign swap.
        
        int originX = 250; //Normally at the center of your frame.
        int originY = 250;
        
        double stretchX = 2;
        double stretchY = 1.5;
        int scale = 100;
        
        int sign;
        
        //A heart, using the equation y=(+ or -)sqrt(1-x^2)+x^(2/3).
        //At this point, the code is not very portable.
        //I might be able to turn this into some sort of graphing application further down the road.
        
        g.setColor(Color.RED);
        sign = 1;
        for(int i = originX + (int)(stretchX * scale * leftBound); i <= originX + (int)(stretchX * scale * rightBound); i++) //Top half of the equation.
            for(int j = (int)(stretchY * scale * equationSplit); j <= originY + upperBound * scale; j++)
                if(j == (int)(stretchY * scale * equationHeart(sign, i, originX, stretchX * scale)))
                {
                    g.drawLine(i, originY - j, i, originY - (int)(stretchY * scale));
                    break;
                }
        sign = -1;
        for(int i = originX + (int)(stretchX * scale * leftBound); i <= originX + (int)(stretchX * scale * rightBound); i++) //Bottom half of the equation.
            for(int j = (int)(lowerBound * scale); j <= stretchY * scale * equationSplit; j++)
                if(j == (int)(stretchY * scale * equationHeart(sign, i, originX, stretchX * scale)))
                {
                    g.drawLine(i, originY - j, i, originY - (int)(stretchY * scale));
                    break;
                }
    }
    
    private double equationHeart(int sign, double x, int originX, double stretchX) //y=(+ or -)sqrt(1-x^2)+x^(2/3)
    {
        return sign * Math.sqrt(1 - (x - originX) / stretchX * (x - originX) / stretchX) + Math.pow(Math.pow((x - originX) / stretchX, 2), (double)1 / 3);
    }
}