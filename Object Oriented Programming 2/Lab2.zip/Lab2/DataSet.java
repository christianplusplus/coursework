/**
 * Produces a set of integers with methods to return information on the set.
 * 
 * @author (Christian Wendlandt) 
 * @version (02/07/17)
 */
public class DataSet
{
    private int[] dataSet;
    private int count;
    
    public DataSet()
    {
        dataSet = new int[100];
    }
    public DataSet(int size)
    {
        dataSet = new int[size];
    }
    
    public int getCount()
    {
        return count;
    }
    public void incrementCount()
    {
        count++;
    }
    
    public int getMin()
    {
        int min = Integer.MAX_VALUE;
        
        for(int i = 0; i < count; i++)
            if(dataSet[i] < min)
                min = dataSet[i];
        return min;
    }
    
    public int getMax()
    {
        int max = Integer.MIN_VALUE;
        
        for(int i = 0; i < count; i++)
            if(dataSet[i] > max)
                max = dataSet[i];
        return max;
    }
    
    public double getAvg()
    {
        double avg = 0;
        
        for(int i = 0; i < count; i++)
            avg += dataSet[i];
        avg /= count;
        return avg;
    }
    
    public double getStdDev()
    {
        double stdDev = 0;
        double avg = getAvg();
        
        for(int i = 0; i < count; i++)
            stdDev += (dataSet[i] - avg) * (dataSet[i] - avg);
        stdDev = Math.sqrt(stdDev / count);
        return stdDev;
    }
    
    public void addDatum(int datum)
    {
        if(!isFull())
        {
            dataSet[count] = datum;
            incrementCount();
        }
        else
        {
            makeDataSetBigger();
            dataSet[count] = datum;
            incrementCount();
        }
    }
    
    private void makeDataSetBigger()
    {
        int[] newSet = new int[dataSet.length * 2];
        
        for(int i = 0; i < count; i++)
            newSet[i] = dataSet[i];
        dataSet = newSet;
    }
    
    public boolean isEmpty()
    {
        boolean check = count == 0 ? true : false;
        
        return check;
    }
    
    public boolean isFull()
    {
        boolean check = count == dataSet.length ? true : false;
        
        return check;
    }
}