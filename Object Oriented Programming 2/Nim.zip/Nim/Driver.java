/**
 * Initializes the program and constructs the match.
 * 
 * @author (Christian Wendlandt) 
 * @version (02/06/17)
 */
public class Driver
{
    public static void main(String[] args)
    {
        NimMatch nimMatch = new NimMatch();
        nimMatch.playMatch();
    }
}