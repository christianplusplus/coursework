/**
 * Represents and initializes a series of Nim games.
 * 
 * @author (Christian Wendlandt) 
 * @version (02/06/17)
 */
import java.util.Scanner;
public class NimMatch
{
    private int humanScore;
    private int computerScore;
    private int gameNumber;
    private Scanner scan = new Scanner(System.in);
    private String input;
    
    NimMatch()
    {
        setHumanScore(0);
        setComputerScore(0);
        setGameNumber(1);
    }
    
    public int getHumanScore()
    {
        return humanScore;
    }
    public int getComputerScore()
    {
        return computerScore;
    }
    public int getGameNumber()
    {
        return gameNumber;
    }
    
    public void setHumanScore(int humanScore)
    {
        this.humanScore = humanScore;
    }
    public void setComputerScore(int computerScore)
    {
        this.computerScore = computerScore;
    }
    public void setGameNumber(int gameNumber)
    {
        this.gameNumber = gameNumber;
    }
    
    public void playMatch()
    {
        NimGame game;
        int mode;
        int firstGame;
        int winner;
        boolean rematch = true;
        
        mode = askMode();
        firstGame = askFirst(NimGame.getHuman(), NimGame.getComputer());
        while(rematch) //The main loop for starting and playing games.
        {
            game = new NimGame(mode);
            winner = game.playGame(gameNumber, firstMove(firstGame, NimGame.getHuman(), NimGame.getComputer())); //This line starts the game by calling NimGame for a winner.
            if(winner == game.getHuman())
                setHumanScore(getHumanScore() + 1);
            else
                setComputerScore(getComputerScore() + 1);
            gameNumber++;
            rematch = askRematch();
        }
        System.out.println(reportScores());
    }
    
    private int askMode()
    {
        while(true) //The only way to leave this loop is to enter a valid input.
        {
            System.out.println("Enter E for easy or H for hard.");
            input = scan.next();
            switch(input){
                case "e":
                case "E":
                    return 1;
                case "h":
                case "H":
                    return 2;
                default:
                    System.out.println("Not a valid selection.");
            }
        }
    }
    
    private int askFirst(int human, int computer)
    {
        while(true) //The only way to leave this loop is to enter a valid input.
        {
            System.out.println("Enter P for player first or C for computer first.");
            input = scan.next();
            switch(input){
                case "p":
                case "P":
                    return human;
                case "c":
                case "C":
                    return computer;
                default:
                    System.out.println("Not a valid selection.");
            }
        }
    }
    
    private int firstMove(int firstGame, int human, int computer)
    {
        return firstGame == human ? human : computer;
    }
    
    private boolean askRematch()
    {
        while(true) //The only way to leave this loop is to enter a valid input.
        {
            System.out.println("Rematch? Y for yes or N for no.");
            input = scan.next();
            switch(input)
            {
                case "n":
                case "N":
                    return false;
                case "y":
                case "Y":
                    return true;
                default:
                    System.out.println("Not a valid selection.");
            }
        }
    }
    
    public String reportScores()
    {
        String sChar1 = "s"; //Most of this method is just formatting the return string grammar.
        String sChar2 = "s";
        
        if(getHumanScore() == 1)
            sChar1 = "";
        if(getComputerScore() == 1)
            sChar2 = "";
        return "You won " + getHumanScore() + " time" + sChar1 + " and the computer won " + getComputerScore() + " time" + sChar2 + ".";
    }
}