/**
 * Represents and controls a Nim game in progress.
 * 
 * @author (Christian Wendlandt) 
 * @version (02/06/17)
 */
import java.util.InputMismatchException;
import java.util.Scanner;
public class NimGame
{
    private static final int HUMAN = 1;
    private static final int COMPUTER = 2;
    private int sticks;
    private int turn;
    private int winner;
    private int mode;
    
    public NimGame()
    {
        setSticks(15);
        setTurn(1);
        setMode(2);
    }
    public NimGame(int mode)
    {
        setSticks(15);
        setTurn(1);
        setMode(mode);
    }
    
    public static int getHuman()
    {
        return HUMAN;
    }
    public static int getComputer()
    {
        return COMPUTER;
    }
    public int getSticks()
    {
        return sticks;
    }
    public int getTurn()
    {
        return turn;
    }
    public int getWinner()
    {
        return winner;
    }
    public int getMode()
    {
        return mode;
    }
    
    public void setSticks(int sticks)
    {
        this.sticks = sticks;
    }
    public void setTurn(int turn)
    {
        this.turn = turn;
    }
    public void setWinner(int winner)
    {
        this.winner = winner;
    }
    public void setMode(int mode)
    {
        this.mode = mode;
    }
    
    public int playGame(int mode, int first)
    {
        String plurality = "are";
        String sChar = "s";
        
        setTurn(first); //Decides who goes first.
        
        do //Primary game loop.
        {
            if(sticks == 1) //Changes how the following message will be displayed.
            {
                sChar = "";
                plurality = "is";
            }
            System.out.println("There " + plurality + " " + getSticks() + " stick" + sChar + " left.");
            
            if(getTurn() == HUMAN) //Tells either the player or the computer to make a move.
                humanMove();
            else if(getMode() == 1)
                computerMove();
            else
                computerMoveWin();
            endTurn();
            if(userWon())
                setWinner(getTurn());
        } while(!userWon());
        
        if(getWinner() == HUMAN) //Prints a game over screen.
            System.out.println("You win!");
        else
            System.out.println("You lose.");
        return getWinner(); //Returns the winner so that NimMatch can record the result.
    }
    
    public void humanMove()
    {
        Scanner scan = new Scanner(System.in);
        String options;
        int inputNum;
        
        if(getSticks() >= 3) //Changes how intructions will be printed.
            options = "1, 2, or 3.";
        else if(getSticks() == 2)
            options = "1 or 2.";
        else
            options = "1.";
            
        while(true) //The only way to leave this loop is to enter a valid input.
        {
            System.out.println("Enter how many sticks you want to take.\nYou make take " + options);
            try
            {
                inputNum = scan.nextInt();
                switch(inputNum)
                {
                    case 1:
                        if(getSticks() >= 1)
                        {
                            System.out.println("You take 1 stick.");
                            setSticks(getSticks() - 1);
                            return;
                        }
                        System.out.println("Not a valid selection.");
                        break;
                    case 2:
                        if(getSticks() >= 2)
                        {
                            System.out.println("You take 2 stick.");
                            setSticks(getSticks() - 2);
                            return;
                        }
                        System.out.println("Not a valid selection.");
                        break;
                    case 3:
                        if(getSticks() >= 3)
                        {
                            System.out.println("You take 3 stick.");
                            setSticks(getSticks() - 3);
                            return;
                        }
                        System.out.println("Not a valid selection.");
                        break;
                    default:
                        System.out.println("Not a valid selection.");
                }
            }
            catch(InputMismatchException e)
            {
                System.out.println("Not a valid selection.");
                scan.nextLine();
            }
        }
    }
    
    public void computerMove()
    {
        int choice;
        String sChar = "s";
        
        if(getSticks() >= 3) //Choices in these loops are random and based on the number of sticks in play.
        {
            choice = (int)(Math.random() * 3 + 1);
            if(choice == 1)
                sChar = "";
            System.out.println("The computer takes " + choice + " stick" + sChar + ".");
            setSticks(getSticks() - choice);
            return;
        }
        else if(getSticks() == 2)
        {
            choice = (int)(Math.random() * 2 + 1);
            if(choice == 1)
                sChar = "";
            System.out.println("The computer takes " + choice + " stick" + sChar + ".");
            setSticks(getSticks() - choice);
            return;
        }
        else
        {
            System.out.println("The computer takes 1 stick.");
            setSticks(getSticks() - 1);
            return;
        }
    }
    
    public void computerMoveWin()
    {
        int choice;
        String sChar = "s"; //sChar is used for print formatting.
        
        if(getSticks() >= 3) //There are 8 branching paths that the AI can take in order to return a winning move.
        {
            if((getSticks() - 4) % 4 == 0)
            {
                setSticks(getSticks() - 3);
                System.out.println("The computer takes 3 sticks.");
                return;
            }
            else if((getSticks() - 3) % 4 == 0)
            {
                setSticks(getSticks() - 2);
                System.out.println("The computer takes 2 sticks.");
                return;
            }
            else if((getSticks() - 2) % 4 == 0)
            {
                setSticks(getSticks() - 1);
                System.out.println("The computer takes 1 stick.");
                return;
            }
            else
            {
                choice = (int)(Math.random() * 3 + 1);
                if(choice == 1)
                    sChar = "";
                setSticks(getSticks() - choice);
                System.out.println("The computer takes " + choice + " stick" + sChar + ".");
                return;
            }
        }
        else if(getSticks() == 2)
        {
            if((getSticks() - 3) % 4 == 0)
            {
                setSticks(getSticks() - 2);
                System.out.println("The computer takes 2 sticks.");
                return;
            }
            else if((getSticks() - 2) % 4 == 0)
            {
                setSticks(getSticks() - 1);
                System.out.println("The computer takes 1 stick.");
                return;
            }
            else
            {
                choice = (int)(Math.random() * 3 + 1);
                if(choice == 1)
                    sChar = "";
                setSticks(getSticks() - choice);
                System.out.println("The computer takes " + choice + " stick" + sChar + ".");
                return;
            }
        }
        else
        {
            setSticks(getSticks() - 1);
            System.out.println("The computer takes 1 stick.");
            return;
        }
    }
    
    public void endTurn()
    {
        setTurn(getHuman() + getComputer() - getTurn()); //If turn == HUMAN, turn sets to COMPUTER, and vice versa.
    }
    
    public boolean userWon()
    {
        boolean check = getSticks() == 0 ? true : false;
        return check;
    }
}