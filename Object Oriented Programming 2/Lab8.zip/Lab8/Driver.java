/**
 * Driver/Tester for exceptions dataSet<E>.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/07/17)
 */
import java.util.Scanner;
public class Driver
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        DataSet<Integer> data = new DataSet<>();
        
        data.addEx(1);
        data.addEx(2);
        data.addEx(3);
        System.out.print("Added 1, 2, and 3 to the data set.\n" +
                "Error test codes:\n" +
                "1 - addEx(null)\n" +
                "2 - addEx(2)\n" +
                "3 - addEx(4, 6)\n" +
                "4 - addEx(null, 1)\n" +
                "5 - addEx(3, 2)\n" +
                "6 - getEx(5)\n" +
                "7 - setEx(4, 4)\n" +
                "8 - setEx(1, null)\n" +
                "9 - removeEx(5)\n" +
                "10 - removeEx(new Integer(6))\n" +
                "11 - indexOfEx(4)\n" +
                "0 - quit\n\n");
        do
        {
            System.out.print(">");
            try
            {
                switch(scan.nextInt())
                {
                    case 1:
                        data.addEx(null);
                        break;
                    case 2:
                        data.addEx(2);
                        break;
                    case 3:
                        data.addEx(4, 6);
                        break;
                    case 4:
                        data.addEx(null, 1);
                        break;
                    case 5:
                        data.addEx(3, 2);
                        break;
                    case 6:
                        data.getEx(5);
                        break;
                    case 7:
                        data.setEx(4, 4);
                        break;
                    case 8:
                        data.setEx(1, null);
                        break;
                    case 9:
                        data.removeEx(5);
                        break;
                    case 10:
                        data.removeEx(new Integer(6));
                        break;
                    case 11:
                        data.indexOfEx(4);
                        break;
                    case 0:
                        System.exit(0);
                }
            }
            catch(Exception ex)
            {
                System.out.println(ex);
            }
        }while(true);
    }
}