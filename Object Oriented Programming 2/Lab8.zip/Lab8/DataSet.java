/**
 * Produces a set of Generics with methods to return information on the set.
 * 
 * @author (Christian Wendlandt) 
 * @version (04/07/17)
 */
import java.util.NoSuchElementException;
public class DataSet<E>
{
    private E[] dataSet;
    private int count;
    
    public DataSet()
    {
        dataSet = (E[]) new Object[101];
        count = 0;
    }
    
    public int size()
    {
        return count;
    }
    
    public boolean add(E element)
    {
        boolean check = false;
        
        if(element != null && !contains(element))
        {
            if(count == dataSet.length)
            {
                reallocate();
            }
            dataSet[count++] = element;
            check = true;
        }
        
        return check;
    }
    
    public E addEx(E element)
    {
        if(element == null)
        {
            throw new NullPointerException();
        }
        if(contains(element))
        {
            throw new ElementAlreadyExistsException();
        }
        if(count == dataSet.length)
        {
            reallocate();
        }
        dataSet[count++] = element;
        
        return element;
    }
    
    public boolean add(E element, int index)
    {
        boolean check = false;
        
        if(index >= 0 && index <= count && element != null && !contains(element))
        {
            if(count == dataSet.length)
            {
                reallocate();
            }
            for(int i = count; i > index; i--)
            {
                dataSet[i] = dataSet[i - 1];
            }
            dataSet[index] = element;
            count++;
            check = true;
        }
        
        return check;
    }
    
    public E addEx(E element, int index)
    {
        if(index < 0 || index > count)
        {
            throw new IndexOutOfBoundsException();
        }
        if(element == null)
        {
            throw new NullPointerException();
        }
        if(contains(element))
        {
            throw new ElementAlreadyExistsException();
        }
        if(count == dataSet.length)
        {
            reallocate();
        }
        for(int i = count; i > index; i--)
        {
            dataSet[i] = dataSet[i - 1];
        }
        dataSet[index] = element;
        count++;
        
        return element;
    }
    
    public E get(int index)
    {
        E element = null;
        
        if(index >= 0 && index < count)
        {
            element = dataSet[index];
        }
        
        return element;
    }
    
    public E getEx(int index)
    {
        E element;
        
        if(index < 0 || index > count)
        {
            throw new IndexOutOfBoundsException();
        }
        element = dataSet[index];
        
        return element;
    }
    
    public E set(int index, E element)
    {
        E returnElement = null;
        
        if(index >= 0 && index < count && element != null)
        {
            dataSet[index] = element;
            returnElement = element;
        }
        
        return returnElement;
    }
    
    public E setEx(int index, E element)
    {
        if(index < 0 || index > count)
        {
            throw new IndexOutOfBoundsException();
        }
        if(element == null)
        {
            throw new NullPointerException();
        }
        dataSet[index] = element;
        
        return element;
    }
    
    public boolean remove(int index)
    {
        boolean check = false;
        
        if(index >= 0 && index < count)
        {
            for(int i = index; i < count - 1; i++)
            {
                dataSet[i] = dataSet[i + 1];
            }
            dataSet[count - 1] = null;
            count--;
            check = true;
        }
        
        return check;
    }
    
    public E removeEx(int index)
    {
        E element = dataSet[index];
        
        if(index < 0 || index > count)
        {
            throw new IndexOutOfBoundsException();
        }
        for(int i = index; i < count - 1; i++)
        {
            dataSet[i] = dataSet[i + 1];
        }
        dataSet[count - 1] = null;
        count--;
        
        return element;
    }
    
    public boolean remove(E element)
    {
        boolean check = remove(indexOf(element));
        
        return check;
    }
    
    public E removeEx(E element)
    {
        try
        {
            remove(indexOfEx(element));
        }
        catch(NoSuchElementException ex)
        {
            throw new CustomNoSuchElementException();
        }
        
        return element;
    }
    
    public int indexOf(E element)
    {
        int index = 0;
        
        while(index < count && dataSet[index] != element)
        {
            index++;
        }
        if(index == count)
        {
            index = -1;
        }
        
        return index;
    }
    
    public int indexOfEx(E element)
    {
        int index = 0;
        
        while(index < count && dataSet[index] != element)
        {
            index++;
        }
        if(index == count)
        {
            throw new NoSuchElementException();
        }
        
        return index;
    }
    
    public boolean contains(E element)
    {
        boolean check = false;
        
        for(int i = 0; i < count; i++)
        {
            if(dataSet[i] == element)
            {
                check = true;
                break;
            }
        }
        
        return check;
    }
    
    public void clear()
    {
        dataSet = (E[]) new Object[101];
        count = 0;
    }
    
    public boolean isEmpty()
    {
        boolean check = count <= 0;
        
        return check;
    }
    
    public String toString()
    {
        String string = "";
        
        for(int i = 0; i < count; i++)
        {
            string += dataSet[i] + " ";
        }
        
        return string;
    }
    
    private void reallocate()
    {
        E[] newDataSet = (E[]) new Object[2 * count + 1];
        
        for(int i = 0; i < count; i++)
        {
            newDataSet[i] = dataSet[i];
        }
        dataSet = newDataSet;
    }
}