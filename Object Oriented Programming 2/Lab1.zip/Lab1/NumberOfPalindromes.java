/**
 * NumberOfPalindromes is a class which stores a string and
 * then analyzes how many palindrome tokens it contains.
 * 
 * @author (Christian Wendlandt) 
 * @version (02/01/17)
 */
public class NumberOfPalindromes
{
    private String str;
    
    public NumberOfPalindromes()
    {
    }
    public NumberOfPalindromes(String str)
    {
        setString(str);
    }
    
    public String getString()
    {
        return str;
    }
    
    public void setString(String str)
    {
        this.str = str;
    }
    
    //Returns the the number of palindrome tokens in str.
    public int getNumberOfPalindromes()
    {
        String strTrimmed;
        String[] strArray;
        int numberOfPalindromes;
        
        strTrimmed = trimString();
        strArray = strTrimmed.split(" ");
        numberOfPalindromes = 0;
        for(String s : strArray)
            if(isPalindrome(s))
                numberOfPalindromes++;
        return numberOfPalindromes;
    }
    
    //Returns a trimmed string based on str such that all non-letters have been removed.
    //Does not remove spaces.
    private String trimString()
    {
        int size;
        StringBuffer buffer;
        String strTrimmed;
        
        size = str.length();
        buffer = new StringBuffer(size);
        for(int i = 0; i < size; i++)
        {
            if(Character.isLetter(str.charAt(i)))
                buffer.append(str.charAt(i));
            else if(str.charAt(i) == ' ')
                buffer.append(str.charAt(i));
        }
        buffer.trimToSize();
        strTrimmed = buffer.toString();
        return strTrimmed;
    }
    
    //Determines if a string is a palindrome.
    //Used on tokens, but does not require the string to be a token.
    private boolean isPalindrome(String str)
    {
        StringBuffer buffer;
        String strReversed;
        boolean check;
        
        buffer = new StringBuffer(str);
        buffer.reverse();
        strReversed = buffer.toString();
        check = str.equalsIgnoreCase(strReversed);
        return check;
    }
    
    public boolean equals(Object obj)
    {
        if(obj instanceof NumberOfPalindromes)
        {
            NumberOfPalindromes other = (NumberOfPalindromes)obj;
            return str == other.getString();
        }
        return false;
    }
    
    public String toString()
    {
        int numberOfPalindromes;
        String sChar;
        
        numberOfPalindromes = getNumberOfPalindromes();
        if(str.equals(""))
            return "No string detected.";
        if(numberOfPalindromes != 1)
            sChar = "s";
        else
            sChar = "";
        return "\"" + str + "\"\nThis string has " + numberOfPalindromes + " palindrome" + sChar + ".";
    }
}