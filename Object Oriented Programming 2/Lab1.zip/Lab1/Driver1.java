/**
 * Driver for testing NumberOfPalindromes Class.
 * 
 * @author (Christian Wendlandt) 
 * @version (02/01/17)
 */
import java.util.Scanner;
public class Driver1
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        NumberOfPalindromes numberOfPalindromes = new NumberOfPalindromes();
        String str;
        
        System.out.println("Enter a string. \"esc\" will terminate the program.");
        while(true)
        {
            System.out.print(">");
            str = scan.nextLine();
            
            if(str.equals("esc"))
                System.exit(0);
                
            numberOfPalindromes.setString(str);
            System.out.println();
            System.out.println(numberOfPalindromes.toString());
            System.out.println();
        }
    }
}