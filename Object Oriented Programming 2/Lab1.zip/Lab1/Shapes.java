// Fig. 5.26: Shapes.java
// Demonstrates drawing different shapes.
import java.awt.*; //handle the display
import javax.swing.JPanel;

public class Shapes extends JPanel
{
   private int choice; // user's choice of which shape to draw
   
   // constructor sets the user's choice
   public Shapes(int userChoice)
   {
      choice = userChoice;
   } 
   
   // draws a cascade of shapes starting from the top-left corner
   public void paintComponent(Graphics g)
   {
      super.paintComponent(g);
      setBackground(Color.WHITE) ;
      
     switch (choice)
     {
        case 1: // draw rectangle
            g.setColor(Color.BLUE);
            g.fill3DRect(10, 10, 200, 200, true);
            break;
        case 2: // mickey mouse
            g.setColor(Color.BLACK);
            g.fillOval(55,20,50,50);
            g.fillOval(75,30,120,120);
            g.fillOval(165,20,50,50);
            break;
        case 3: // draw Pacman
            g.setColor(Color.YELLOW);
            g.fillArc(10,10,200,200,30,300);
            break;
        case 4: //draw checkers
            for(int i = 0; i < 10; i++)
            {
                for(int j = 0; j < 10; j++)
                {
                    int oddOrEven = (i + j) % 2;
                    Color color;
                    if(oddOrEven == 0)
                    {
                        color = Color.BLUE;
                    }
                    else
                    {
                        color = Color.RED;
                    }
                    g.setColor(color);
                    g.fillRect(i*30, j*30, 30, 30);
                }
            }
            break;
     }
   } 
} // end class Shapes


/**************************************************************************
 * (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
