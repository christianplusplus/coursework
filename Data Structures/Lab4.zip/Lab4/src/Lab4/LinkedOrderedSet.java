package Lab4;
/**
 * @author Christian Wendlandt
 * @version 10/1/17
 * @param <T>
 */

public class LinkedOrderedSet<T extends Comparable<T>> implements OrderedSet<T>
{
    private Node head;
    private Node tail;
    private int size;
    
    private class Node
    {
        T element;
        Node next;
        
        Node(T element)
        {
            this.element = element;
        }
    }
    
    //O(1)
    LinkedOrderedSet()
    {
        head = null;
        tail = null;
        size = 0;
    }
    
    //O(n)
    @Override
    public boolean insert(T element)
    {
        Node currentNode;
        Node newNode;
        
        if(contains(element))
            return false;
        newNode = new Node(element);
        if(isEmpty())
        {
            newNode.next = null;
            head = newNode;
            tail = newNode;
        }
        else if(element.compareTo(head.element) < 0)
        {
            newNode.next = head;
            head = newNode;
        }
        else if(element.compareTo(tail.element) > 0)
        {
            newNode.next = null;
            tail.next = newNode;
            tail = newNode;
        }
        else
        {
            currentNode = head;
            while(element.compareTo(currentNode.next.element) > 0)
                currentNode = currentNode.next;
            newNode.next = currentNode.next;
            currentNode.next = newNode;
        }
        size++;
        return true;
    }

    //O(n)
    @Override
    public boolean contains(T  element)
    {
        Node currentNode;
        
        currentNode = head;
        while(currentNode != null)
        {
            if(element.compareTo(currentNode.element) == 0)
                return true;
            currentNode = currentNode.next;
        }
        return false;
    }

    //O(n)
    @Override
    public boolean remove(T  element)
    {
        Node currentNode;
        
        if(isEmpty() || !contains(element))
            return false;
        if(element.compareTo(head.element) == 0)
            head = head.next;
        else
        {
            currentNode = head;
            while(element.compareTo(currentNode.next.element) != 0)
                currentNode = currentNode.next;
            if(currentNode.next.next == null)
                tail = currentNode;
            currentNode.next = currentNode.next.next;
        }
        size--;
        return true;
    }

    //O(n)
    @Override
    public T get(int index)
    {
        Node currentNode;
        
        if(index < 0 || index >= size)
            return null;
        currentNode = head;
        for(int i = 0; i < index; i++)
            currentNode = currentNode.next;
        return currentNode.element;
    }

    //O(1)
    @Override
    public int size()
    {
        return size;
    }
    
    /*
    These next five methods have faster solutions by avoiding the use of
    insert(), but since speed isn't a requirement of the lab, I opted to keep
    them simple.
    */
    
    //O(n^2)
    @Override
    public OrderedSet<T> first(int k)
    {
        OrderedSet<T> newSet = new LinkedOrderedSet<>();
        Node currentNode = head;
        
        for(int i = 0; i < Math.min(k, size); i++)
        {
            newSet.insert(currentNode.element);
            currentNode = currentNode.next;
        }
        return newSet;
    }

    //O(n^2)
    @Override
    public OrderedSet<T> last(int k)
    {
        OrderedSet<T> newSet = new LinkedOrderedSet<>();
        Node currentNode = head;
        
        for(int i = 0; i < size - Math.max(k, 0); i++)
            currentNode = currentNode.next;
        while(currentNode != null)
        {
            newSet.insert(currentNode.element);
            currentNode = currentNode.next;
        }
        return newSet;
    }
    
    

    //O(n^2)
    @Override
    public OrderedSet<T> union(OrderedSet<T> set)
    {
        OrderedSet<T> newSet = new LinkedOrderedSet<>();
        
        for(int i = 0; i < size; i++)
            newSet.insert(get(i));
        for(int i = 0; i < set.size(); i++)
            newSet.insert(set.get(i));
        return newSet;
    }

    //O(n^2)
    @Override
    public OrderedSet<T> inter(OrderedSet<T> set)
    {
        OrderedSet<T> newSet = new LinkedOrderedSet<>();
        
        for(int i = 0; i < size; i++)
            if(set.contains(get(i)))
                newSet.insert(get(i));
        return newSet;
    }

    //O(n^2)
    @Override
    public OrderedSet<T> diff(OrderedSet<T> set)
    {
        OrderedSet<T> newSet = new LinkedOrderedSet<>();
        
        for(int i = 0; i < size; i++)
            if(!set.contains(get(i)))
                newSet.insert(get(i));
        return newSet;
    }
    
    //O(n)
    @Override
    public String toString()
    {
        StringBuilder string = new StringBuilder("[");
        Node currentNode = head;
        boolean first = true;
        
        for(int i = 0; i < size - 1; i++)
        {
            string.append(currentNode.element.toString());
            string.append(", ");
            currentNode = currentNode.next;
        }
        string.append(currentNode.element.toString());
        string.append("]");
        return string.toString();
    }
    
    private boolean isEmpty()
    {
        return head == null;
    }
}