/**
 * @author Christian Wendlandt
 * @version 2017.11.2
 * @param <T>
 */

public class PriorityWrapper<T>
        implements Comparable<PriorityWrapper<T>>
{
    private final T element;
    private final int priority;
    private final long timestamp;
    
    PriorityWrapper(T element)
    {
        this(element, 0, System.currentTimeMillis());
    }
    
    PriorityWrapper(T element, int priority)
    {
        this(element, priority, System.currentTimeMillis());
    }
    
    PriorityWrapper(T element, long timestamp)
    {
        this(element, 0, timestamp);
    }
    
    PriorityWrapper(T element, int priority, long timestamp)
    {
        this.element = element;
        this.priority = priority;
        this.timestamp = timestamp;
    }
    
    public T getElement()
    {
        return element;
    }
    
    public int getPriority()
    {
        return priority;
    }
    
    public long getTimestamp()
    {
        return timestamp;
    }
    
    @Override
    public int compareTo(PriorityWrapper<T> otherWrapper)
    {
        if(priority < otherWrapper.priority)
            return -1;
        else if(priority > otherWrapper.priority)
            return 1;
        else if(timestamp < otherWrapper.timestamp)
            return 1;
        else if(timestamp > otherWrapper.timestamp)
            return -1;
        return 0;
    }
    
    @Override
    public String toString()
    {
        return element.toString();
    }
}