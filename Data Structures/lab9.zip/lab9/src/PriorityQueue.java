/**
 * @author Christian Wendlandt
 * @version 2017.11.2
 * @param <T>
 */

public class PriorityQueue<T>
{
    private final MaxHeap<PriorityWrapper<T>> heap;
    private long timestamp;//Is a  counter, not system time.
    
    public PriorityQueue()
    {
        heap = new MaxHeap<>();
        timestamp = Long.MIN_VALUE;
        
    }
    
    public void insert(T element, int priority)
    {
        heap.insert(new PriorityWrapper<>(element, priority, timestamp++));
    }
    
    public T remove()
    {
        return heap.remove().getElement();
    }
    
    public T peek()
    {
        return heap.peek().getElement();
    }
    
    public boolean isEmpty()
    {
        return heap.isEmpty();
    }
}
