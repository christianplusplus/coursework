/**
 * @author Christian Wendlandt
 * @version 2017.11.2
 * @param <T>
 */

public class MaxHeap<T extends Comparable<T>>
{
    private T[] array;
    private int size;
    
    public MaxHeap()
    {
        array = (T[])(new Comparable[8]);
        size = 0;
    }
    
    public void insert(T element)
    {
        size++;
        if(size == array.length)
            resize();
        array[size] = element;
        heapifyUp(size);
    }
    
    public T remove()
    {
        T element;
        
        if(size == 0)
            return null;
        element = array[1];
        array[1] = array[size];
        size--;
        heapifyDown();
        return element;
    }
    
    public T peek()
    {
        if(size == 0)
            return null;
        return array[1];
    }
    
    public boolean isEmpty()
    {
        return size == 0;
    }
    
    public void traversePrint()
    {
        int i;
        
        for(i = 1; i <= size; i++)
        {
            System.out.print(array[i]);
            if(lastIndexOfRow(i))
                System.out.println();
            else if(i != size)
                System.out.print(" ");
        }
        if(!lastIndexOfRow(i - 1))
            System.out.println();
    }
    
    @Override
    public String toString()
    {
        StringBuilder string = new StringBuilder("[");
        
        for(int i = 1; i < size; i++)
        {
            string.append(array[i]);
            string.append(", ");
        }
        if(size > 0)
            string.append(array[size]);//The last element shoudn't get a comma.
        string.append("]");
        return string.toString();
    }
    
    private void resize()
    {
        T[] newArray;
        
        newArray = (T[])(new Comparable[array.length * 2 + 1]);
        for(int i = 0; i < array.length; i++)
            newArray[i] = array[i];
        array = newArray;
    }
    
    private void heapifyUp(int index)
    {
        int parentIndex;
        
        parentIndex = index / 2;
        
        while(parentIndex != 0 && array[index].compareTo(array[parentIndex]) > 0)
        {
            swapElements(index, parentIndex);
            index = parentIndex;
            parentIndex = index / 2;
        }
    }
    
    private void heapifyDown()
    {
        int childIndex = 2;
        int index = 1;
        
        while(childIndex <= size &&
                array[index].compareTo(array[childIndex]) < 0 ||
                childIndex + 1 <= size &&
                array[index].compareTo(array[childIndex + 1]) < 0)//If there exists a child that is greater than the parent.
        {
            if(childIndex + 1 <= size)//If there are 2 children.
            {
                if(array[index].compareTo(array[childIndex]) < 0)//If the left child is greater than the parent.
                {
                    if(array[childIndex].compareTo(array[childIndex +1]) < 0)//If the left child is less than the right child.
                        childIndex++;//The right child is the greatest.
                }
                else
                    childIndex++;//One of the children are greater than the parent, but it's not the left. So it must be the right.
            }
            swapElements(index, childIndex);
            index = childIndex;
            childIndex = 2 * index;
        }
    }
    
    private void swapElements(int index1, int index2)
    {
        T temp = array[index1];
        array[index1] = array[index2];
        array[index2] = temp;
    }
    
    private boolean lastIndexOfRow(int index)
    {
        return ((index + 1) & index) == 0;//Checks if (i + 1) is a power of 2.
    }
}
