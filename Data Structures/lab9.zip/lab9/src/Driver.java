/**
 * @author Christian Wendlandt
 * @version 2017.11.2
 */

public class Driver
{
    public static void main(String[] args)
    {
        PriorityQueue<String> queue = new PriorityQueue<>();
        queue.insert("third", 4);
        System.out.println(queue.peek() + " is in front of the queue.");
        queue.insert("eighth", 0);
        queue.insert("sixth", 3);
        queue.insert("fourth", 4);
        queue.insert("seventh", 1);
        System.out.println(queue.peek() + " is in front of the queue.");
        queue.insert("first", 7);
        queue.insert("second", 5);
        queue.insert("fifth", 4);
        queue.insert("tenth", -1);
        queue.insert("ninth", 0);
        System.out.println(queue.peek() + " is in front of the queue.");
        while(!queue.isEmpty())
            System.out.println(queue.remove());
    }
}
