/**
 * @author Christian Wendlandt
 * @version 2017.11.6
 * description: A Driver for the JavaIdentifierFinder. It simply constructs the
 * driver and a file chooser, gives a chosen file to the finder, then prints a
 * string of all of the identifiers that the finder has found.
 */
import java.io.File;
import java.io.FileNotFoundException;
import javax.swing.JFileChooser;

public class Driver
{
    public static void main(String[] args)
    {
        JavaIdentifierFinder finder;
        
        finder = new JavaIdentifierFinder();
        try
        {
            finder.scanFile(openInputFile());
            System.out.print(finder.printIdentifiers());
        }
        catch(FileNotFoundException | NullPointerException ex)
        {
            System.out.println("File not found.\nTerminating program.");
        }
    }
    
    private static File openInputFile()
    {
        File file;
        
        JFileChooser chooser = new JFileChooser(System.getProperty("user.dir"));
        if(chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
            file = chooser.getSelectedFile();
        else
            file = null;
        return file;
    }
}
