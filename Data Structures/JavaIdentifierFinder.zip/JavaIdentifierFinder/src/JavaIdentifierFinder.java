/**
 * @author Christian Wendlandt
 * @version 2017.11.6
 * description: Takes given java files and creates an ordered list of all
 * identifiers in the file. Uses a keywords.txt document to keep track of what
 * not to consider as an identifier. Each identifier is stored with a line
 * number so that it can traced back to the exact line that it was found in the
 * java file.
 * 
 * Runtime Justification:
 * The constructor takes each keyword in the text file and inserts them into
 * an AVL tree one at a time. Each insertion is log(n) time. But to be fair, the
 * number of keywords in the java library is relatively constant, which makes
 * the constructor operate in O(1) time.
 * 
 * The clear method simply throws out the old identifiers AVL tree for the
 * garbage collector and makes a new one. Without knowing too much about how the
 * collector operates, I will assume the method operates in O(1) time.
 * 
 * Creating a string of the identifiers draws directly from the toString method
 * of the AVL tree; which should take no longer than O(n) time.
 * 
 * The scanFile method is notably the most complicated. Each file line is
 * scanned one at a time. Then for each line, the string is cleaned up and then
 * read each character at a time. Perhaps the best way to measure its time
 * complexity is to consider time complexity for each identifier inside of a
 * given file. So then if there are n identifiers, each identifier is inserted
 * into the AVL tree with O(log(n)) time. Then the time complexity for an entire
 * file should have O(nlog(n)) time complexity, where n is the total number of
 * identifiers in the given file.
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JavaIdentifierFinder
{
    private MyAVLTree<String> keywords;
    private MyAVLTree<String> identifiers;
    
    public JavaIdentifierFinder()
    {
        Scanner input = null;
        
        keywords = new MyAVLTree<>();
        identifiers = new MyAVLTree<>();
        System.out.println();
        try
        {
            input = new Scanner(new File("src\\keywords.txt"));
        }
        catch(FileNotFoundException ex)
        {
            Logger.getLogger(JavaIdentifierFinder.class.getName()).log(Level.SEVERE, null, ex);
        }
        while(input.hasNext())
            keywords.insert(input.nextLine());
        input.close();
    }
    
    /**
     * Tells the finder to parse through a given java source code file. The
     * finder will take each identifier and store them in an AVL tree along with
     * the line number that they were found. Duplicate identifiers will simply
     * be given a separate line number(duplicate line numbers will not be kept).
     * @param file - This is the file that will be parsed.
     * @throws java.io.FileNotFoundException
     */
    public void scanFile(File file) throws FileNotFoundException
    {
        Scanner input;
        int lineCount = 1;
        boolean inComment = false;
        
        input = new Scanner(file);
        while(input.hasNext())
            inComment = scanLine(input.nextLine(), lineCount++, inComment);
        //A boolean is returned so that the next line knows if the previous line
        //was inside of a comment that hadn't terminated yet.
    }
    
    /**
     * Creates and returns a string list containing all of the identifiers that
     * were found by the scanFile method along with each line number that each
     * was found on. Duplicate identifiers will simply be given a separate line
     * number(duplicate line numbers will not be kept).
     * @return String - This is the list of identifiers being stored by the
     * object.
     */
    public String printIdentifiers()
    {
        return identifiers.toString();
    }
    
    /**
     * A new list of identifiers is created and the old one is thrown out.
     */
    public void clearIdentifiers()
    {
        identifiers = new MyAVLTree<>();
    }
    
    private boolean scanLine(String line, int lineCount, boolean inComment)
    {
        int startIndex;
        int endIndex;
        
        //Clean out comments and String literals
        startIndex = line.indexOf("*/");
        if(inComment && startIndex != -1)
        {
            line = line.substring(startIndex + 2);
            inComment = false;
        }
        if(inComment)
            return true;
        startIndex = line.indexOf("/*");
        while(startIndex != -1)
        {
            endIndex = line.indexOf("*/", startIndex);
            if(endIndex == -1)
            {
                endIndex = line.length();
                inComment = true;
            }
            else
                inComment = false;
            line = line.substring(0, startIndex) + line.substring(endIndex);
            startIndex = line.indexOf("/*");
        }
        if(inComment)
            return true;
        line = slashSlashTrim(line);
        line = stringLiteralTrim(line);
        
        scanCleanLine(line, lineCount);
        return false;
    }
    
    private String slashSlashTrim(String string)
    {
        int index = string.indexOf("//");
        
        return index == -1 ? string : string.substring(0, index);
    }
    
    private String stringLiteralTrim(String string)
    {
        int endIndex;
        int startIndex = string.indexOf("\"");
        
        while(startIndex != -1)
        {
            endIndex = string.indexOf("\"", startIndex + 1);
            if(endIndex == -1)
                endIndex = string.length();
            string = string.substring(0, startIndex) +
                    string.substring(endIndex);
            startIndex = string.indexOf("\"");
        }
        return string;
    }
    
    private void scanCleanLine(String line, int lineCount)
    {
        StringBuilder sb = new StringBuilder();
        String string;
        boolean inString = false;
        char character;
        
        for(int i = 0; i < line.length(); i++)
        {
            character = line.charAt(i);
            if(Character.isAlphabetic(character) || character == '_')
            {
                sb.append(character);
                inString = true;
            }
            else if(inString && Character.isDigit(character))
                sb.append(character);
            else//either the end of an identifier or a nonstarter.
            {
                inString = false;
                string = sb.toString();
                if(!string.equals("") && !keywords.contains(string))
                    identifiers.insert(string, lineCount);
                sb = new StringBuilder();
            }
        }
        //flushes the last string builder
        string = sb.toString();
        if(!string.equals("") && !keywords.contains(string))
                    identifiers.insert(string, lineCount);
    }
}