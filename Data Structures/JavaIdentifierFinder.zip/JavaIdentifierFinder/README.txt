@author Christian Wendlandt
@version 2017.11.6

Description: Takes given java files and creates an ordered list of all
identifiers in the file. Uses a keywords.txt document to keep track of what
not to consider as an identifier. Each identifier is stored with a line
number so that it can traced back to the exact line that it was found in the
java file.

public void scanFile(File file)
Tells the finder to parse through a given java source code file. The
finder will take each identifier and store them in an AVL tree along with
the line number that they were found. Duplicate identifiers will simply
be given a separate line number(duplicate line numbers will not be kept).
@param file - This is the file that will be parsed.
@throws java.io.FileNotFoundException

public String printIdentifiers()
Creates and returns a string list containing all of the identifiers that
were found by the scanFile method along with each line number that each
was found on. Duplicate identifiers will simply be given a separate line
number(duplicate line numbers will not be kept).
@return String - This is the list of identifiers being stored by the
object.

public void clearIdentifiers()
A new list of identifiers is created and the old one is thrown out.