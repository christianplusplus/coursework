/**
 * @author Christian Wendlandt
 * @version 2017.12.14
 * @description A static object "compresses" and "decompresses" text in/into
 * readable LZ78 tuples.
 */

import java.util.HashMap;
import java.util.ArrayList;

public class LZ78
{
    /**
     * "Compresses" text into a string of readable LZ78 tuples.
     * @param text The text to be compressed.
     * @return The compressed text.
     */
    public static String encode(String text)
    {
        HashMap<CharacterArray, Integer> dictionary = new HashMap<>();
        CharacterArray encodedText = new CharacterArray();
        CharacterArray buffer = new CharacterArray();
        int prevIndex = 0;
        int currIndex = 0;
        
        for(int i = 0; i < text.length(); i++)
        {
            //Adds to dictionary entry
            buffer.append(text.charAt(i));
            
            //Checks dictionary
            if(dictionary.containsKey(buffer))
                //Then use dictionary entry index
                prevIndex = dictionary.get(buffer);
            else
            {
                //Then make new dictionary entry
                //Update dictionary
                dictionary.put(buffer, ++currIndex);
                
                //Encode characters
                appendTuple(encodedText, prevIndex, buffer.getLastChar());
                
                //Clear character buffer
                buffer = new CharacterArray();
                prevIndex = 0;
            }
        }
        //Incase no last character to encode
        if(prevIndex > 0)
        {
            dictionary.put(buffer, ++currIndex);
            appendTuple(encodedText, prevIndex, 0);
        }
        return encodedText.toString();
    }
    
    private static void appendTuple(CharacterArray encodedText, int index, int character)
    {
        encodedText.append('(');
        encodedText.appendInt(index);
        encodedText.append(',');
        encodedText.appendInt(character);
        encodedText.append(')');
    }
    
    /**
     * "Decompresses" readable LZ78 tuples into a string message.
     * @param text The string to be decompressed.
     * @return The decompressed text.
     */
    public static String decode(String text)
    {
        ArrayList<String> dictionary = new ArrayList<>();
        StringBuilder decodedText = new StringBuilder();
        int entryIndex;
        int entryCharacter;
        String preEntry;
        String entry;
        int startIndex;
        int commaIndex;
        int endIndex;
        
        //Sets the 0 index to an empty string
        dictionary.add("");
        startIndex = text.indexOf("(");
        while(startIndex != -1)
        {
            //Parses touple data locations
            commaIndex = text.indexOf(",", startIndex);
            endIndex = text.indexOf(")", startIndex);
            
            //Parses the tuple
            entryIndex = Integer.parseInt(text.substring(startIndex + 1, commaIndex));
            entryCharacter = Integer.parseInt(text.substring(commaIndex + 1, endIndex));
            entry = Character.toString((char)entryCharacter);
            
            //Updates dictionary
            preEntry = dictionary.get(entryIndex);
            dictionary.add(preEntry + entry);
            
            //Outputs decoded characters
            decodedText.append(preEntry);
            if(entryCharacter != 0)
                decodedText.append(entry);
            
            //Parses start of new touple
            startIndex = text.indexOf("(", endIndex);
        }
        return decodedText.toString();
    }
}
