/**
 * @author Christian Wendlandt
 * @version 2017.12.14
 * Made a specialized stringBuilder to help clean up calls and improve speed.
 * The stringBuilder equals() method was also "lacking".
 */

class CharacterArray
{
    private char[] array;
    private char lastChar;
    private int size;
    
    public CharacterArray()
    {
        array = new char[8];
        size = 0;
        lastChar = '\u0000';
    }
    
    public void append(char character)
    {
        if(size == array.length)
            resize();
        array[size] = character;
        size++;
        lastChar = character;
    }
    
    public void appendInt(int integer)
    {
        String integerString = Integer.toString(integer);
        
        for(int i = 0; i < integerString.length(); i++)
            append(integerString.charAt(i));
    }
    
    private void resize()
    {
        char[] newArray = new char[2 * array.length];
        
        for(int i = 0; i < array.length; i++)
            newArray[i] = array[i];
        array = newArray;
    }
    
    public char getLastChar()
    {
        return lastChar;
    }
    
    @Override
    public int hashCode()
    {
        return (new String(array)).hashCode();
    }
    
    @Override
    public String toString()
    {
        return new String(array);
    }
    
    @Override
    public boolean equals(Object otherArray)
    {
        if(otherArray instanceof CharacterArray)
        {
            if(size != ((CharacterArray) otherArray).size)
                return false;
            for(int i = 0; i < size; i++)
                if(array[i] != ((CharacterArray) otherArray).array[i])
                    return false;
            return true;
        }
        return false;
    }
}
