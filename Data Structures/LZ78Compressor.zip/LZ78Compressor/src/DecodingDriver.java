/**
 * @author Christian Wendlandt
 * @version 2017.12.14
 * @description Prompts the user for an input and output file. Scans the input
 * and then decodes it into the output using the LZ78 decoding algorithm.
 */

import java.util.Scanner;
import java.io.PrintWriter;
import java.io.FileNotFoundException;

public class DecodingDriver
{
    public static void main(String[] args)
    {
        PrintWriter output;
        Scanner scan;
        String text;
        
        try
        {
            scan = new Scanner(FileChooser.openFile());
            text = scan.useDelimiter("\\Z").next();
            scan.close();
            
            text = LZ78.decode(text);
            
            output = new PrintWriter(FileChooser.writeFile());
            output.print(text);
            output.close();
        }
        catch(FileNotFoundException ex)
        {
            System.out.println(ex);
            System.out.println("Valid file not selected. Terminating.");
            System.exit(0);
        }
    }
}