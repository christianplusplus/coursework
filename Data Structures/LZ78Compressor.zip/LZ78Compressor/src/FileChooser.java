/**
 * @author Christian Wendlandt
 * @version 2017.12.14
 */

import java.io.File;
import javax.swing.JFileChooser;

class FileChooser
{
    public static File openFile()
    {
        File file;
        
        JFileChooser chooser = new JFileChooser();
        if(chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
            file = chooser.getSelectedFile();
        else
            file = null;
        return file;
    }
    
    public static File writeFile()
    {
        File file;
        
        JFileChooser chooser = new JFileChooser();
        if(chooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION)
            file = chooser.getSelectedFile();
        else
            file = null;
        return file;
    }
}