/**
 * @author Christain Wendlandt
 * @version 10/26/17
 */
public class Driver
{
    public static void main(String[] args)
    {
        MyTreeSet<Integer> tree = new MyTreeSet<>();
        tree.insert(7);
        tree.insert(10);
        tree.insert(11);
        tree.insert(15);
        tree.insert(7);
        tree.insert(7);
        tree.insert(20);
        tree.insert(30);
        tree.insert(40);
        tree.insert(7);
        System.out.println(tree);
        tree.inorder();
        tree.checkBalance();
        
        System.out.println("First: " + tree.first());
        System.out.println("Last: " + tree.last());
        for(int i = tree.first() - 1; i <= tree.last() + 1; i++)
            System.out.println("Smallest but greater than " + i + ": " + tree.higher(i));
        for(int i = tree.first() - 1; i <= tree.last() + 1; i++)
            System.out.println("Largest but less than " + i + ": " + tree.lower(i));
        MyTreeSet<Integer> tailTree = tree.tailSet(11);
        tailTree.checkBalance();
        System.out.println(tailTree);
        MyTreeSet<Integer> headTree = tree.headSet(11);
        headTree.checkBalance();
        System.out.println(headTree);
    }
}
