/**
 * @author Christian Wendlandt
 * @version 2017.12.6
 */

import java.util.HashSet;

public class Vertex<T> implements Comparable<Vertex>
{
    private T data;
    private final HashSet<String> outgoingNeighborsList;
    private final HashSet<String> incomingNeighborsList;
    public final String label;
    
    public Vertex(String label)
    {
        this(label, null);
    }
    
    public Vertex(String label, T data)
    {
        this.label = label;
        this.data = data;
        outgoingNeighborsList = new HashSet<>();
        incomingNeighborsList = new HashSet<>();
    }
    
    public void addOutgoingNeighbor(String neighbor)
    {
        outgoingNeighborsList.add(neighbor);
    }
    
    public void addIncomingNeighbor(String neighbor)
    {
        incomingNeighborsList.add(neighbor);
    }
    
    public void deleteOutgoingNeighbor(String neighbor)
    {
        outgoingNeighborsList.remove(neighbor);
    }
    
    public void deleteIncomingNeighbor(String neighbor)
    {
        incomingNeighborsList.remove(neighbor);
    }
    
    public int getOutDegree()
    {
        return outgoingNeighborsList.size();
    }
    
    public int getInDegree()
    {
        return incomingNeighborsList.size();
    }
    
    public HashSet<String> getOutgoingNeighborsList()
    {
        return outgoingNeighborsList;
    }
    
    public HashSet<String> getIncomingNeighborsList()
    {
        return incomingNeighborsList;
    }
    
    public String getLabel()
    {
        return label;
    }
    
    public T getData()
    {
        return data;
    }
    
    public void setData(T data)
    {
        this.data = data;
    }
    
    @Override
    public String toString()
    {
        if(data != null)
            return "[" + label + ", " + data.toString() + "]";
        return label;
    }
    
    @Override
    public int compareTo(Vertex otherVertex)
    {
        return label.compareTo(otherVertex.label);
    }
    
    @Override
    public boolean equals(Object otherVertex)
    {
        if(otherVertex instanceof Vertex)
            return label.equals(((Vertex)otherVertex).label);
        return false;
    }

    @Override
    public int hashCode()
    {
        return label.hashCode();
    }
}
