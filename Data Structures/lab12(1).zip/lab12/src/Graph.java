/**
 * @author Christian Wendlandt
 * @version 2017.12.6
 */

import java.util.HashMap;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Stack;
import java.util.HashSet;

public class Graph
{
    private final boolean isDirected;
    private final HashMap<String, Vertex> vertices;
    //key is label
    private final HashMap<Integer, Edge> edges;
    //key is (origin label + destination label).hashCode()
    
    Graph(boolean isDirected)
    {
        this.isDirected = isDirected;
        vertices = new HashMap<>();
        edges = new HashMap<>();
    }
    
    public boolean isDirected()
    {
        return isDirected;
    }
    
    public int vertexCount()
    {
        return vertices.size();
    }
    
    public int edgeCount()
    {
        return isDirected ? edges.size() : edges.size() / 2;
    }
    
    public void insertVertex(String label)
    {
        vertices.put(label, new Vertex(label));
    }
    
    public void insertEdge(String origin, String destination)
    {
        insertEdge(origin, destination, 1);
    }
    
    public void insertEdge(String origin, String destination, double weight)
    {
        Vertex originVertex = vertices.get(origin);
        Vertex destinationVertex = vertices.get(destination);
        
        edges.put((origin + destination).hashCode(),
                new Edge(origin, destination, weight));
        originVertex.addOutgoingNeighbor(destination);
        destinationVertex.addIncomingNeighbor(origin);
        if(!isDirected)
        {
            edges.put((destination + origin).hashCode(),
                    new Edge(destination, origin, weight));
            destinationVertex.addOutgoingNeighbor(origin);
            originVertex.addIncomingNeighbor(destination);
        }
    }
    
    public void removeVertex(String vertex)
    {
        for(Object neighbor : vertices.get(vertex).getOutgoingNeighborsList())
        {
            vertices.get((String)neighbor).deleteIncomingNeighbor(vertex);
            edges.remove((vertex + (String)neighbor).hashCode());
        }
        for(Object neighbor : vertices.get(vertex).getIncomingNeighborsList())
        {
            vertices.get((String)neighbor).deleteOutgoingNeighbor(vertex);
            edges.remove(((String)neighbor + vertex).hashCode());
        }
        vertices.remove(vertex);
    }
    
    public void removeEdge(String origin, String destination)
    {
        vertices.get(origin).getOutgoingNeighborsList().remove(destination);
        vertices.get(destination).getIncomingNeighborsList().remove(origin);
        edges.remove((origin + destination).hashCode());
    }
    
    public boolean containsVertex(String vertex)
    {
        return vertices.containsKey(vertex);
    }
    
    public boolean containsEdge(String origin, String destination)
    {
        return edges.containsKey((origin + destination).hashCode());
    }
    
    public ArrayList<Vertex> BFS(String vertexLabel)
    {
        ArrayList<Vertex> searchList = new ArrayList<>();
        LinkedList<String> queue = new LinkedList<>();
        HashSet<String> discovered = new HashSet<>();
        Vertex vertex;
        
        queue.offer(vertexLabel);
        discovered.add(vertexLabel);
        while(!queue.isEmpty())
        {
            vertex = vertices.get(queue.poll());
            searchList.add(vertex);
            for(Object neighbor : vertex.getOutgoingNeighborsList())
            {
                if(!discovered.contains((String)neighbor))
                {
                    queue.offer((String)neighbor);
                    discovered.add((String)neighbor);
                }
            }
        }
        return searchList;
    }
    
    public ArrayList<Vertex> DFS(String vertexLabel)
    {
        ArrayList<Vertex> searchList = new ArrayList<>();
        Stack<String> stack = new Stack();
        HashSet<String> discovered = new HashSet<>();
        Vertex vertex;
        
        stack.push(vertexLabel);
        while(!stack.isEmpty())
        {
            vertexLabel = stack.pop();
            if(!discovered.contains(vertexLabel))
            {
                vertex = vertices.get(vertexLabel);
                searchList.add(vertex);
                discovered.add(vertexLabel);
                for(Object neighbor : vertex.getOutgoingNeighborsList())
                    if(!discovered.contains((String)neighbor))
                        stack.push((String)neighbor);
            }
        }
        return searchList;
    }
    
    public HashMap<String, PathWrapper> shortestPath(String currentVertex)
    {
        HashMap<String, PathWrapper> pathList = new HashMap<>();
        LinkedList<String> queue = new LinkedList<>();
        HashSet<String> discovered = new HashSet<>();
        String neighborLabel;
        
        for(Vertex vertex : vertices.values())
            pathList.put(vertex.label,
                    new PathWrapper(null, Double.POSITIVE_INFINITY));
        pathList.get(currentVertex).distance = 0;
        queue.offer(currentVertex);
        while(!queue.isEmpty())
        {
            currentVertex = queue.poll();
            discovered.add(currentVertex);
            for(Object neighbor : vertices.get(currentVertex).getOutgoingNeighborsList())
            {
                neighborLabel = (String)neighbor;
                if(!discovered.contains(neighborLabel))
                {
                    if(pathList.get(currentVertex).distance +
                            edges.get((currentVertex + neighborLabel).hashCode()).weight <
                            pathList.get(neighborLabel).distance)
                    {
                        pathList.get(neighborLabel).distance =
                                pathList.get(currentVertex).distance +
                                edges.get((currentVertex + neighborLabel).hashCode()).weight;
                        pathList.get(neighborLabel).predecessor = currentVertex;
                        queue.offer(neighborLabel);
                    }
                }
            }
        }
        return pathList;
    }
    
    @Override
    public String toString()
    {
        StringBuilder string = new StringBuilder();
        String edgeString;
        int breakCounter = 0;
        
        string.append("V={");
        for(String label : vertices.keySet())
        {
            if(breakCounter > 70)
            {
                string.append("\n   ");
                breakCounter = 0;
            }
            string.append(label);
            string.append(',');
            breakCounter += label.length() + 1;
        }
        if(!vertices.isEmpty())
            string.deleteCharAt(string.length() - 1);//removes trailing commas.
        
        breakCounter = 0;
        string.append("}\nE={");
        for(Edge edge : edges.values())
        {
            if(breakCounter > 70)
            {
                string.append("\n   ");
                breakCounter = 0;
            }
            edgeString = edge.toString();
            string.append(edgeString);
            string.append(',');
            breakCounter += edgeString.length() + 1;
        }
        if(!edges.isEmpty())
            string.deleteCharAt(string.length() - 1);//removes trailing commas.
        string.append('}');
        
        return string.toString();
    }
    
    public void print()
    {
        System.out.println(toString());
    }
}
