/**
 * @author Christian Wendlandt
 * @version 2017.12.6
 */

public class Driver
{
    public static void main(String[] args)
    {
        Graph g = new Graph(false);
        
        g.insertVertex("H");
        g.insertVertex("A");
        g.insertVertex("B");
        g.insertVertex("C");
        g.insertVertex("D");
        g.insertVertex("E");
        g.insertVertex("F");
        g.insertVertex("S");
        g.insertEdge("H", "A", 3);
        g.insertEdge("A", "D", 3);
        g.insertEdge("H", "B", 2);
        g.insertEdge("B", "D", 1);
        g.insertEdge("H", "C", 5);
        g.insertEdge("C", "E", 2);
        g.insertEdge("B", "E", 6);
        g.insertEdge("D", "F", 4);
        g.insertEdge("F", "E", 1);
        g.insertEdge("S", "F", 2);
        g.insertEdge("S", "E", 4);
        g.print();
        
        System.out.println(g.shortestPath("H"));
    }
}
