/**
 * @author Christian Wendlandt
 * @version 2017.12.6
 */

public class PathWrapper implements Comparable<PathWrapper>
{
    public String predecessor;
    public double distance;
    
    PathWrapper(String predecessor, double distance)
    {
        this.predecessor = predecessor;
        this.distance = distance;
    }
    
    @Override
    public String toString()
    {
        return "(" + predecessor + "," + Double.toString(distance) + ")";
    }
    
    @Override
    public int compareTo(PathWrapper otherPath)
    {
        if(distance < otherPath.distance)
            return -1;
        if(distance > otherPath.distance)
            return 1;
        return 0;
    }
    
    @Override
    public int hashCode()
    {
        return predecessor.hashCode();
    }

    @Override
    public boolean equals(Object otherPath)
    {
        if(otherPath instanceof PathWrapper)
            return predecessor.equals(((PathWrapper)otherPath).predecessor);
        return false;
    }
}
