package Lab3;

/**
 * @author Christian Wendlandt
 * @version 9/21/17
 */
public class ArrayOrderedSet<T extends Comparable<T>> implements OrderedSet<T>
{
    private T[] array;
    private int count;
    
    //O(1)
    ArrayOrderedSet()
    {
        array = (T[])(new Comparable[8]);
        count = 0;
    }
    
    //O(n)
    @Override
    public boolean insert(T element)
    {
        int index;
        
        if(contains(element))
            return false;
        if(count == array.length)
            resize();
        index = findInsertionPoint(element);
        shiftOut(index);
        array[index] = element;
        count++;
        return true;
    }

    //O(n)
    @Override
    public boolean contains(T  element)
    {
        for(int i = 0; i < count; i++)
            if(array[i] == element)
                return true;
        return false;
    }

    //O(n)
    @Override
    public boolean remove(T  element)
    {
        int index;
        
        index = findElement(element);
        if(index == -1)
            return false;
        for(int i = index; i < count - 1; i++)
            array[i] = array[i + 1];
        count--;
        return true;
    }

    //O(1)
    @Override
    public T get(int index)
    {
        if(index < 0 || index >= count)
            throw new IndexOutOfBoundsException();
        
        return array[index];
    }

    //O(1)
    @Override
    public int size()
    {
        return count;
    }

    //O(n)
    @Override
    public OrderedSet<T> first(int k)
    {
        OrderedSet<T> set;
        
        set = new ArrayOrderedSet();
        for(int i = 0; i < k && i < count; i++)
            set.insert(array[i]);
        
        return set;
    }

    //O(n)
    @Override
    public OrderedSet<T> last(int k)
    {
        OrderedSet<T> set;
        
        set = new ArrayOrderedSet();
        for(int i = Math.max(k, 0); i < count; i++)
            set.insert(array[i]);
        
        return set;
    }

    //O(n)
    @Override
    public OrderedSet<T> union(OrderedSet<T> set)
    {
        OrderedSet<T> newSet;
        
        newSet = new ArrayOrderedSet();
        for(int i = 0; i < set.size(); i++)
        {
            newSet.insert(array[i]);
            newSet.insert(set.get(i));
        }
        
        return newSet;
    }

    //O(n)
    @Override
    public OrderedSet<T> inter(OrderedSet<T> set)
    {
        OrderedSet<T> newSet;
        
        newSet = new ArrayOrderedSet();
        for(int i = 0; i < count; i++)
            if(set.contains(array[i]))
                newSet.insert(array[i]);
        
        return newSet;
    }

    //O(n)
    @Override
    public OrderedSet<T> diff(OrderedSet<T> set)
    {
        OrderedSet<T> newSet;
        
        newSet = new ArrayOrderedSet();
        for(int i = 0; i < count; i++)
            newSet.insert(array[i]);
        for(int i = 0; i < set.size(); i++)
            newSet.remove(set.get(i));
        
        return newSet;
    }
    
    //O(n)
    @Override
    public String toString()
    {
        StringBuilder string;
        
        string = new StringBuilder("[");
        for(int i = 0; i < count; i++)
        {
            string.append(array[i].toString());
            string.append(", ");
        }
        string.deleteCharAt(string.length() - 1);
        string.deleteCharAt(string.length() - 1);
        string.append("]");
        
        return string.toString();
    }
    
    private void resize()
    {
        T[] newArray;
        
        newArray = (T[])(new Comparable[array.length * 2 + 1]);
        for(int i = 0; i < array.length; i++)
            newArray[i] = array[i];
        array = newArray;
    }
    
    private void shiftOut(int index)
    {
        for(int i = count; i > index; i--)
            array[i] = array[i - 1];
    }
    
    private int findElement(T element)
    {
        for(int i = 0; i < count; i++)
            if(element.compareTo(array[i]) == 0)
                return i;
        
        return -1;
    }
    
    private int findInsertionPoint(T element)
    {
        int index;
        
        index = 0;
        while(index < count && element.compareTo(array[index]) > 0)
            index++;
        
        return index;
    }
}