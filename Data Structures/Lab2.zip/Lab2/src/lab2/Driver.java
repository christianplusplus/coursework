package lab2;

/**
 * Allows testing of various sorting algorithms.
 * Testers use a default seed of 542.
 *
 * @author Christian Wendlandt
 * @version 9/14/17
 *
 * Timings (in milliseconds):
 * N                                   Selection    Array.sort
 * -----------------------------------------------------------
 * 10                                          0             0
 * 100                                         0             0
 * 1,000                                       3             1
 * 10,000                                     36             3
 * 100,000                                  3185            16
 * 1,000,000                              316580           132
 * 10,000,000                           31837009           996
 * -----------------------------------------------------------
 * Selection sort big O: n^2
 * Array.sort big O: n*log(n)
 * ------------------------------------------------------------
 * Estimates (in seconds):
 * N                                    Selection    Array.sort
 * ------------------------------------------------------------
 * 100,000,000                            3185511            11
 * 10,000,000,000                     31857113832          1323
 * 1,000,000,000,000              318571337983185         15882
 * 1,000,000,000,000,000    318571339997983150000      19852500
 */

import java.util.Arrays;
import java.util.Random;

public class Driver
{
    public static void main(String[] args)
    {
        int arrSize = 10000;
        int numOfTests = 1;

        System.out.println(selectionSortFastTester(numOfTests, arrSize) + "ms");
        System.out.println(arraysSortTester(numOfTests, arrSize) + "ms");

    }

    public static double selectionSortFastTester(int numOfTests, int arrSize)
    {
        int[] array;
        long start;
        long end;
        long time;
        double totalTime;
        double average;

        totalTime = 0;
        for(int i = 0; i < numOfTests; i++)
        {
            array = createRandomArray(arrSize, 542);

            start = System.currentTimeMillis();
            selectionSortFast(array);
            end = System.currentTimeMillis();

            if(!verify(array))
                throw new RuntimeException("List not sorted.");
            time = end - start;
            totalTime += time;
        }
        average = totalTime / numOfTests;

        return average;
    }

    public static double selectionSortSimpleTester(int numOfTests, int arrSize)
    {
        int[] array;
        long start;
        long end;
        long time;
        double totalTime;
        double average;

        totalTime = 0;
        for(int i = 0; i < numOfTests; i++)
        {
            array = createRandomArray(arrSize, 542);

            start = System.currentTimeMillis();
            selectionSortSimple(array);
            end = System.currentTimeMillis();

            if(!verify(array))
                throw new RuntimeException("List not sorted.");
            time = end - start;
            totalTime += time;
        }
        average = totalTime / numOfTests;

        return average;
    }

    public static double arraysSortTester(int numOfTests, int arrSize)
    {
        int[] array;
        long start;
        long end;
        long time;
        long totalTime;
        double average;

        totalTime = 0;
        for(int i = 0; i < numOfTests; i++)
        {
            array = createRandomArray(arrSize, 542);

            start = System.currentTimeMillis();
            Arrays.sort(array);
            end = System.currentTimeMillis();

            if(!verify(array))
                throw new RuntimeException("List not sorted.");
            time = end - start;
            totalTime += time;
        }
        average = (double)totalTime / numOfTests;

        return average;
    }

    public static void selectionSortFast(int[] array)
    {
        int smallestNum;
        int smallestNumIndex;

        for(int i = 0; i < array.length - 1; i++)
        {
            smallestNum = array[i];
            smallestNumIndex = i;
            for(int j = i + 1; j < array.length; j++)
            {
                if(array[j] < smallestNum)
                {
                    smallestNum = array[j];
                    smallestNumIndex = j;
                }
            }
            array[smallestNumIndex] = array[i];
            array[i] = smallestNum;
        }
    }

    public static void selectionSortSimple(int[] array)
    {
        int smallestNumIndex;
        int temp;

        for(int i = 0; i < array.length - 1; i++)
        {
            smallestNumIndex = i;
            for(int j = i + 1; j < array.length; j++)
                if(array[j] < array[smallestNumIndex])
                    smallestNumIndex = j;
            temp = array[i];
            array[i] = array[smallestNumIndex];
            array[smallestNumIndex] = temp;
        }
    }

    public static boolean verify(int[] array)
    {
        for(int i = 0; i < array.length - 1; i++)
            if(array[i] > array[i + 1])
                return false;
        return true;
    }

    public static void printArray(int[] array)
    {
        String printString = "";
        for(int i : array)
        {
            printString += i;
            printString += ',';
        }
        System.out.println(printString);
    }

    public static int[] createRandomArray(int size)
    {
        Random random = new Random();
        int[] array = new int[size];

        for(int i = 0; i < size; i++)
            array[i] = random.nextInt();

        return array;
    }

    public static int[] createRandomArray(int size, int seed)
    {
        Random random = new Random(seed);
        int[] array = new int[size];

        for(int i = 0; i < size; i++)
            array[i] = random.nextInt();

        return array;
    }

    public static int[] createRandomArray(int size, int seed, int range)
    {
        Random random = new Random(seed);
        int[] array = new int[size];

        for(int i = 0; i < size; i++)
            array[i] = random.nextInt(range);

        return array;
    }

    //Based on timings and quadradic regression modeling.
    //Used to find estimates.
    public static double quadradicEstimationFunction(double x)
    {
        return 3.1857134 * .0000001 * x * x - 0.002016815194 * x;
    }

    //Based on timings and the "looks pretty close" method.
    //Used to find estimates.
    public static double nLogNEstimationFunction(double x)
    {
        return .000003984132 * x * Math.log(x) / Math.log(2);
    }
}