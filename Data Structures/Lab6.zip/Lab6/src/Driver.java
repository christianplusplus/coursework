/**
 * @author Christian Wendlandt
 * @versoin 10/12/17
 */

import java.util.Random;

public class Driver
{
    public static void main(String[] args)
    {
        MyBST<Integer> tree = new MyBST<>();
        Random random = new Random();
        
        for(int i = 0; i < 15; i++)
            tree.insert(random.nextInt(9));
        tree.levelTraversal();
        System.out.println("Occurrences of 0: " + tree.countOccurrences(0));
        System.out.println("Number of integers between 3 and 6: " +
                tree.inBetween(3, 6));
        System.out.println("Number of elements less than 3 removed: " +
                tree.removeLessThan(3));
        tree.levelTraversal();
    }
}
