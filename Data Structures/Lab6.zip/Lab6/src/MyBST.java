
public class MyBST<T extends Comparable<T>>{
	//Inner Class to capture a node
	private class MyNode<T> {
		private T data;
		private MyNode<T> left;
		private MyNode<T> right;
		private MyNode(T e, MyNode<T> l, MyNode<T> r){
			data=e;
			left=l;
			right=r;
		}
	}

	//Data members
	private MyNode<T>root;
	private int size;

	//Operations
	public MyBST(){
		root = null;
		size=0;
	}

	public int size(){
		return size;
	}

	public boolean contains(T element){
		MyNode<T> temp=root;
		return containsNode(root,element);
	}

	//O(h) -- O(log n) to O(n)
	public boolean containsNode(MyNode<T> temp,T element){
		if(temp!=null){
			int compared = temp.data.compareTo(element);
			if(compared==0)
				return true;
			else if (compared >0)
				return containsNode(temp.left,element);
			else
				return containsNode(temp.right,element);
		}
		return false;
	}

	public void inorder(){
		System.out.print("Tree of size "+size+": ");
		inorder(root);
		System.out.println();
	}

	//O(n)
	private void inorder(MyNode<T> temp){
		if (temp!=null){
			inorder(temp.left);
			System.out.print(temp.data+" ");
			inorder(temp.right);
		}
	}

	//O(n)
	public void levelTraversal(){
		java.util.Queue<MyNode<T>> queue = new java.util.LinkedList<MyNode<T>>();
		MyNode<T> temp = root;
		while(temp!=null){
			System.out.print(temp.data+" ");
			if (temp.left!=null)
				queue.offer(temp.left);
			if (temp.right!=null)
				queue.offer(temp.right);
			temp = queue.poll();
		}
		System.out.println();
	}


	public void insert(T element){
		if(root==null)
			root = new MyNode<T>(element,null,null);
		else
			insertNode(root, element);
		size++;
	}

	//O(h) -- O(log n) to O(n)
	private void insertNode(MyNode<T> temp, T element){
		int compared = temp.data.compareTo(element);
		if(compared > 0){
			if(temp.left==null){
				MyNode<T> insertMe = new MyNode<T>(element,null,null);
				temp.left = insertMe;
			}
			else
				insertNode(temp.left, element);
		}
		else {
			if(temp.right==null){
				MyNode<T> insertMe = new MyNode<T>(element,null,null);
				temp.right = insertMe;
			}
			else
				insertNode(temp.right, element);
		}
	}


	public boolean remove(T element){
		boolean success = removeNode(root,null, element);
		if (success)
			size--;
		return success;
	}

	//O(h) -- O(log n) to O(n)
	private boolean removeNode(MyNode<T> temp, MyNode<T> parent, T element){
		if (temp==null)	//Node not present
			return false;
		else{
			int compared = temp.data.compareTo(element);
			if(compared==0){	//this is the node to remove
				//delete temp
				removeNode(temp,parent);
				return true;
			}
			else if (compared>0){ //in left subtree
				return removeNode(temp.left, temp, element);
			}
			else{ //in right subtree
				return removeNode(temp.right, temp, element);
			}
		}
	}

	//overloaded method to remove non-null node temp
	private void removeNode(MyNode<T> temp, MyNode<T> parent){
		if(temp.right==null && temp.left==null) {//leaf node, easy!
			if(root==temp)	//deleted only node
				root=null;
			else if (parent.left==temp)
				parent.left=null;
			else if (parent.right==temp)
				parent.right=null;
		}
		else if (temp.right==null){ //one left child
			if(root==temp)
				root=temp.left;
			else if (parent !=null && parent.left==temp)
				parent.left=temp.left;
			else
				parent.right=temp.left;
		}
		else if (temp.left==null){ //one right child
			if(root==temp)
				root=temp.right;
			else if (parent.left==temp)
				parent.left=temp.right;
			else
				parent.right=temp.right;
		}
		else { //two children
			//find inorder successor
			//this is the leftmost node in the right subtree
			//we could also use the inorder predecessor - rightmost node in left subtree
			MyNode<T> curr = temp.right;
			MyNode<T> currParent = temp;
			while(curr.left!=null){
				currParent = curr;
				curr=curr.left;
			}
			//write this value in place of temp:
			temp.data=curr.data;
			//and remove this new node:
			removeNode(curr,currParent);
			//No need to adjust the root here...
		}
	}

	/*public static void main(String args[]){
		MyBST<Integer> tree = new MyBST<>();
		tree.insert(20);
		tree.insert(10);
		tree.insert(7);
		tree.insert(30);
		tree.insert(40);
		tree.insert(15);
		tree.insert(11);
		tree.inorder();
		tree.levelTraversal();
		tree.remove(20);
		tree.inorder();
		tree.levelTraversal();
		System.out.println(tree.contains(40));
		System.out.println(tree.contains(1));

		System.out.println();
	}*/

        public int countOccurrences(T element)
        {
            if(root == null)
                return 0;
            return countOccurrences(root, element);
        }
        
        private int countOccurrences(MyNode<T> node, T element)
        {
            int count = 0;
            
            if(node == null)
                return 0;
            if(element.compareTo(node.data) < 0)
                count += countOccurrences(node.left, element);
            else if(element.compareTo(node.data) == 0)
            {
                count++;
                count += countOccurrences(node.right, element);
            }
            else//if(element.compareTo(root.data) > 0)
                count += countOccurrences(node.right, element);
            return count;
        }

        public int inBetween(T low, T high)
        {
            if(root == null)
                return 0;
            return inBetween(root, low, high);
        }
        
        private int inBetween(MyNode<T> node, T low, T high)
        {
            int count = 0;
            
            if(node == null)
                return 0;
            if(node.data.compareTo(high) < 0 && node.data.compareTo(low) > 0)
                count++;
            count += inBetween(node.left, low, high);
            count += inBetween(node.right, low, high);
            return count;
        }
        
        //Look at the overloaded helper.
        public int removeLessThan(T element)
        {
            if(root == null)
                return 0;
            return removeLessThan(null, root, element);
        }
        
        /*
        In the worst case, each internal node is less than the element.
        Suppose the tree is unbalanced such that it forms a singly-linked list
        and we must visit every node.
        T(n)=T(n-1)+O(1)
        =T(n-1)+1
        =T(n-2)+2
        =T(n-3)+3
        =T(n-k)+k
        Let k=n.
        =T(0)+n
        =O(n)
        Suppose the tree is balanced, but we must still visit every node.
        T(n)=T(n/2)+T(n/2)+O(1)
        =2T(n/2)+1
        =2(2T(n/4)+1)+1
        =4T(n/4)+3
        =4(2T(n/8)+1)+3
        =8T(n/8)+5
        =(2^k)T(n/2^k)+2k-1
        Let k=log(n).
        =2^log(n)(n/2^log(n))+2log(n)-1
        =n*T(n/n)+2log(n)-1
        =O(n)*O(1)+2O(log(n))-O(1)
        =O(n)
        */
        private int removeLessThan(MyNode<T> parent, MyNode<T> node, T element)
        {
            int count = 0;
            
            if(node == null)
                return 0;
            if(node.data.compareTo(element) >= 0)
                count += removeLessThan(node, node.left, element);
            else if(node.data.compareTo(element) < 0)
            {
                count++;
                count += removeLessThan(node, node.left, element);
                count += removeLessThan(node, node.right, element);
                if(parent == null)//if root
                    root = node.right;
                else if(node.data.compareTo(parent.data) < 0)//if left child
                    parent.left = node.right;
                else//if right child
                    parent.right = node.right;
            }
            return count;
        }
}








