/**
 * @author Christian Wendlandt
 * @version 2017.11.9
 */

import java.util.Scanner;
import java.util.Random;

public class Driver
{
    public static void main(String[] args)
    {
        final int NUMBER_OF_TESTS = 4;
        final int TEST_SIZE_FACTOR = 2;
        LPHashTable<Integer> table = new LPHashTable();
        Scanner input = new Scanner(System.in);
        Random random = new Random();
        int[] numberOfEntriesPerIteration = new int[NUMBER_OF_TESTS];
        long[] timeElapsed = new long[NUMBER_OF_TESTS];
        long stopWatch;
        int numberOfEntries;
        
        System.out.println("How many entries?");
        numberOfEntries = input.nextInt();
        numberOfEntriesPerIteration[0] = numberOfEntries;
        for(int i = 1; i < NUMBER_OF_TESTS; i++)
        {
            numberOfEntries *= TEST_SIZE_FACTOR;
            numberOfEntriesPerIteration[i] = numberOfEntries;
        }
        
        System.out.println("--------------------------------------------------------------------------------");
        System.out.println("      n        big O    elapsed time in nanos   elapsed time / big O  normalized");
        System.out.println("-------   ----------    ---------------------   --------------------  ----------");
        
        for(int i = 0; i < NUMBER_OF_TESTS; i++)
        {
            table.clear();//resets the capacity as well.
            for(int j = 0; j < numberOfEntriesPerIteration[i]; j++)
                table.insert(random.nextInt(), random.nextInt());
            for(int j = 0; j < numberOfEntriesPerIteration[i]; j++)
            {
                stopWatch = System.nanoTime();
                table.search(random.nextInt());
                timeElapsed[i] += System.nanoTime() - stopWatch;
            }
        }
        
        for(int i = 0; i < NUMBER_OF_TESTS; i++)
            System.out.printf("%7d%13d%25d%23.5f%12.2f\n",
                    numberOfEntriesPerIteration[i],
                    numberOfEntriesPerIteration[i],
                    timeElapsed[i],
                    (double)timeElapsed[i] / numberOfEntriesPerIteration[i],
                    (double)timeElapsed[i] / numberOfEntriesPerIteration[i] *
                            numberOfEntriesPerIteration[0] / timeElapsed[0]);
        
        //table.printOut();//evidence that tables are filled.
    }
}

/*
A sample run. If times are low, normalization may vary by quite a bit.

How many entries?
1000000
--------------------------------------------------------------------------------
      n        big O    elapsed time in nanos   elapsed time / big O  normalized
-------   ----------    ---------------------   --------------------  ----------
1000000      1000000                110018740              110.01874        1.00
2000000      2000000                225886406              112.94320        1.03
4000000      4000000                473789355              118.44734        1.08
8000000      8000000                963732622              120.46658        1.09
*/