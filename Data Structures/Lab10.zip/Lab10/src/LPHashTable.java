/**
 * @author Christian Wendlandt
 * @version 2017.11.9
 */

public class LPHashTable<T>
{
    private Bucket[] table;
    private final double LOAD_FACTOR_THRESHOLD = .6;//always > 0 and < 1
    private int tableUsage;
    private int size;
    
    private class Bucket<T>
    {
        int key;
        T element;
        boolean isFull;
        
        Bucket(int key, T element)
        {
            this.key = key;
            this.element = element;
            isFull = true;
        }
    }
    
    public LPHashTable()
    {
        table = new Bucket[7];
        tableUsage = size = 0;
    }
    
    public void insert(int key, T element)
    {
        int index;
        Bucket bucket;
        
        index = getHash(key);
        bucket = table[index];
        while(bucket != null && bucket.isFull)
        {
            index = ++index % table.length;
            bucket = table[index];
        }
        if(bucket == null)
            tableUsage++;
        table[index] = new Bucket(key, element);
        size++;
        if((double)tableUsage / table.length > LOAD_FACTOR_THRESHOLD)
            resize();
    }
    
    public T delete(int key)
    {
        int index = getHash(key);
        Bucket bucket = table[index];
        
        while(bucket != null)
        {
            if(bucket.key == key && bucket.isFull)
            {
                bucket.isFull = false;
                size--;
                return (T)bucket.element;
            }
            index = ++index % table.length;
            bucket = table[index];
        }
        return null;
    }
    
    public T search(int key)
    {
        int index = getHash(key);
        Bucket bucket = table[index];
        
        while(bucket != null)
        {
            if(bucket.isFull && bucket.key == key)
                return (T)bucket.element;
            index = ++index % table.length;
            bucket = table[index];
        }
        return null;
    }
    
    public boolean isEmpty()
    {
        return size == 0;
    }
    
    public void printOut()
    {
        System.out.printf("Capacity: %d, Size: %d\n", table.length, size);
        for(Bucket bucket : table)
        {
            if(bucket == null)
                System.out.println("empty");
            else if(bucket.isFull)
                System.out.printf("(%d, %s)\n", bucket.key, bucket.element.toString());
            else
                System.out.println("deleted");
        }
    }
    
    public void clear()
    {
        table = new Bucket[7];
        tableUsage = size = 0;
    }
    
    private void resize()
    {
        Bucket[] tempTable = table;
        
        table = new Bucket[2 * table.length + 1];
        tableUsage = size = 0;
        for(Bucket bucket : tempTable)
            if(bucket != null && bucket.isFull)
                insert(bucket.key, (T)bucket.element);
    }
    
    private int getHash(int key)
    {
        int length = table.length;
        
        key = key % length;
        if(key < 0)
            key += length;
        return key;
        //Java gives us the remainder, which may be negative. This will give us the modulus.
    }
    
    ////////////////////////////////////////////////////////////////////////////
    
    public static void main(String[] args)
    {
        LPHashTable<String> hashTable = new LPHashTable<>();
        
        System.out.println(hashTable.isEmpty() ? "empty" : "not empty");
        hashTable.insert(21, "first");
        hashTable.insert(23, "second");
        hashTable.insert(14, "third");
        hashTable.insert(7, "fourth");
        hashTable.printOut();
        hashTable.delete(23);
        hashTable.printOut();
        hashTable.insert(0, "fifth");
        hashTable.printOut();
        hashTable.insert(28, "sixth");
        hashTable.printOut();
        System.out.println(hashTable.search(21));
        System.out.println(hashTable.delete(21));
        hashTable.printOut();
        System.out.println(hashTable.isEmpty() ? "empty" : "not empty");
        hashTable.clear();
        System.out.println(hashTable.isEmpty() ? "empty" : "not empty");
    }
}