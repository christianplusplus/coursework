package lab5;

/**
 * @author Christian Wendlandt
 * @version 10/05/07
 */
public class Driver
{
    public static void main(String[] args)
    {
        Quack<Integer> t1 = new Quack<>();
        t1.insert(1);
        t1.insert(2);
        t1.insert(3);
        t1.insert(4);
        System.out.println(t1);
        System.out.println("First element: " + t1.peekFirst());
        System.out.println("Last element: " + t1.peekLast());
        t1.pop();
        System.out.println(t1);
        System.out.println("First element: " + t1.peekFirst());
        System.out.println("Last element: " + t1.peekLast());
        t1.insert(5);
        t1.insert(6);
        System.out.println(t1);
        System.out.println("First element: " + t1.peekFirst());
        System.out.println("Last element: " + t1.peekLast());
        t1.dequeue();
        System.out.println(t1);
        System.out.println("First element: " + t1.peekFirst());
        System.out.println("Last element: " + t1.peekLast());
        t1.insert(7);
        System.out.println(t1);
        System.out.println("First element: " + t1.peekFirst());
        System.out.println("Last element: " + t1.peekLast());
        t1.flip();
        System.out.println(t1);
        System.out.println("First element: " + t1.peekFirst());
        System.out.println("Last element: " + t1.peekLast());
        t1.insert(99);
        System.out.println(t1);
        System.out.println("First element: " + t1.peekFirst());
        System.out.println("Last element: " + t1.peekLast());
        t1.flip();
        System.out.println(t1);
        System.out.println("First element: " + t1.peekFirst());
        System.out.println("Last element: " + t1.peekLast());
        t1.pop();
        t1.pop();
        t1.pop();
        t1.pop();
        t1.pop();
        t1.pop();
        t1.pop();
        System.out.println(t1);
        t1.insert(8);
        t1.insert(9);
        t1.insert(10);
        System.out.println(t1);
        System.out.println("First element: " + t1.peekFirst());
        System.out.println("Last element: " + t1.peekLast());
        t1.dequeue();
        t1.dequeue();
        t1.dequeue();
        t1.dequeue();
        System.out.println(t1);
    }
}
