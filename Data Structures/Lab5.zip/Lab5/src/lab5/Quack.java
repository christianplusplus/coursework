package lab5;

/**
 * @author Christian Wendlandt
 * @version 10/05/07
 * @param <T>
 */
public class Quack<T extends Comparable<T>>
{
    private Node head;
    private Node tail;
    private int size;
    
    public class Node
    {
        Node prev;
        Node next;
        T element;
        
        Node(T element)
        {
            prev = null;
            next = null;
            this.element = element;
        }
    }
    
    //O(1)
    Quack()
    {
        head = null;
        tail = null;
        size = 0;
    }
    
    //O(1)
    public void insert(T element)
    {
        Node newNode = new Node(element);
        
        if(isEmpty())
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            newNode.prev = tail;
            tail.next = newNode;
            tail = newNode;
        }
        size++;
    }
    
    //O(1)
    public T pop()
    {
        T element;
        
        if(isEmpty())
            return null;
        element = tail.element;
        if(size == 1)
        {
            head = null;
            tail = null;
        }
        else
        {
            tail = tail.prev;
            tail.next = null;
        }
        size--;
        return element;
    }
    
    //O(1)
    public T peekFirst()
    {
        if(isEmpty())
            return null;
        return head.element;
    }
    
    //O(1)
    public T peekLast()
    {
        if(isEmpty())
            return null;
        return tail.element;
    }
    
    //O(1)
    public T dequeue()
    {
        T element;
        
        if(isEmpty())
            return null;
        element = head.element;
        if(size == 1)
        {
            head = null;
            tail = null;
        }
        else
        {
            head = head.next;
            head.prev = null;
        }
        size--;
        return element;
    }
    
    //O(n)
    public void flip()
    {
        Node currentNode;
        Node tempNode;
        
        if(isEmpty())
            return;
        currentNode = head;
        //swapping prev and next for each Node reverses the order.
        tempNode = currentNode.prev;
        currentNode.prev = currentNode.next;
        currentNode.next = tempNode;

        while(currentNode.prev != null)
        {
            //progressing forward through the list by "walking backwards".
            currentNode = currentNode.prev;

            tempNode = currentNode.prev;
            currentNode.prev = currentNode.next;
            currentNode.next = tempNode;
        }
        //we need to swap head and tail as well.
        tempNode = head;
        head = tail;
        tail = tempNode;
    }
    
    //O(1)
    public int size()
    {
        return size;
    }
    
    //O(n)
    @Override
    public String toString()
    {
        StringBuilder string = new StringBuilder("[");
        Node currentNode;
        
        if(!isEmpty())
        {
            currentNode = head;
            for(int i = 0; i < size - 1; i++)
            {
                string.append(currentNode.element.toString());
                string.append(", ");
                currentNode = currentNode.next;
            }
            string.append(currentNode.element.toString());
        }
        string.append("]");
        return string.toString();
    }
    
    private boolean isEmpty()
    {
        return head == null;
    }
}