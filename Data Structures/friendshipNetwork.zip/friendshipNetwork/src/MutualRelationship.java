/**
 * @author Christian Wendlandt
 * @version 2017.12.8
 */

import java.util.HashMap;

public class MutualRelationship
{
    public final String origin;
    public final String destination;
    public final double mutualityScore;
    
    public MutualRelationship(String origin, String mutual, String destination,
            HashMap<Integer, Edge> edges)
    {
        this.origin = origin;
        this.destination = destination;
        
        mutualityScore = edges.get((origin + mutual).hashCode()).weight +
                edges.get((mutual + destination).hashCode()).weight;
    }
}
