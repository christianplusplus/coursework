/**
 * @author Christian Wendlandt
 * @version 2017.12.6
 */

import java.util.HashMap;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Stack;
import java.util.HashSet;
import java.util.Collection;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class Graph
{
    private final boolean isDirected;
    private final HashMap<String, Vertex> vertices;
    //key is label
    private final HashMap<Integer, Edge> edges;
    //key is (origin label + destination label).hashCode()
    
    Graph(boolean isDirected)
    {
        this.isDirected = isDirected;
        vertices = new HashMap<>();
        edges = new HashMap<>();
    }
    
    
    /**
     * Gets whether or not the graph is directed.
     * @return The state of "directedness".
     */
    public boolean isDirected()
    {
        return isDirected;
    }
    
    /**
     * Gets the number of vertices in the graph.
     * @return The number of vertices.
     */
    public int vertexCount()
    {
        return vertices.size();
    }
    
    /**
     * Gets the number of Edges in the graph.
     * @return The number of Edges.
     */
    public int edgeCount()
    {
        return isDirected ? edges.size() : edges.size() / 2;
    }
    
    /**
     * Adds a vertex to the graph.
     * @param label The name of the vertex. It must be unique.
     */
    public void insertVertex(String label)
    {
        vertices.put(label, new Vertex(label));
    }
    
    /**
     * Adds an edge to graph. Vertices must exist beforehand.
     * If the graph is undirected, a mirror edge will be added as well.
     * @param origin The origin of the edge.
     * @param destination The destination of the edge.
     */
    public void insertEdge(String origin, String destination)
    {
        insertEdge(origin, destination, 1);
    }
    public void insertEdge(String origin, String destination, double weight)
    {
        Vertex originVertex = vertices.get(origin);
        Vertex destinationVertex = vertices.get(destination);
        
        edges.put((origin + destination).hashCode(),
                new Edge(origin, destination, weight));
        originVertex.addOutgoingNeighbor(destination);
        destinationVertex.addIncomingNeighbor(origin);
        if(!isDirected)
        {
            edges.put((destination + origin).hashCode(),
                    new Edge(destination, origin, weight));
            destinationVertex.addOutgoingNeighbor(origin);
            originVertex.addIncomingNeighbor(destination);
        }
    }
    
    /**
     * Takes a properly formatted file containing a list of edges to be inserted
     * into the graph. Any vertices listed as part of an edge will be added to.
     * If the graph is undirected, mirror edges will be added as well.
     * @param file The file to be scanned. Each line should read like so:
     * "origin destination x" where x is the weight of the edge (which is a double).
     */
    public void insertEdgeCollectionFile(File file)
    {
        Scanner scan;
        String[] edge;
        
        try
        {
            scan = new Scanner(file);
        }
        catch(FileNotFoundException | NullPointerException ex)
        {
            System.out.println("Not a valid file.");
            return;
        }
        while(scan.hasNextLine())
        {
            edge = scan.nextLine().split("[\\t ]+");
            if(!vertices.containsKey(edge[0]))
                insertVertex(edge[0]);
            if(!vertices.containsKey(edge[1]))
                insertVertex(edge[1]);
            insertEdge(edge[0], edge[1], Double.parseDouble(edge[2]));
        }
    }
    
    /**
     * Removes a vertex from the graph and any edges that were connected to it.
     * @param vertex The vertex to be removed.
     */
    public void removeVertex(String vertex)
    {
        for(Object neighbor : vertices.get(vertex).getOutgoingNeighborsList())
        {
            vertices.get((String)neighbor).deleteIncomingNeighbor(vertex);
            edges.remove((vertex + (String)neighbor).hashCode());
        }
        for(Object neighbor : vertices.get(vertex).getIncomingNeighborsList())
        {
            vertices.get((String)neighbor).deleteOutgoingNeighbor(vertex);
            edges.remove(((String)neighbor + vertex).hashCode());
        }
        vertices.remove(vertex);
    }
    
    /**
     * Removes an edge from the graph. If undirected, will remove the mirror edge
     * as well.
     * @param origin The label of the origin vertex of the edge.
     * @param destination The label of the destination vertex of the edge.
     */
    public void removeEdge(String origin, String destination)
    {
        vertices.get(origin).getOutgoingNeighborsList().remove(destination);
        vertices.get(destination).getIncomingNeighborsList().remove(origin);
        edges.remove((origin + destination).hashCode());
        if(!isDirected)
        {
            vertices.get(destination).getOutgoingNeighborsList().remove(origin);
            vertices.get(origin).getIncomingNeighborsList().remove(destination);
            edges.remove((destination + origin).hashCode());
        }
    }
    
    /**
     * Returns whether or not a vertex is inside of the graph.
     * @param vertex The vertex label to be checked.
     * @return True or false.
     */
    public boolean containsVertex(String vertex)
    {
        return vertices.containsKey(vertex);
    }
    
    /**
     * Returns whether or not a edge is inside of the graph.
     * @param origin The label of the origin vertex of the edge.
     * @param destination The label of the destination vertex of the edge.
     * @return True or false.
     */
    public boolean containsEdge(String origin, String destination)
    {
        return edges.containsKey((origin + destination).hashCode());
    }
    
    /**
     * Implementation of a standard Breath First Search traversal.
     * @param origin Where the search will start.
     * @return An array list of traversed vertices, ordered by range (the ranges are unknown).
     */
    public ArrayList<Vertex> BFS(String origin)
    {
        ArrayList<Vertex> searchList = new ArrayList<>();
        LinkedList<String> queue = new LinkedList<>();
        HashSet<String> discovered = new HashSet<>();
        Vertex vertex;
        
        queue.offer(origin);
        discovered.add(origin);
        while(!queue.isEmpty())
        {
            vertex = vertices.get(queue.poll());
            searchList.add(vertex);
            for(Object neighbor : vertex.getOutgoingNeighborsList())
            {
                if(!discovered.contains((String)neighbor))
                {
                    queue.offer((String)neighbor);
                    discovered.add((String)neighbor);
                }
            }
        }
        return searchList;
    }
    
    /**
     * Implementation of a standard Depth First Search. Preference of traversal
     * is somewhat random, since lists are sorted in HashMaps.
     * @param origin Where the search begins.
     * @return An array list of vertex labels in the order they were found.
     */
    public ArrayList<Vertex> DFS(String origin)
    {
        ArrayList<Vertex> searchList = new ArrayList<>();
        Stack<String> stack = new Stack();
        HashSet<String> discovered = new HashSet<>();
        Vertex vertex;
        
        stack.push(origin);
        while(!stack.isEmpty())
        {
            origin = stack.pop();
            if(!discovered.contains(origin))
            {
                vertex = vertices.get(origin);
                searchList.add(vertex);
                discovered.add(origin);
                for(Object neighbor : vertex.getOutgoingNeighborsList())
                    if(!discovered.contains((String)neighbor))
                        stack.push((String)neighbor);
            }
        }
        return searchList;
    }
    
    /**
     * Standard implementation of Dykstra's Shortest Path algorithm.
     * @param origin Where the algorithm starts.
     * @return Returns an unsorted list of vertices with a predecessor and distance
     * from the origin. To find the path to the origin, just follow the predecessors.
     */
    public HashMap<String, PathWrapper> shortestPath(String origin)
    {
        HashMap<String, PathWrapper> pathList = new HashMap<>();
        LinkedList<String> queue = new LinkedList<>();
        HashSet<String> discovered = new HashSet<>();
        String neighborLabel;
        
        for(Vertex vertex : vertices.values())
            pathList.put(vertex.label,
                    new PathWrapper(null, Double.POSITIVE_INFINITY));
        pathList.get(origin).distance = 0;
        queue.offer(origin);
        while(!queue.isEmpty())
        {
            origin = queue.poll();
            discovered.add(origin);
            for(Object neighbor : vertices.get(origin).getOutgoingNeighborsList())
            {
                neighborLabel = (String)neighbor;
                if(!discovered.contains(neighborLabel))
                {
                    if(pathList.get(origin).distance +
                            edges.get((origin + neighborLabel).hashCode()).weight <
                            pathList.get(neighborLabel).distance)
                    {
                        pathList.get(neighborLabel).distance =
                                pathList.get(origin).distance +
                                edges.get((origin + neighborLabel).hashCode()).weight;
                        pathList.get(neighborLabel).predecessor = origin;
                        queue.offer(neighborLabel);
                    }
                }
            }
        }
        return pathList;
    }
    
    
    /**
     * Slightly modified Shortest Path algorithm. Will stop after reaching the
     * desired range.
     * @param origin Where to the search starts.
     * @param range How far the the search will traverse before stopping.
     * @return origin Where the algorithm starts.
     * @return Returns an unsorted list of vertices with a predecessor and distance
     * from the origin. Vertices out of range don't have a predecessor and will
     * show a distance of infinity.
     */
    public HashMap<String, PathWrapper> shortestPathRestricted(String origin, double range)
    {
        HashMap<String, PathWrapper> pathList = new HashMap<>();
        LinkedList<String> queue = new LinkedList<>();
        HashSet<String> discovered = new HashSet<>();
        String neighborLabel;
        
        for(Vertex vertex : vertices.values())
            pathList.put(vertex.label,
                    new PathWrapper(null, Double.POSITIVE_INFINITY));
        pathList.get(origin).distance = 0;
        queue.offer(origin);
        while(!queue.isEmpty())
        {
            origin = queue.poll();
            discovered.add(origin);
            for(Object neighbor : vertices.get(origin).getOutgoingNeighborsList())
            {
                neighborLabel = (String)neighbor;
                if(!discovered.contains(neighborLabel))
                {
                    if(pathList.get(origin).distance + 1 <
                            pathList.get(neighborLabel).distance &&
                            pathList.get(origin).distance + 1 <= range)
                    {
                        pathList.get(neighborLabel).distance =
                                pathList.get(origin).distance + 1;
                        pathList.get(neighborLabel).predecessor = origin;
                        queue.offer(neighborLabel);
                    }
                }
            }
        }
        return pathList;
    }
    
    /**
     * Finds the shortest path between two vertices. Ignores weights. Terminates
     * the search as soon as the target is found to reduce time consumption.
     * @param origin Where the search starts.
     * @param destination The vertex that we want to find the distance to. If not
     * found, will show a "no connection" message in the toString().
     * @return A path object which will display the correct path to take and total
     * number of edges using the toString.
     */
    public Path shortestWeightlessPath(String origin, String destination)
    {
        HashMap<String, PathWrapper> pathList = new HashMap<>();
        LinkedList<String> queue = new LinkedList<>();
        HashSet<String> discovered = new HashSet<>();
        String neighborLabel;
        
        for(Vertex vertex : vertices.values())
            pathList.put(vertex.label,
                    new PathWrapper(null, Double.POSITIVE_INFINITY));
        pathList.get(origin).distance = 0;
        queue.offer(origin);
        mainLoop:
        while(!queue.isEmpty())
        {
            origin = queue.poll();
            discovered.add(origin);
            for(Object neighbor : vertices.get(origin).getOutgoingNeighborsList())
            {
                neighborLabel = (String)neighbor;
                if(!discovered.contains(neighborLabel))
                {
                    if(pathList.get(origin).distance + 1 <
                            pathList.get(neighborLabel).distance)
                    {
                        pathList.get(neighborLabel).distance =
                                pathList.get(origin).distance + 1;
                        pathList.get(neighborLabel).predecessor = origin;
                        
                        //escape if destination found
                        if(neighborLabel.equals(destination))
                            break mainLoop;
                        
                        queue.offer(neighborLabel);
                    }
                }
            }
        }
        return new Path(pathList, destination);
    }
    
    /**
     * Finds the most connected node by counting the indegree and outdegree of
     * each vertex, even if the graph is undirected.
     * @return Returns an array list containing the most connected
     * vertex and any vertex that ties with it. To get the the number number of
     * connections, just call the getInDegree() and getOutDegree() methods on
     * any vertex in the array.
     */
    public ArrayList<Vertex> mostConnectedNodes()
    {
        ArrayList<Vertex> mostConnectedNodes = new ArrayList<>();
        int mostConnections = 0;
        int connections;
        
        for(Vertex vertex : vertices.values())
        {
            connections = vertex.getInDegree() + vertex.getOutDegree();
            if(connections < mostConnections)
                continue;//Common case first;
            if(connections == mostConnections)
                mostConnectedNodes.add(vertex);
            else//connections > mostConnections
            {
                mostConnectedNodes = new ArrayList();
                mostConnectedNodes.add(vertex);
                mostConnections = connections;
            }
        }
        return mostConnectedNodes;
    }
    
    /**
     * Looks at Friend nodes within a range of 2 and chooses recommendations offered
     * as a collection of labels. Recommendations are based off of how strong
     * the mutual friendships are between the home account and its friends of friends.
     * @param origin The home node that is being given the recommendations.
     * @return A standard collection of suggestions wrappers, which can be sorted
     * by score.
     */
    public Collection<RecommendationWrapper> getBestMutualFriends(String origin)
    {
        ArrayList<FriendConnection> connections = new ArrayList<>();
        HashMap<String, RecommendationWrapper> friendRecommendations = new HashMap<>();
        HashSet<String> discovered = new HashSet<>();
        String mutualFriendName;
        String friendsFriendName;
        
        discovered.add(origin);
        for(Object mutualFriend : vertices.get(origin).getOutgoingNeighborsList())
            discovered.add((String)mutualFriend);
        for(Object mutualFriend : vertices.get(origin).getOutgoingNeighborsList())
        {
            mutualFriendName = (String)mutualFriend;
            for(Object friendsFriend : vertices.get(mutualFriendName).getOutgoingNeighborsList())
            {
                friendsFriendName = (String)friendsFriend;
                if(!discovered.contains(friendsFriendName))
                    connections.add(new FriendConnection(origin, mutualFriendName, friendsFriendName));
            }
        }
        for(FriendConnection friend : connections)
        {
            if(friendRecommendations.containsKey(friend.friendOfFriend))
            {
                double weight = edges.get((friend.origin + friend.friend).hashCode()).weight +
                                        edges.get((friend.friend + friend.friendOfFriend).hashCode()).weight;
                friendRecommendations.get(friend.friendOfFriend).score += weight;
            }
            else
                friendRecommendations.put(friend.friendOfFriend,
                        new RecommendationWrapper(friend.friendOfFriend,
                                edges.get((friend.origin + friend.friend).hashCode()).weight +
                                        edges.get((friend.friend + friend.friendOfFriend).hashCode()).weight));
        }
        return friendRecommendations.values();
    }
    
    /**
     * Rates and offers friend recommendations to the home node based off of an
     * influence score of the home accounts friends. If a friend has relatively
     * few friends, then their score will be relatively high.
     * @param origin The home account.
     * @return A generic collection of recommendation wrappers that can be sorted
     * and trimmed to fit the needs of the caller.
     */
    public Collection<RecommendationWrapper> getMostInfulentialFriends(String origin)
    {
        ArrayList<FriendConnection> connections = new ArrayList<>();
        HashMap<String, RecommendationWrapper> friendRecommendations = new HashMap<>();
        HashSet<String> discovered = new HashSet<>();
        String mutualFriendName;
        String friendsFriendName;
        
        discovered.add(origin);
        for(Object mutualFriend : vertices.get(origin).getOutgoingNeighborsList())
            discovered.add((String)mutualFriend);
        for(Object mutualFriend : vertices.get(origin).getOutgoingNeighborsList())
        {
            mutualFriendName = (String)mutualFriend;
            for(Object friendsFriend : vertices.get(mutualFriendName).getOutgoingNeighborsList())
            {
                friendsFriendName = (String)friendsFriend;
                if(!discovered.contains(friendsFriendName))
                    connections.add(new FriendConnection(origin, mutualFriendName, friendsFriendName));
            }
        }
        for(FriendConnection friend : connections)
        {
            if(friendRecommendations.containsKey(friend.friendOfFriend))
            {
                double weight = 1. / vertices.get(friend.friend).getOutDegree();
                friendRecommendations.get(friend.friendOfFriend).score += weight;
            }
            else
                friendRecommendations.put(friend.friendOfFriend,
                        new RecommendationWrapper(friend.friendOfFriend,
                                1. / vertices.get(friend.friend).getOutDegree()));
        }
        return friendRecommendations.values();
    }
    
    @Override
    public String toString()
    {
        StringBuilder string = new StringBuilder();
        String edgeString;
        int breakCounter = 0;
        
        string.append("V={");
        for(String label : vertices.keySet())
        {
            if(breakCounter > 70)
            {
                string.append("\n   ");
                breakCounter = 0;
            }
            string.append(label);
            string.append(',');
            breakCounter += label.length() + 1;
        }
        if(!vertices.isEmpty())
            string.deleteCharAt(string.length() - 1);//removes trailing commas.
        
        breakCounter = 0;
        string.append("}\nE={");
        for(Edge edge : edges.values())
        {
            if(breakCounter > 70)
            {
                string.append("\n   ");
                breakCounter = 0;
            }
            edgeString = edge.toString();
            string.append(edgeString);
            string.append(',');
            breakCounter += edgeString.length() + 1;
        }
        if(!edges.isEmpty())
            string.deleteCharAt(string.length() - 1);//removes trailing commas.
        string.append('}');
        
        return string.toString();
    }
    
    public void print()
    {
        System.out.println(toString());
    }
}
