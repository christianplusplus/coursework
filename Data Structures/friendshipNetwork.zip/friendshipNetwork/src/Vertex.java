/**
 * @author Christian Wendlandt
 * @version 2017.12.6
 */

import java.util.ArrayList;

public class Vertex<T> implements Comparable<Vertex>
{
    private T data;
    private final ArrayList<String> outgoingNeighborsList;
    private final ArrayList<String> incomingNeighborsList;
    public final String label;
    
    public Vertex(String label)
    {
        this(label, null);
    }
    
    public Vertex(String label, T data)
    {
        this.label = label;
        this.data = data;
        outgoingNeighborsList = new ArrayList<>();
        incomingNeighborsList = new ArrayList<>();
    }
    
    public void addOutgoingNeighbor(String neighbor)
    {
        outgoingNeighborsList.add(neighbor);
    }
    
    public void addIncomingNeighbor(String neighbor)
    {
        incomingNeighborsList.add(neighbor);
    }
    
    public void deleteOutgoingNeighbor(String neighbor)
    {
        outgoingNeighborsList.remove(neighbor);
    }
    
    public void deleteIncomingNeighbor(String neighbor)
    {
        incomingNeighborsList.remove(neighbor);
    }
    
    public int getOutDegree()
    {
        return outgoingNeighborsList.size();
    }
    
    public int getInDegree()
    {
        return incomingNeighborsList.size();
    }
    
    public ArrayList<String> getOutgoingNeighborsList()
    {
        return outgoingNeighborsList;
    }
    
    public ArrayList<String> getIncomingNeighborsList()
    {
        return incomingNeighborsList;
    }
    
    public String getLabel()
    {
        return label;
    }
    
    public T getData()
    {
        return data;
    }
    
    public void setData(T data)
    {
        this.data = data;
    }
    
    @Override
    public String toString()
    {
        if(data != null)
            return "[" + label + ", " + data.toString() + "]";
        return label;
    }
    
    @Override
    public int compareTo(Vertex otherVertex)
    {
        return label.compareTo(otherVertex.label);
    }
    
    @Override
    public boolean equals(Object otherVertex)
    {
        if(otherVertex instanceof Vertex)
            return label.equals(((Vertex)otherVertex).label);
        return false;
    }

    @Override
    public int hashCode()
    {
        return label.hashCode();
    }
}
