/**
 * @author Christian Wendlandt
 * @version 2017.12.7
 */

import java.io.File;
import javax.swing.JFileChooser;

public class FileChooser
{
    public static File chooseFile()
    {
        File file;
        
        JFileChooser chooser = new JFileChooser();
        if(chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
            file = chooser.getSelectedFile();
        else
            file = null;
        return file;
    }
}
