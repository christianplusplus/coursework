/**
 * @author Christian Wendlandt
 * @version 2017.12.7
 */

import java.util.LinkedList;
import java.util.HashMap;

public class Path
{
    public final LinkedList<String> directions;
    public final double distance;
    
    public Path(HashMap<String, PathWrapper> pathList, String destination)
    {
        directions = new LinkedList<>();
        this.distance = pathList.get(destination).distance;
        String predecessor;
        
        predecessor = destination;
        do
        {
            directions.offerFirst(predecessor);
            predecessor = pathList.get(predecessor).predecessor;
        }while(predecessor != null);
    }
    
    @Override
    public String toString()
    {
        StringBuilder string = new StringBuilder();
        
        for(String node : directions)
        {
            string.append(node);
            string.append("->");
        }
        string.delete(string.length() - 2, string.length());
        if(distance == Double.POSITIVE_INFINITY)
            string.append(" . . . No path.");
        else
        {
            string.append('\n');
            string.append("Distance: ");
            string.append(distance);
        }
        return string.toString();
    }
}