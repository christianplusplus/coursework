/**
 * @author Christian Wendlandt
 * @version 2017.12.6
 */
public class RecommendationWrapper implements Comparable<RecommendationWrapper>
{
    public final String name;
    public double score;
    
    public RecommendationWrapper(String name, double score)
    {
        this.name = name;
        this.score = score;
    }
    
    @Override
    public int compareTo(RecommendationWrapper otherFriend)
    {
        if(score < otherFriend.score)
            return -1;
        if(score > otherFriend.score)
            return 1;
        return 0;
    }
    
    @Override
    public boolean equals(Object otherRec)
    {
        if(otherRec instanceof RecommendationWrapper)
            return name.equals(((RecommendationWrapper)otherRec).name);
        return false;
    }
    
    @Override
    public String toString()
    {
        StringBuilder string = new StringBuilder("(");
        
        string.append(name);
        string.append(',');
        string.append(score);
        string.append(')');
        return string.toString();
    }
}