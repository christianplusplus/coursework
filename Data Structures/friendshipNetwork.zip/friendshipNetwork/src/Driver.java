/**
 * @author Christian Wendlandt
 * @version 2017.12.7
 */

import java.util.ArrayList;
import java.util.Collections;

public class Driver
{
    public static void main(String[] args)
    {
        Graph network;
        String testNode1 = "1";
        String testNode2 = "10123";
        
        //Creates the network.
        network = new Graph(false);
        network.insertEdgeCollectionFile(FileChooser.chooseFile());
        
        System.out.println();
        
        //Finds the most connected friend.
        ArrayList<Vertex> mostConnectedNodes = network.mostConnectedNodes();
        System.out.println(mostConnectedNodes);
        System.out.println((mostConnectedNodes.get(0).getInDegree() +
                mostConnectedNodes.get(0).getOutDegree()) / 2 + " Connections");
        
        System.out.println();
        
        //Finds the shortest path between two friends.
        Path path = network.shortestWeightlessPath(testNode1, testNode2);
        System.out.println(path);
        
        System.out.println();

        //Finds 5 friend reccomendations based on mutuality and displays their score.
        ArrayList<RecommendationWrapper> recommendationszByMutuality = new ArrayList<>();
        recommendationszByMutuality.addAll(network.getBestMutualFriends(testNode1));
        Collections.sort(recommendationszByMutuality, Collections.reverseOrder());
        System.out.println(recommendationszByMutuality.subList(0, 5));
        
        System.out.println();
        
        //Finds 5 friends based on infulence and displays their score.
        ArrayList<RecommendationWrapper> recommendationszByInfluence = new ArrayList<>();
        recommendationszByInfluence.addAll(network.getMostInfulentialFriends(testNode1));
        Collections.sort(recommendationszByInfluence, Collections.reverseOrder());
        System.out.println(recommendationszByInfluence.subList(0, 5));
    }
}