/**
 * @author Christian Wendlandt
 * @version 2017.12.6
 */
public class FriendConnection
{
    public final String origin;
    public final String friend;
    public final String friendOfFriend;
    
    public FriendConnection(String origin, String friend, String friendOfFriend)
    {
        this.origin = origin;
        this.friend = friend;
        this.friendOfFriend = friendOfFriend;
    }
}
