/**
 * @author Christian Wendlandt
 * @version 2017.11.22
 * Driver for testing or operating FileSynchronizer.java.
 * backup.txt is the file that states which folder is the live version and which
 * one is the backup version; in that order.
 */

import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;

public class Driver
{
    public static void main(String[] args)
    {
        FileSynchronizer sync = new FileSynchronizer();
        Scanner scan;
        File liveDirectory;
        File backupDirectory;
        
        try
        {
            scan = new Scanner(new File("src\\backup.txt"));
            liveDirectory = new File(scan.nextLine());
            backupDirectory = new File(scan.nextLine());
            sync.readBackupDirectory(backupDirectory);
            sync.readLiveDirectory(liveDirectory);
            sync.printOut();
        }
        catch(FileNotFoundException ex)
        {
            System.out.println("Missing backup.txt");
        }
    }
}