/**
 * @author Christian Wendlandt
 * @version 2017.11.22
 * A wrapper class for file headers. Allows for file names to be stored and
 * compared based only on their names, but keeps their timestamps accessible.
 */

public class FileHeader implements Comparable<FileHeader>
{
    public final String fileName;
    public final long timestamp;
    
    public FileHeader(String fileName, long timestamp)
    {
        this.fileName = fileName;
        this.timestamp = timestamp;
    }
    
    @Override
    public int compareTo(FileHeader otherHeader)
    {
        return fileName.compareTo(otherHeader.fileName);
    }
    
    @Override
    public boolean equals(Object o)
    {
        if(o instanceof FileHeader)
            if(fileName.equals(((FileHeader) o).fileName))
                return true;
        return false;
    }

    @Override
    public int hashCode()
    {
        return fileName.hashCode();
    }
}
