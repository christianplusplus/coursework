/**
 * @author Christian Wendlandt
 * @version 2017.11.22
 * Maintains and updates a list of prime numbers, with particular emphasis on
 * the last and second to last primes on the list. Keeping the older primes
 * as part of a cache helps us find new primes faster.
 */

public class PrimesCache
{
    private int[] primes;
    private int secondToLastPrime;//for quick access.
    private int lastPrime;
    int size;
    
    public PrimesCache()
    {
        primes = new int[8];
        primes[0] = 2;
        size = 1;
    }
    
    /**
     * Updates the list of primes to include all primes up to the given number.
     * If the lead number is prime, the list will expand to include that number.
     * If the lead is not prime, the list will expand to the prime after it.
     * @param lead The number for which the list of primes must either match
     * or surpass.
     */
    public void updateCache(int lead)
    {
        while(lastPrime < lead)
            incrementPrimes();
    }
    
    /**
     * Allows easy access for the end of the list.
     * @return The last prime in the list.
     */
    public int getLastPrime()
    {
        return lastPrime;
    }
    
    /**
     * Allows easy access for the end of the list.
     * @return The second to last prime in the list. If 2 is the only prime,
     * then it returns 2.
     */
    public int getSecondToLastPrime()
    {
        if(size == 1)
            return 2;
        return secondToLastPrime;
    }
    
    @Override
    public String toString()
    {
        StringBuilder string = new StringBuilder();
        int counter = 0;
        
        for(int i = 0; i < size - 1; i++)
        {
            string.append(primes[i]);
            string.append("\n");
        }
        string.append(primes[size - 1]);
        return string.toString();
    }
    
    private void incrementPrimes()
    {
        int newNumber;
        
        newNumber = primes[size - 1] + 1;
        while(!isPrime(newNumber))
            newNumber++;
        insert(newNumber);
    }
    
    private boolean isPrime(int number)
    {
        int primeIndex = 0;
        int integerSqrt;
        int lowerPrime;
        
        integerSqrt = integerSqrt(number);
        lowerPrime = primes[primeIndex];
        while(lowerPrime <= integerSqrt)
        {
            if(number % lowerPrime == 0)
                return false;
            lowerPrime = primes[++primeIndex];
        }
        return true;
    }
    
    private void insert(int prime)
    {
        if(size == primes.length)
            resize();
        primes[size] = prime;
        secondToLastPrime = lastPrime;
        lastPrime = prime;
        size++;
    }
    
    private void resize()
    {
        int length = primes.length;
        int[] newArray;
        
        newArray = new int[length * 2];
        for(int i = 0; i < length; i++)
            newArray[i] = primes[i];
        primes = newArray;
    }
    
    /**
     * I'm not going to claim to know how this algorithm works, only that it is
     * widely available and efficient for finding primes.
     * Effectively calculates floor(sqrt(n)).
     */
    private int integerSqrt(int number)
    {
        int smallResult;
        int bigResult;
        
        if(number < 2)
            return number;
        smallResult = integerSqrt(number >> 2) << 1;
        bigResult = smallResult + 1;
        if(bigResult * bigResult > number)
            return smallResult;
        return bigResult;
    }
}