/**
 * @author Christian Wendlandt
 * @version 2017.11.22
 * Takes two folders, a backup and a live version, in that order, then generates
 * tables that hold a list of files that need to be removed, added, and replaced
 * in order to update the backup version.
 */

import java.util.TreeSet;
import java.io.File;

public class FileSynchronizer
{
    private HashTable<FileHeader> removeList;
    private HashTable<FileHeader> addList;
    private HashTable<FileHeader> replaceList;
    
    public FileSynchronizer()
    {
        removeList = new HashTable<>();
        addList = new HashTable<>();
        replaceList = new HashTable<>();
    }
    
    /**
     * Searches through a given directory and puts all files inside of a hash
     * table for later comparison along with their paths from the directory.
     * @param backupDirectory The directory to be searched through.
     */
    public void readBackupDirectory(File backupDirectory)
    {
        File[] directory;
        
        directory = backupDirectory.listFiles();
        for(File file : directory)
        {
            if(file.isDirectory())
                readBackupDirectory(file, file.getName());
            else if(file.isFile())
                removeList.insert(new FileHeader(file.getName(),
                        file.lastModified()));
        }
    }
    
    private void readBackupDirectory(File backupDirectory, String prefix)
    {
        File[] directory;
        
        directory = backupDirectory.listFiles();
        for(File file : directory)
        {
            if(file.isDirectory())
                readBackupDirectory(file, prefix + "\\" + file.getName());
            else if(file.isFile())
                removeList.insert(new FileHeader(prefix + "\\" + file.getName(),
                        file.lastModified()));
        }
    }
    
    /**
     * Searches through a directory and compares each file and path to an 
     * already populated list of files and modifies a collection of hash tables
     * representing a list of changes needed to turn the old directory into this
     * one.
     * @param LiveDirectory The new directory to be searched through.
     */
    public void readLiveDirectory(File LiveDirectory)
    {
        File[] directory;
        FileHeader liveFile;
        FileHeader backupFile;
        
        directory = LiveDirectory.listFiles();
        for(File file : directory)
        {
            if(file.isDirectory())
                readLiveDirectory(file, file.getName());
            else if(file.isFile())
            {
                liveFile = new FileHeader(file.getName(), file.lastModified());
                backupFile = removeList.search(liveFile);
                if(backupFile == null)
                    addList.insert(liveFile);
                else
                {
                    removeList.delete(backupFile);
                    if(liveFile.timestamp != backupFile.timestamp)
                         replaceList.insert(liveFile);
                }
            }
        }
    }
    
    private void readLiveDirectory(File LiveDirectory, String prefix)
    {
        File[] directory;
        FileHeader liveFile;
        FileHeader backupFile;
        
        directory = LiveDirectory.listFiles();
        for(File file : directory)
        {
            if(file.isDirectory())
                readLiveDirectory(file, prefix + "\\" + file.getName());
            else if(file.isFile())
            {
                liveFile = new FileHeader(prefix + "\\" + file.getName(),
                        file.lastModified());
                backupFile = removeList.search(liveFile);
                if(backupFile == null)
                    addList.insert(liveFile);
                else
                {
                    removeList.delete(backupFile);
                    if(liveFile.timestamp > backupFile.timestamp)
                         replaceList.insert(backupFile);
                }
            }
        }
    }
    
    /**
     * Lists all changes that need to be made to bring the backup directory up
     * to speed with the live directory.
     */
    public void printOut()
    {
        printList(replaceList, "REPLACE");
        printList(addList, "ADD");
        printList(removeList, "REMOVE");
    }
    
    private void printList(HashTable<FileHeader> list, String header)
    {
        TreeSet<FileHeader> orderedSet = new TreeSet<>();
        
        System.out.print(header);
        if(list.isEmpty())
            System.out.print(" none");
        System.out.println();
        orderedSet.addAll(list.exportCollection());
        for(FileHeader fileHeader : orderedSet)
            System.out.println(fileHeader.fileName);
    }
}
