/**
 * @author Christian Wendlandt
 * @version 2017.11.22
 * Implementation of a hash table. Suitable for fast setting and getting within
 * a collection but is, unfortunately, unable to sort.
 */

import java.util.ArrayList;

public class HashTable<T>
{
    private Bucket[] table;
    private PrimesCache primes;
    private final double LOAD_FACTOR_THRESHOLD = .5;//always > 0 and < 1
    private int tableUsage;
    private int size;
    
    private class Bucket<T>
    {
        T element;
        boolean isFull;
        
        Bucket(T element)
        {
            this.element = element;
            isFull = true;
        }
    }
    
    public HashTable()
    {
        this(7);
    }
    
    
    public HashTable(int capacity)
    {
        primes = new PrimesCache();
        primes.updateCache(capacity);
        table = new Bucket[primes.getLastPrime()];
        tableUsage = size = 0;
    }
    
    /**
     * Inserts an element into pseudo-random location of the table array by
     * using the element's hashcode. Resolves collision with rehashing.
     * @param element The element to be inserted. Always make sure the element's
     * hashcode method is overridden.
     */
    public void insert(T element)
    {
        int key;
        Bucket bucket;
        int iterationCounter = 0;
        
        key = hash(element);
        bucket = table[key];
        while(bucket != null && bucket.isFull)
        {
            key = rehash(element, ++iterationCounter);
            bucket = table[key];
        }
        if(bucket == null)
            tableUsage++;
        table[key] = new Bucket(element);
        size++;
        if((double)tableUsage / table.length > LOAD_FACTOR_THRESHOLD)
            resize();
    }
    
    /**
     * Finds and deletes and element from the table by using it's hashcode.
     * @param element The element to be deleted.
     * @return The element that was deleted, or null if it was not found.
     */
    public T delete(T element)
    {
        int key;
        Bucket bucket;
        int iterationCounter = 0;
        
        key = hash(element);
        bucket = table[key];
        while(bucket != null)
        {
            if(bucket.isFull && bucket.element.equals(element))
            {
                bucket.isFull = false;
                size--;
                return (T)bucket.element;
            }
            key = rehash(element, ++iterationCounter);
            bucket = table[key];
        }
        return null;
    }
    
    /**
     * Finds and returns an element of the table0
     * @param element The element to be searched for.
     * @return The element if it is found, otherwise null;
     */
    public T search(T element)
    {
        int key;
        Bucket bucket;
        int iterationCounter = 0;
        
        key = hash(element);
        bucket = table[key];
        while(bucket != null)
        {
            if(bucket.isFull && bucket.element.equals(element))
                return (T)bucket.element;
            key = rehash(element, ++iterationCounter);
            bucket = table[key];
        }
        return null;
    }
    
    /**
     * Checks to see if the hash table is has not elements in it.
     * @return True if the table is empty, false if it is not.
     */
    public boolean isEmpty()
    {
        return size == 0;
    }
    
    /**
     * Prints the tables data fields to the standard input. Lists tables
     * capacity, number of elements it contains, and the number of buckets in
     * use. A bucket will remain "in use" if its element has been deleted, and
     * will only be cleared during a resize or clear. Also prints the contents
     * of every bucket in the table.
     */
    public void printOut()
    {
        System.out.printf("Capacity: %d, Size: %d, Table Usage: %d\n",
                table.length, size, tableUsage);
        for(Bucket bucket : table)
        {
            if(bucket == null)
                System.out.println("[empty]");
            else if(bucket.isFull)
                System.out.printf("[%s]\n", bucket.element.toString());
            else
                System.out.println("[deleted]");
        }
    }
    
    /**
     * Sets all buckets in the table to empty. Will not reduce the table's
     * capacity.
     */
    public void clear()
    {
        table = new Bucket[table.length];
        tableUsage = size = 0;
    }
    
    /**
     * Since the contents of the table are ideally sparse, this groups all of
     * the elements into an easily readable list, the returns that list.
     * @return An unsorted collection of every element of the table.
     */
    public ArrayList<T> exportCollection()
    {
        ArrayList<T> list = new ArrayList<>();
        
        for(Bucket bucket : table)
            if(bucket != null && bucket.isFull)
                list.add((T)bucket.element);
        return list;
    }
            
    private void resize()
    {
        Bucket[] tempTable = table;
        
        primes.updateCache(2 * table.length);
        table = new Bucket[primes.getLastPrime()];
        tableUsage = size = 0;
        for(Bucket bucket : tempTable)
            if(bucket != null && bucket.isFull)
                insert((T)bucket.element);
    }
    
    private int hash(T element)
    {
        return (element.hashCode() & 0x7fffffff) % table.length;
    }
    
    /**
     * I modified the provided hashing algorithm because it failed to use the
     * current iteration as part of the calculation.
     */
    private int rehash(T element, int iteration)
    {
        int largestPrime;
        int hashcode;
        
        largestPrime = primes.getSecondToLastPrime();
        hashcode = element.hashCode() * iteration & 0x7fffffff;
        return largestPrime - hashcode % largestPrime;
    }
}