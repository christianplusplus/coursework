@author Christian Wendlandt
@version 2017.11.22

Description: Takes two folders, a backup and a live version, in that order, then
generates tables that hold a list of files that need to be removed, added, and
replaced in order to update the backup version.

The Driver uses directories that are stored in backup.txt. Edit that to select
your directories. Otherwise you can forward your file paths directly to the
FileSynchronizer methods and it will accomplish the same thing.

public void readBackupDirectory(File backupDirectory)

Searches through a given directory and puts all files inside of a hash
table for later comparison along with their paths from the directory.
@param backupDirectory The directory to be searched through.

public void readLiveDirectory(File LiveDirectory)

Searches through a directory and compares each file and path to an 
already populated list of files and modifies a collection of hash tables
representing a list of changes needed to turn the old directory into this one.
@param LiveDirectory The new directory to be searched through.

public void printOut()

Lists all changes that need to be made to bring the backup directory up to speed
with the live directory. Prints to the standard console output.