/**
 * @author Christian Wendlandt
 * @version 2017.11.28
 */

public class Driver
{
    public static void main(String[] args)
    {
        Graph graph = new Graph(true);
        
        graph.insertVertex("a");
        graph.insertVertex("b");
        graph.insertVertex("c");
        graph.insertVertex("d");
        graph.insertVertex("e");
        graph.insertVertex("f");
        graph.insertVertex("g");
        graph.insertEdge("a", "b");
        graph.insertEdge("a", "f");
        graph.insertEdge("b", "c");
        graph.insertEdge("c", "e");
        graph.insertEdge("d", "a");
        graph.insertEdge("d", "b");
        graph.insertEdge("f", "e");
        
        graph.insertEdge("c", "d");
        graph.print();
        
        graph.removeEdge("d", "b");
        graph.print();
        
        graph.insertVertex("g");
        graph.insertEdge("e", "g");
        graph.insertEdge("f", "g");
        graph.print();
        
        System.out.println(graph.BFS("b"));
        System.out.println(graph.DFS("b"));
        
        System.out.println(graph.BFS("f"));
        System.out.println(graph.DFS("f"));
        
        System.out.println(graph.BFS("g"));
    }
}
