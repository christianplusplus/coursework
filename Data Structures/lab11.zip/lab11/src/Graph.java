/**
 * @author Christian Wendlandt
 * @version 2017.11.28
 */

import java.util.HashMap;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Stack;

public class Graph
{
    private final boolean isDirected;
    private final HashMap<Integer, Vertex> vertices;
    private final ArrayList<Edge> edges;
    //edges just here for bookkeeping. vertices know their own edges.
    
    Graph(boolean isDirected)
    {
        this.isDirected = isDirected;
        vertices = new HashMap<>();
        edges = new ArrayList<>();
    }
    
    public boolean isDirected()
    {
        return isDirected;
    }
    
    public int vertexCount()
    {
        return vertices.size();
    }
    
    public int edgeCount()
    {
        return edges.size();
    }
    
    public void insertVertex(String label)
    {
        Vertex vertex = new Vertex(label);
        
        if(vertices.containsValue(vertex))
            return;
        vertices.put(vertex.hashCode(), vertex);
    }
    
    public void insertEdge(String originLabel, String destinationLabel)
    {
        insertEdge(originLabel, destinationLabel, 1);
    }
    
    public void insertEdge(String originLabel, String destinationLabel,
            double weight)
    {
        Vertex origin;
        Vertex destination;
        Edge edge;
        
        //construct the edge.
        origin = vertices.get((new Vertex(originLabel)).hashCode());
        destination = vertices.get((new Vertex(destinationLabel)).hashCode());
        edge = new Edge(origin, destination, weight);
        
        //place the edge
        origin.addNeighbor(destination);
        edges.add(edge);
        if(!isDirected)
        {
            destination.addNeighbor(origin);
            edges.add(new Edge(destination, origin, weight));
        }
    }
    
    public void removeVertex(String label)
    {
        Vertex vertex;
        ArrayList<Edge> found = new ArrayList<>();
        
        //gets the vertex by presenting a hashclone of the desired vertex.
        vertex = vertices.get((new Vertex(label)).hashCode());
        
        //guard statement.
        if(vertex == null)
            return;
        
        //deletes the vertex.
        vertices.remove(vertex.hashCode(), vertex);
        vertex.deleteAllNeighbors();
        
        //Removes edges in bookkeeping list.
        for(Edge edge : edges)
            if(edge.origin.equals(vertex) || edge.destination.equals(vertex))
                found.add(edge);
        edges.removeAll(found);
        
    }
    
    public void removeEdge(String originLabel, String destinationLabel)
    {
        Vertex origin;
        Vertex destination;
        Edge edgeToDelete;
        Edge oppositeEdgeToDelete;
        
        //grabs orgin and destination by presenting hashclones.
        origin = vertices.get((new Vertex(originLabel)).hashCode());
        destination = vertices.get((new Vertex(destinationLabel)).hashCode());
        
        //this is a hashclone of the edge we want to delete.
        edgeToDelete = new Edge(origin, destination, 1);
        
        //guard statement.
        if(!edges.contains(edgeToDelete))
            return;
        
        //deletes the edge.
        origin.deleteNeighbor(destination);
        for(Edge edge : edges)
            if(edge.equals(edgeToDelete))
            {
                edges.remove(edge);
                break;
            }
        if(!isDirected)
        {
            destination.deleteNeighbor(origin);
            oppositeEdgeToDelete = new Edge(destination, origin, 1);
            for(Edge edge : edges)
            if(edge.equals(oppositeEdgeToDelete))
            {
                edges.remove(edge);
                break;
            }
        }
    }
    
    public boolean containsVertex(String label)
    {
        return vertices.containsValue(new Vertex(label));
    }
    
    public boolean containsEdge(String originLabel, String destinationLabel)
    {
        Vertex origin;
        Vertex destination;
        
        //presents a hashclone to check.
        origin = vertices.get((new Vertex(originLabel)).hashCode());
        destination = vertices.get((new Vertex(destinationLabel)).hashCode());
        return edges.contains(new Edge(origin, destination, 1));
    }
    
    public ArrayList<Vertex> BFS(String label)
    {
        ArrayList<Vertex> searchList = new ArrayList<>();
        LinkedList<Vertex> queue = new LinkedList<>();
        HashMap<Integer, Vertex> discovered = new HashMap<>();
        Vertex vertex;
        
        vertex = vertices.get((new Vertex(label)).hashCode());
        queue.offer(vertex);
        discovered.put(vertex.hashCode(), vertex);
        while(!queue.isEmpty())
        {
            vertex = queue.poll();
            searchList.add(vertex);
            for(Object edge : vertex.outgoingNeighbors())
                if(!discovered.containsValue(((Edge)edge).destination))
                {
                    queue.offer(((Edge)edge).destination);
                    discovered.put((((Edge)edge).destination).hashCode(),
                            ((Edge)edge).destination);
                }
        }
        return searchList;
    }
    
    public ArrayList<Vertex> DFS(String label)
    {
        ArrayList<Vertex> searchList = new ArrayList<>();
        Stack<Vertex> stack = new Stack<>();
        HashMap<Integer, Vertex> discovered = new HashMap<>();
        Vertex vertex;
        
        vertex = vertices.get((new Vertex(label)).hashCode());
        stack.push(vertex);
        while(!stack.isEmpty())
        {
            vertex = stack.pop();
            searchList.add(vertex);
            if(!discovered.containsValue(vertex))
            {
                discovered.put(vertex.hashCode(), vertex);
                for(Object edge : vertex.outgoingNeighbors())
                    if(!discovered.containsValue(((Edge)edge).destination))
                        stack.push(((Edge)edge).destination);
            }
        }
        return searchList;
    }
    
    @Override
    public String toString()
    {
        StringBuilder string = new StringBuilder();
        
        string.append("V={");
        for(Vertex vertex : vertices.values())
        {
            string.append(vertex.getLabel());
            string.append(",");
        }
        string.deleteCharAt(string.length() - 1);//removes trailing comma.
        string.append("} Size=");
        string.append(vertices.size());
        string.append("\n");
        string.append("E={");
        for(Edge edge : edges)
        {
            string.append("(");
            string.append(edge.origin.getLabel());
            string.append(",");
            string.append(edge.destination.getLabel());
            string.append("),");
        }
        string.deleteCharAt(string.length() - 1);//removes trailing comma.
        string.append("} Size=");
        string.append(edges.size());
        return string.toString();
    }
    
    public void print()
    {
        System.out.println(toString());
    }
}
