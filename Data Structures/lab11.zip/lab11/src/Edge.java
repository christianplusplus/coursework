/**
 * @author Christian Wendlandt
 * @version 2017.11.28
 */

public class Edge implements Comparable<Edge>
{
    public final Vertex origin;
    public final Vertex destination;
    public final double weight;
    
    public Edge(Vertex origin, Vertex destination, double weight)
    {
        this.origin = origin;
        this.destination = destination;
        this.weight = weight;
    }
    
    @Override
    public String toString()
    {
        return "{" + origin.toString() + ", " + destination.toString() + ", " +
                Double.toString(weight) + "}";
    }
    
    @Override
    public int compareTo(Edge otherEdge)
    {
        if(weight < otherEdge.weight)
            return -1;
        if(weight > otherEdge.weight)
            return 1;
        return destination.compareTo(otherEdge.destination);
    }
    
    @Override
    public boolean equals(Object otherEdge)
    {
        if(otherEdge instanceof Edge)
        {
            if(origin.equals(((Edge)otherEdge).origin) &&
                    destination.equals(((Edge)otherEdge).destination))
                return true;
        }
        return false;
    }

    @Override
    public int hashCode()
    {
        int hash = 7;
        hash = 11 * hash + origin.hashCode();
        hash = 11 * hash + destination.hashCode();
        return hash;
    }
}
