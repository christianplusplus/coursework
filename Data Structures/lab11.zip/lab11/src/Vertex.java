/**
 * @author Christian Wendlandt
 * @version 2017.11.28
 */

import java.util.ArrayList;
import java.util.TreeSet;

public class Vertex<T> implements Comparable<Vertex>
{
    private String label;
    private T data;
    private final TreeSet<Edge> outgoingEdges;
    private final TreeSet<Edge> incomingEdges;
    
    public Vertex(String label)
    {
        this(label, null);
    }
    
    public Vertex(String label, T data)
    {
        this.label = label;
        this.data = data;
        outgoingEdges = new TreeSet<>();
        incomingEdges = new TreeSet<>();
    }
    
    public void addNeighbor(Vertex neighbor)
    {
        addNeighbor(neighbor, 1);
    }
    
    public void addNeighbor(Vertex neighbor, double weight)
    {
        Edge edge = new Edge(this, neighbor, weight);
        
        outgoingEdges.add(edge);
        neighbor.greetNeighbor(edge);
    }
    
    public void deleteNeighbor(Vertex neighbor)
    {
        for(Edge edge : outgoingEdges)
            if(edge.destination.equals(neighbor))
            {
                outgoingEdges.remove(edge);
                neighbor.forgetNeighbor(edge);
                break;
            }
    }
    
    public void deleteAllNeighbors()
    {
        ArrayList<Edge> foundEdges = new ArrayList<>();
        ArrayList<Vertex> foundVertices = new ArrayList<>();
        
        for(Edge edge : outgoingEdges)
        {
            edge.destination.forgetNeighbor(edge);
            foundEdges.add(edge);
        }
        outgoingEdges.removeAll(foundEdges);
        
        for(Edge edge : incomingEdges)
        {
            foundVertices.add(edge.origin);
        }
        for(Vertex vertex : foundVertices)
            vertex.deleteNeighbor(this);
    }
    
    public int getOutDegree()
    {
        return outgoingEdges.size();
    }
    
    public int getInDegree()
    {
        return incomingEdges.size();
    }
    
    public TreeSet<Edge> incomingNeihgbors()
    {
        return incomingEdges;
    }
    
    public TreeSet<Edge> outgoingNeighbors()
    {
        return outgoingEdges;
    }
    
    public String getLabel()
    {
        return label;
    }
    
    public void setLabel(String label)
    {
        this.label = label;
    }
    
    public T getData()
    {
        return data;
    }
    
    public void setData(T data)
    {
        this.data = data;
    }
    
    @Override
    public String toString()
    {
        if(data != null)
            return "[" + label + ", " + data.toString() + "]";
        return "[" + label + "]";
    }
    
    @Override
    public int compareTo(Vertex otherVertex)
    {
        return label.compareTo(otherVertex.label);
    }
    
    @Override
    public boolean equals(Object otherVertex)
    {
        if(otherVertex instanceof Vertex)
        {
            if(label.equals(((Vertex)otherVertex).label))
                return true;
        }
        return false;
    }

    @Override
    public int hashCode()
    {
        int hash = 3;
        hash = 37 * hash + label.hashCode();
        if(data != null)
            hash = 37 * hash + data.hashCode();
        return hash;
    }
    
    private void greetNeighbor(Edge edge)
    {
        incomingEdges.add(edge);
    }
    
    private void forgetNeighbor(Edge edge)
    {
        incomingEdges.remove(edge);
    }
}
