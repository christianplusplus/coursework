/**
 * @author Christian Wendlandt
 * @version 2017.12.14
 * @description Implementation of a graph ADT. Instantiated either by
 * individually entering vertices and edges, or by a given graph text file.
 * The format of the text file should be as so:
 * Directed=(TRUE|FALSE)
 * Vertex labels on ONE line, each label separated by a comma.
 * Edges composed of FROM, TO, WEIGHT one per line.
 */

import java.util.HashMap;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Stack;
import java.util.PriorityQueue;
import java.util.HashSet;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.File;
import javax.swing.JFileChooser;

public class Graph
{
    private final boolean isDirected;
    private final HashMap<String, Vertex> vertices;
    //key is label
    private final HashMap<Integer, Edge> edges;
    //key is (origin label + destination label).hashCode()
    
    public Graph(boolean isDirected)
    {
        this.isDirected = isDirected;
        vertices = new HashMap<>();
        edges = new HashMap<>();
    }
    
    @SuppressWarnings("OverridableMethodCallInConstructor")
    public Graph(File graphFile)
    {
        Scanner scan = new Scanner(System.in);
        String[] commaSepVertices;
        String[] edge;
        String line = "";
        vertices = new HashMap<>();
        edges = new HashMap<>();
        
        //Begin scanning file.
        try
        {
            scan = new Scanner(graphFile);
            line = scan.nextLine();
        }
        catch(FileNotFoundException | NullPointerException ex)
        {
            System.out.println("Not a valid file.");
            System.out.println(ex);
        }
        
        //Reads directedness.
        if(line.contains("TRUE"))
            isDirected = true;
        else if(line.contains("FALSE"))
            isDirected = false;
        else
            throw new RuntimeException();

        //Reads vertices.
        commaSepVertices = scan.nextLine().split("[\\t ,]+");
        for(String vertex : commaSepVertices)
            insertVertex(vertex);

        //Reads edges. Can add new edges too.
        while(scan.hasNextLine())
        {
            edge = scan.nextLine().split("[\\t ,]+");
            if(!vertices.containsKey(edge[0]))
                insertVertex(edge[0]);
            if(!vertices.containsKey(edge[1]))
                insertVertex(edge[1]);
            insertEdge(edge[0], edge[1], Double.parseDouble(edge[2]));
        }
    }
    
    /**
     * Gets whether or not the graph is directed.
     * @return The state of "directedness".
     */
    public boolean isDirected()
    {
        return isDirected;
    }
    
    /**
     * Gets the number of vertices in the graph.
     * @return The number of vertices.
     */
    public int vertexCount()
    {
        return vertices.size();
    }
    
    /**
     * Gets the number of Edges in the graph.
     * @return The number of Edges.
     */
    public int edgeCount()
    {
        return isDirected ? edges.size() : edges.size() / 2;
    }
    
    /**
     * Adds a vertex to the graph.
     * @param label The name of the vertex. It must be unique.
     */
    public void insertVertex(String label)
    {
        vertices.put(label, new Vertex(label));
    }
    
    /**
     * Adds an edge to graph. Vertices must exist beforehand.
     * If the graph is undirected, a mirror edge will be added as well.
     * @param origin The origin of the edge.
     * @param destination The destination of the edge.
     */
    public void insertEdge(String origin, String destination)
    {
        insertEdge(origin, destination, 1);
    }
    public void insertEdge(String origin, String destination, double weight)
    {
        Vertex originVertex = vertices.get(origin);
        Vertex destinationVertex = vertices.get(destination);
        
        edges.put((origin + destination).hashCode(),
                new Edge(origin, destination, weight));
        originVertex.addOutgoingNeighbor(destination);
        destinationVertex.addIncomingNeighbor(origin);
        if(!isDirected)
        {
            edges.put((destination + origin).hashCode(),
                    new Edge(destination, origin, weight));
            destinationVertex.addOutgoingNeighbor(origin);
            originVertex.addIncomingNeighbor(destination);
        }
    }
    
    /**
     * Removes a vertex from the graph and any edges that were connected to it.
     * @param vertex The vertex to be removed.
     */
    public void removeVertex(String vertex)
    {
        for(Object neighbor : vertices.get(vertex).getOutgoingNeighborsList())
        {
            vertices.get((String)neighbor).deleteIncomingNeighbor(vertex);
            edges.remove((vertex + (String)neighbor).hashCode());
        }
        for(Object neighbor : vertices.get(vertex).getIncomingNeighborsList())
        {
            vertices.get((String)neighbor).deleteOutgoingNeighbor(vertex);
            edges.remove(((String)neighbor + vertex).hashCode());
        }
        vertices.remove(vertex);
    }
    
    /**
     * Removes an edge from the graph. If undirected, will remove the mirror edge
     * as well.
     * @param origin The label of the origin vertex of the edge.
     * @param destination The label of the destination vertex of the edge.
     */
    public void removeEdge(String origin, String destination)
    {
        vertices.get(origin).getOutgoingNeighborsList().remove(destination);
        vertices.get(destination).getIncomingNeighborsList().remove(origin);
        edges.remove((origin + destination).hashCode());
        if(!isDirected)
        {
            vertices.get(destination).getOutgoingNeighborsList().remove(origin);
            vertices.get(origin).getIncomingNeighborsList().remove(destination);
            edges.remove((destination + origin).hashCode());
        }
    }
    
    /**
     * Returns whether or not a vertex is inside of the graph.
     * @param vertex The vertex label to be checked.
     * @return True or false.
     */
    public boolean containsVertex(String vertex)
    {
        return vertices.containsKey(vertex);
    }
    
    /**
     * Returns whether or not a edge is inside of the graph.
     * @param origin The label of the origin vertex of the edge.
     * @param destination The label of the destination vertex of the edge.
     * @return True or false.
     */
    public boolean containsEdge(String origin, String destination)
    {
        return edges.containsKey((origin + destination).hashCode());
    }
    
    /**
     * Implementation of a standard Breath First Search traversal.
     * @param origin Where the search will start.
     * @return An array list of traversed vertices, ordered by range (the ranges are unknown).
     */
    public ArrayList<String> BFS(String origin)
    {
        ArrayList<String> searchList = new ArrayList<>();
        LinkedList<String> queue = new LinkedList<>();
        HashSet<String> discovered = new HashSet<>();
        Vertex vertex;
        
        queue.offer(origin);
        discovered.add(origin);
        while(!queue.isEmpty())
        {
            vertex = vertices.get(queue.poll());
            searchList.add(vertex.label);
            for(Object neighbor : vertex.getOutgoingNeighborsList())
            {
                if(!discovered.contains((String)neighbor))
                {
                    queue.offer((String)neighbor);
                    discovered.add((String)neighbor);
                }
            }
        }
        return searchList;
    }
    
    /**
     * Implementation of a standard Depth First Search. Preference of traversal
     * is somewhat random, since lists are sorted in HashMaps.
     * @param origin Where the search begins.
     * @return An array list of vertex labels in the order they were found.
     */
    public ArrayList<String> DFS(String origin)
    {
        ArrayList<String> searchList = new ArrayList<>();
        Stack<String> stack = new Stack();
        HashSet<String> discovered = new HashSet<>();
        Vertex vertex;
        
        stack.push(origin);
        while(!stack.isEmpty())
        {
            origin = stack.pop();
            if(!discovered.contains(origin))
            {
                vertex = vertices.get(origin);
                searchList.add(vertex.label);
                discovered.add(origin);
                for(Object neighbor : vertex.getOutgoingNeighborsList())
                    if(!discovered.contains((String)neighbor))
                        stack.push((String)neighbor);
            }
        }
        return searchList;
    }
    
    /**
     * Standard implementation of Dyjkstra's Shortest Path algorithm.
     * @param origin Where the algorithm starts.
     * @return Returns an unsorted list of vertices with a predecessor and distance
     * from the origin. To find the path to the origin, just follow the
     * predecessors. Path.java can also do this for you.
     */
    public HashMap<String, PathWrapper> shortestPath(String origin)
    {
        HashMap<String, PathWrapper> pathList = new HashMap<>();
        PriorityQueue<PathWrapper> queue = new PriorityQueue<>();
        HashSet<String> discovered = new HashSet<>();
        PathWrapper currentVertex;
        String neighborLabel;
        
        //Initializing queue, pathList, and starting vertex
        for(Vertex vertex : vertices.values())
            pathList.put(vertex.label,
                    new PathWrapper(null, vertex.label, Double.POSITIVE_INFINITY));
        currentVertex = pathList.get(origin);
        currentVertex.distance = 0;
        queue.offer(currentVertex);
        
        //While all vertices have not been visited
        while(!queue.isEmpty())
        {
            //V <- Dequeue Q where V is the vertex with the smallest distance
            currentVertex = queue.poll();
            
            //Set visited flag for V to true
            discovered.add(currentVertex.vertex);
            
            //For each neighbor U of V
            for(Object neighbor : vertices.get(currentVertex.vertex).getOutgoingNeighborsList())
            {
                //If U is not visited
                neighborLabel = (String)neighbor;
                if(!discovered.contains(neighborLabel))
                {
                    //Set distance[U] to MIN(distance[U],distance[V]+cost(V,U))
                    if(pathList.get(currentVertex.vertex).distance +
                            edges.get((currentVertex.vertex + neighborLabel).hashCode()).weight <
                            pathList.get(neighborLabel).distance)
                    {
                        pathList.get(neighborLabel).distance =
                                pathList.get(currentVertex.vertex).distance +
                                edges.get((currentVertex.vertex + neighborLabel).hashCode()).weight;
                        
                        //Update pred[U] to V if distance[U] changed
                        pathList.get(neighborLabel).predecessor = currentVertex.vertex;
                        
                        //Enqueue (U, distance[U]) into Q if distance[U] changed
                        queue.offer(pathList.get(neighborLabel));
                    }
                }
            }
        }
        return pathList;
    }
    
    /**
     * Standard implementation of Prim's minimal spanning tree algorithm.
     * @param root Where the algorithm starts.
     * @return The minimal spanning tree as another graph object.
     * Does not specify the root.
     */
    public Graph PrimsMinimalSpanningTree(String root)
    {
        Graph mst = new Graph(isDirected);
        HashMap<String, PathWrapper> pathList = new HashMap<>();
        PriorityQueue<PathWrapper> queue = new PriorityQueue<>();
        HashSet<String> discovered = new HashSet<>();
        PathWrapper currentVertex;
        String neighborLabel;
        
        //Initializing queue, pathList, and starting vertex
        for(Vertex vertex : vertices.values())
            pathList.put(vertex.label,
                    new PathWrapper(null, vertex.label, Double.POSITIVE_INFINITY));
        currentVertex = pathList.get(root);
        currentVertex.distance = 0;
        queue.offer(currentVertex);
        
        //While all vertices have not been visited
        while(!queue.isEmpty())
        {
            //V <- Dequeue Q where V is the vertex with the smallest distance
            currentVertex = queue.poll();
            
            //Set visited flag for V to true
            discovered.add(currentVertex.vertex);
            
            //For each neighbor U of V
            for(Object neighbor : vertices.get(currentVertex.vertex).getOutgoingNeighborsList())
            {
                //If U is not visited
                neighborLabel = (String)neighbor;
                if(!discovered.contains(neighborLabel))
                {
                    //Set distance[U] to MIN(distance[U],cost(V,U))
                    if(edges.get((currentVertex.vertex + neighborLabel).hashCode()).weight <
                            pathList.get(neighborLabel).distance)
                    {
                        pathList.get(neighborLabel).distance =
                                edges.get((currentVertex.vertex + neighborLabel).hashCode()).weight;
                        //Update pred[U] to V if distance[U] changed
                        pathList.get(neighborLabel).predecessor = currentVertex.vertex;
                        //Enqueue (U, distance[U]) into Q if distance[U] changed
                        queue.offer(pathList.get(neighborLabel));
                    }
                }
            }
        }
        
        //Converts the path list into a new graph/tree
        for(String destination : pathList.keySet())
        {
            PathWrapper path = pathList.get(destination);
            if(path.predecessor != null)
            {
                if(!mst.containsVertex(path.predecessor))
                    mst.insertVertex(path.predecessor);
                if(!mst.containsVertex(destination))
                    mst.insertVertex(destination);
                mst.insertEdge(path.predecessor, destination, path.distance);
            }
        }
        return mst;
    }
    
    /**
     * Calculates the cost of a tree graph based on Dyjkstra's shortest path
     * algorithm. For rooted trees, Dyjkstra's is fast.
     * @param root Where cost is calculated from. Cost of node increases
     * proportional to its distance from the root.
     * @return The cost of the tree.
     */
    public double TreeCost(String root)
    {
        HashMap<String, PathWrapper> pathList = shortestPath(root);
        double sum = 0;
        
        for(PathWrapper path : pathList.values())
            sum += path.distance;
        return sum;
    }
    
    /**
     * Creates a topologically sorted list of this graphs vertices. The graph
     * MUST be acyclic for this to work.
     * @return The array list of vertex labels in a topological order.
     * @throws NonAcyclicGraphException 
     */
    public ArrayList<String> topologicalSort() throws NonAcyclicGraphException
    {
        ArrayList<String> list = new ArrayList<>();
        HashMap<String, IndegreeWrapper> vertexList = new HashMap<>();
        String currentVertex = "";
        
        //Stores all vertices and there indegree value onto a list
        //Their indegree value will act as a counter
        for(Vertex vertex : vertices.values())
            vertexList.put(vertex.label,
                    new IndegreeWrapper(vertex.label, vertex.getInDegree()));
        
        //While there are vertices still on the list
        while(!vertexList.isEmpty())
        {
            //Find an arbitrary vertex with an indegree of 0
            for(IndegreeWrapper vertex : vertexList.values())
            {
                currentVertex = vertex.label;
                if(vertex.indegree == 0)
                    break;
            }
            
            //If we did not find a vertex with an indegree of 0
            if(vertexList.get(currentVertex).indegree != 0)
                //If you get here, then the graph is not acyclic.
                throw new NonAcyclicGraphException();
            
            //For each neighbor U of V decrement their indegree counter
            for(Object neighbor : vertices.get(currentVertex).getOutgoingNeighborsList())
                vertexList.get((String)neighbor).indegree -= 1;
            
            //Add V to the output
            list.add(currentVertex);
            
            //Remove V from the indegree couting list
            vertexList.remove(currentVertex);
        }
        return list;
    }
    
    @Override
    public String toString()
    {
        StringBuilder string = new StringBuilder();
        HashSet<Integer> edgeTracker = new HashSet<>();
        String edgeString;
        int breakCounter = 0;
        
        //Append the vertices
        string.append("V={");
        for(String label : vertices.keySet())
        {
            if(breakCounter > 70)
            {
                string.append("\n   ");
                breakCounter = 0;
            }
            string.append(label);
            string.append(',');
            breakCounter += label.length() + 1;
        }
        if(!vertices.isEmpty())
            string.deleteCharAt(string.length() - 1);//removes trailing commas.
        
        //Append the edges
        breakCounter = 0;
        string.append("}\nE={");
        for(Edge edge : edges.values())
        {
            //So that I'm not printing mirrored edges of an undirected graph.
            if(!isDirected)
            {
                if(edgeTracker.contains(edge.hashCode()))
                    continue;
                edgeTracker.add(edge.hashCode());
                edgeTracker.add((edge.destination + edge.origin).hashCode());
            }
            
            if(breakCounter > 70)
            {
                string.append("\n   ");
                breakCounter = 0;
            }
            edgeString = edge.toString();
            string.append(edgeString);
            string.append(',');
            breakCounter += edgeString.length() + 1;
        }
        if(!edges.isEmpty())
            string.deleteCharAt(string.length() - 1);//removes trailing commas.
        string.append('}');
        
        return string.toString();
    }
    
    /**
     * Simply prints the toString() method to the console.
     */
    public void print()
    {
        System.out.println(toString());
    }
    
    ////////////////////////////////////////////////////////////////////////////
    
    //For testing. G1.txt remains available for testing.
    public static void main(String[] args)
    {
        Graph g = new Graph(chooseFile());
        Graph mst;
        String testOrigin = "1";
        
        g.print();
        System.out.println();
        //*
        System.out.println("Shortest paths from " + testOrigin + ":");
        HashMap<String, PathWrapper> pathList = g.shortestPath(testOrigin);
        for(String destination : pathList.keySet())
            System.out.println(new Path(pathList, destination));
        System.out.println();
        //*/
        //*
        System.out.println("Graph as a minimal spanning tree.");
        mst = g.PrimsMinimalSpanningTree(testOrigin);
        mst.print();
        System.out.println("Cost: " + mst.TreeCost(testOrigin));
        System.out.println();
        //*/
        //*
        try
        {
            //For the test file G1.txt, we must remove these edges to make it acyclic.
            //*
            g.removeEdge("9", "1");
            g.removeEdge("3", "2");
            //*/
            ArrayList<String> list = g.topologicalSort();
            System.out.println("Topologically sorted with (9,1) and (3,2) removed.");
            System.out.println(list);
        }
        catch(NonAcyclicGraphException ex)
        {
            System.out.println("Graph must be acyclic to sort topologically.");
        }
        //*/
    }
    
    private static File chooseFile()
    {
        File file;
        
        JFileChooser chooser = new JFileChooser();
        if(chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
            file = chooser.getSelectedFile();
        else
            file = null;
        return file;
    }
}
