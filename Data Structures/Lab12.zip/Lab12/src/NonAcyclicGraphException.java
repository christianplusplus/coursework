/**
 * @author Christian Wendlandt
 * @version 2017.12.14
 */
class NonAcyclicGraphException extends Exception
{
    NonAcyclicGraphException(){}
    
    public NonAcyclicGraphException(String message)
    {
        super(message);
    }
}
