/**
 * @author Christian Wendlandt
 * @version 2017.12.14
 * @description Given a path list (a hashMap with vertex labels as keys and
 * PathWrappers as values), this object analyzes and stores paths to the
 * vertices of a graph. Directions are stored as a linked list and total
 * distance is stored separately as a number.
 */

import java.util.LinkedList;
import java.util.HashMap;

public class Path
{
    public final LinkedList<String> directions;
    public final double distance;
    
    public Path(HashMap<String, PathWrapper> pathList, String destination)
    {
        directions = new LinkedList<>();
        this.distance = pathList.get(destination).distance;
        String predecessor;
        
        predecessor = destination;
        do
        {
            directions.offerFirst(predecessor);
            predecessor = pathList.get(predecessor).predecessor;
        }while(predecessor != null);
    }
    
    @Override
    public String toString()
    {
        StringBuilder string = new StringBuilder();
        
        for(String node : directions)
        {
            string.append(node);
            string.append("->");
        }
        string.delete(string.length() - 2, string.length());
        if(distance == Double.POSITIVE_INFINITY)
            string.append(" . . . No path.");
        else
        {
            string.append("; Distance: ");
            string.append(distance);
        }
        return string.toString();
    }
}