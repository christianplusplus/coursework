/**
 * @author Christian Wendlandt
 * @version 2017.12.14
 * @description PathWrapper is used to store graph path data efficiently. Each
 * path list contains the final vertex, the preceding vertex, and the total path
 * distance. By following the preceding vertices of all PathWrapers in a graph
 * to the origin, we can find the absolute path to the vertex. Use the
 * Path.java object to do this automatically.
 */

public class PathWrapper implements Comparable<PathWrapper>
{
    public String predecessor;
    public final String vertex;
    public double distance;
    
    PathWrapper(String predecessor, String vertex, double distance)
    {
        this.predecessor = predecessor;
        this.vertex = vertex;
        this.distance = distance;
    }
    
    @Override
    public String toString()
    {
        return "(" + predecessor + "," + vertex + "," +
                Double.toString(distance) + ")";
    }
    
    @Override
    public int compareTo(PathWrapper otherPath)
    {
        if(distance < otherPath.distance)
            return -1;
        if(distance > otherPath.distance)
            return 1;
        return 0;
    }
    
    @Override
    public int hashCode()
    {
        return vertex.hashCode();
    }

    @Override
    public boolean equals(Object otherPath)
    {
        if(otherPath instanceof PathWrapper)
            return vertex.equals(((PathWrapper)otherPath).vertex);
        return false;
    }
}
