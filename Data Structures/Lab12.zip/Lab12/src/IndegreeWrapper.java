/**
 * @author Christian Wendlandt
 * @version 2017.12.14
 */

class IndegreeWrapper implements Comparable<IndegreeWrapper>
{
    public String label;
    public int indegree;
    
    public IndegreeWrapper(String label, int indegree)
    {
        this.label = label;
        this.indegree = indegree;
    }
    
    @Override
    public String toString()
    {
        return "(" + label + "," + Integer.toString(indegree) + ")";
    }
    
    @Override
    public int compareTo(IndegreeWrapper otherWrapper)
    {
        if(indegree < otherWrapper.indegree)
            return -1;
        if(indegree > otherWrapper.indegree)
            return 1;
        return 0;
    }
    
    @Override
    public int hashCode()
    {
        return label.hashCode();
    }

    @Override
    public boolean equals(Object otherPath)
    {
        if(otherPath instanceof PathWrapper)
            return label.equals(((PathWrapper)otherPath).vertex);
        return false;
    }
}
