/**
 * @author Christian Wendlandt
 * @version 2017.12.14
 */

class Edge implements Comparable<Edge>
{
    public final String origin;
    public final String destination;
    public final double weight;
    
    public Edge(String origin, String destination, double weight)
    {
        this.origin = origin;
        this.destination = destination;
        this.weight = weight;
    }
    
    @Override
    public String toString()
    {
        return "(" + origin + "," + destination + "," +
                Double.toString(weight) + ")";
    }
    
    @Override
    public int compareTo(Edge otherEdge)
    {
        if(weight < otherEdge.weight)
            return -1;
        if(weight > otherEdge.weight)
            return 1;
        return destination.compareTo(otherEdge.destination);
    }
    
    @Override
    public boolean equals(Object otherEdge)
    {
        if(otherEdge instanceof Edge)
            return origin.equals(((Edge)otherEdge).origin) &&
                    destination.equals(((Edge)otherEdge).destination);
        return false;
    }

    @Override
    public int hashCode()
    {
        return (origin + destination).hashCode();
    }
}
