package lab1;

/**
 * @author Christian Wendlandt
 * @version 9/7/17
 */
import java.util.*;
public class DayOfTheWeek
{
    public static void main(String[] args)
    {
        Calendar calendar;
        String input;
        String dayOfTheWeekString;
        String gregDayOfTheWeekString;
        int gregDayOfTheWeekInt;
        int month;
        int adjustedMonth;
        int day;
        int year;
        int adjustedYear;
        int dayOfTheWeekInt;
        int algorithmicSum;
        
        input = inputDate();
        month = getMonth(input);
        day = getDay(input);
        year = getYear(input);
        
        adjustedMonth = adjustMonth(month);
        adjustedYear = year - 1900;
        algorithmicSum = adjustedMonth + day + adjustedYear + adjustedYear / 4;
        dayOfTheWeekInt = algorithmicSum % 7;
        dayOfTheWeekString = dayFromIntToString(dayOfTheWeekInt);
        
        System.out.println(dayOfTheWeekString);
        
        System.out.println("compared the the Gregorian Calender");
        calendar = new GregorianCalendar(year, month - 1, day);
        gregDayOfTheWeekInt = calendar.get(Calendar.DAY_OF_WEEK);
        gregDayOfTheWeekString = gregDayFromIntToString(gregDayOfTheWeekInt);
        System.out.println(gregDayOfTheWeekString);
    }
    
    private static String inputDate()
    {
        String date;
        int first = 0;
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Enter a date in the format mm-dd-yyyy");
        
        do
        {
            if(first++ != 0)
                System.out.println("Not a date. Try again.");
            date = scan.nextLine();
        }while(!stringIsADate(date));
        
        return date;
    }
    
    private static boolean stringIsADate(String date)
    {
        String stringToCheck;
        int index;
        
        index = date.indexOf("-");
        if(index == -1)
            return false;
        stringToCheck = date.substring(0, index);
        if(!stringIsAnInteger(stringToCheck))
            return false;
        date = date.substring(index + 1);
        
        index = date.indexOf("-");
        if(index == -1)
            return false;
        stringToCheck = date.substring(0, index);
        if(!stringIsAnInteger(stringToCheck))
            return false;
        date = date.substring(index + 1);
        
        if(!stringIsAnInteger(date))
            return false;
        
        return true;
    }
    
    private static boolean stringIsAnInteger(String stringToCheck)
    {
        for(int i = 0; i < stringToCheck.length(); i++)
        {
            if(!Character.isDigit(stringToCheck.charAt(i)))
                return false;
        }
        
        return true;
    }
    
    private static int getMonth(String date)
    {
        int month;
        int indexOfFirstDash;
        
        indexOfFirstDash = date.indexOf("-");
        date = date.substring(0, indexOfFirstDash);
        month = Integer.parseInt(date);
        
        return month;
    }
    
    private static int getDay(String date)
    {
        int day;
        int indexOfFirstDash;
        int indexOfLastDash;
        
        indexOfFirstDash = date.indexOf("-");
        indexOfLastDash = date.lastIndexOf("-");
        date = date.substring(indexOfFirstDash + 1, indexOfLastDash);
        day = Integer.parseInt(date);
        
        return day;
    }
    
    private static int getYear(String date)
    {
        int year;
        int indexOfLastDash;
        
        indexOfLastDash = date.lastIndexOf("-");
        date = date.substring(indexOfLastDash + 1);
        year = Integer.parseInt(date);
        
        return year;
    }
    
    private static int adjustMonth(int month)
    {
        switch(month)
        {
            case 1:
                return 1;
            case 2:
                return 4;
            case 3:
                return 4;
            case 4:
                return 0;
            case 5:
                return 2;
            case 6:
                return 5;
            case 7:
                return 0;
            case 8:
                return 3;
            case 9:
                return 6;
            case 10:
                return 1;
            case 11:
                return 4;
            case 12:
                return 6;
            default:
                return -1;
        }
    }
    
    private static String dayFromIntToString(int dayOfTheWeekInt)
    {
        switch(dayOfTheWeekInt)
        {
            case 0:
                return "Saturday";
            case 1:
                return "Sunday";
            case 2:
                return "Monday";
            case 3:
                return "Tuesday";
            case 4:
                return "Wednesday";
            case 5:
                return "Thursday";
            case 6:
                return "Friday";
            default:
                return "Error";
        }
    }
    
    private static String gregDayFromIntToString(int dayOfTheWeekInt)
    {
        switch(dayOfTheWeekInt)
        {
            case 1:
                return "Sunday";
            case 2:
                return "Monday";
            case 3:
                return "Tuesday";
            case 4:
                return "Wednesday";
            case 5:
                return "Thursday";
            case 6:
                return "Friday";
            case 7:
                return "Saturday";
            default:
                return "Error";
        }
    }
}
