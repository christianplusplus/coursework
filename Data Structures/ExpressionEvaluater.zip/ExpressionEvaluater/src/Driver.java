/**
 * @author Christian Wendlandt
 * @version 10/12/17
 * @Driver
 * A driver for running the StatementEvaluator. Shown here is the simplest way
 * to implement the class. Line breaks automatically.
 */

import java.util.Scanner;

public class Driver
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        StatementEvaluator se = new StatementEvaluator();
        while(true)
            System.out.print(se.parse(scan.nextLine()));
    }
}
