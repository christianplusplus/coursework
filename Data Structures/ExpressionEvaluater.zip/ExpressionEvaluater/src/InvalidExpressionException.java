import java.util.ArrayList;

/**
 * @author Christian Wendlandt
 * @version 10/12/17
 * @InvalidExpressionException
 * An exception for bad infix expressions. Allows the implementation of more
 * complex error messages if desired.
 */
public class InvalidExpressionException extends Exception
{
    String message;
    
    InvalidExpressionException()
    {
        message = "Error: Invalid expression.";
    }
    
    InvalidExpressionException(ArrayList<String> expression)
    {
        message = "Error: " + expression.toString() +
                " is not a valid expression.";
    }
    
    @Override
    public String toString()
    {
        return message;
    }
}
