/**
 * @author Christian Wendlandt
 * @version 10/12/17
 * @InvalidVariableException
 * An exception for bad variable names and assignments.
 */
public class InvalidVariableException extends Exception
{
    String message;
    
    InvalidVariableException()
    {
        message = "Error: Invalid variable name.";
    }
    
    InvalidVariableException(String variable)
    {
        message = "Error: " + variable + " isn't a valid variable name.";
    }
    
    InvalidVariableException(String variable, String value)
    {
        message = "Error: " + variable + " can't be assigned to " + value + ".";
    }
    
    @Override
    public String toString()
    {
        return message;
    }
}
