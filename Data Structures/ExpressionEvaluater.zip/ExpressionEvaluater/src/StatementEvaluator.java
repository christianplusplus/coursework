/**
 * @author Christian Wendlandt
 * @version 10/16/17
 * @StatementEvaluator
 * Takes and stores expressions and variables, then evaluates them. All
 * functionality can be accessed through the parse() function.
 */

import java.util.*;

public class StatementEvaluator
{
    ArrayList<String> expression;
    Map<String, Double> variableList;
    
    StatementEvaluator()
    {
        expression = new ArrayList<>();
        variableList = new HashMap<>();
    }
    
    /**
     * Functions similarly to a command line. Performs actions based on the type
     * of command it is given. "clear" clears all variables. Anything with an
     * "=" sign is an assignment to a variable (see assign()). Anything else is
     * taken as an expression and the method will attempt to return a result.
     * @param statement A command given to the evaluator.
     * @return String Reserved for error messages or the result of evaluations.
     * Is an empty string if nothing need be returned.
     */
    public String parse(String statement)
    {
        if(statement.equals("clear"))
        {
            clear();
            return "All variables cleard.\n";
        }
        else if(statement.contains("="))
            return parseAssignment(statement);
        else
        {
            parseExpression(statement);
            return evaluateExpression();
        }
    }
    
    /**
     * Clears all stored variables.
     */
    public void clear()
    {
        variableList.clear();
    }
    
    /**
     * Parses an assignment statement. The token on the left-hand side becomes
     * the variable name. If the right-hand side of the statement is a number,
     * the token will be assigned as a double. If the right-hand side is an
     * already existing variable, the left-hand variable will be assigned to
     * the value of the right-hand variable.
     * @param assignment The string to be parsed as an assignment statement.
     * @return String Usually returns an empty string, or an error message if
     * necessary.
     */
    public String parseAssignment(String assignment)
    {
        String variable;
        String valueString;
        int delimiterIndex = assignment.indexOf('=');
        
        variable = assignment.substring(0, delimiterIndex);
        variable = variable.trim();
        valueString = assignment.substring(delimiterIndex + 1);
        valueString = valueString.trim();
        return assign(variable, valueString);
    }
    
    /**
     * Assigns values to variable names in the variableList Map.
     * @param variable Name of the variable. Must be a valid alphabetic name.
     * Ranges of valid variable names can be expanded on (see isVariableName()).
     * @param stringValue String that is either a parsable double, or a
     * preexisting variable name.
     * @return String Either an empty string or an error message.
     */
    public String assign(String variable, String stringValue)
    {
        double value;
        
        try
        {
            if(!isVariableName(variable))
                throw new InvalidVariableException(variable);
        }
        catch(InvalidVariableException ex)
        {
            return ex.toString() + "\n";
        }
        if(variableList.containsKey(stringValue))
        {
            variableList.put(variable, variableList.get(stringValue));
            return "";
        }
        try
        {
            try
            {
                value = Double.parseDouble(stringValue);
                variableList.put(variable, value);
                return "";
            }
            catch(NumberFormatException ex)
            {
                throw new InvalidVariableException(variable, stringValue);
            }
        }
        catch(InvalidVariableException ex)
        {
            return ex.toString() + "\n";
        }
    }
    
    /**
     * Parses a mathematical expression and stores it in an array list. Does
     * not actually check if the expression is a valid infix expression. For
     * that, see evaluateExpression().
     * @param expression An infix expression with tokens such as integers,
     * doubles, +, -, *, /, (, ), and any preexisting variable names.
     */
    public void parseExpression(String expression)
    {
        StringBuilder buffer = new StringBuilder();
        String character;
        
        this.expression.clear();
        for(int i = 0; i < expression.length(); i++)
        {
            character = expression.substring(i, i + 1);
            if(character.matches("\\s"))
                dumpBuffer(buffer);//dumps into the list, but only if not empty.
            else if(isOperator(character) || character.matches("[\\(\\)]"))
            {
                dumpBuffer(buffer);
                this.expression.add(character);
            }
            else
                buffer.append(character);
        }
        dumpBuffer(buffer);
    }
    
    /**
     * Evaluates the expression currently being held in the ArrayList
     * expression. The expression in the array list must be a valid infix
     * expression.
     * @return String Returns either the expression evaluated as a string and
     * rounded to two decimal places, or returns an error message.
     */
    public String evaluateExpression()
    {
        if(!isValidExpression())
            try
            {
                throw new InvalidExpressionException(expression);
            }
            catch(InvalidExpressionException ex)
            {
                return ex.toString();
            }
        return String.format(">>%.2f",
                evaluatePostfixExpression(makePostfixExpression())) + "\n";
    }
    
    @Override
    public String toString()
    {
        StringBuilder string = new StringBuilder();
        
        string.append("Current Exression: ");
        string.append(expression.toString());
        string.append('\n');
        string.append("Expression valid: ");
        string.append(isValidExpression());
        string.append('\n');
        string.append("Current Variables: ");
        string.append(variableList.toString());
        return string.toString();
    }
    
    private boolean isVariableName(String variable)
    {
        return variable.matches("^[A-z]+$");
    }
    
    private boolean isOperator(String character)
    {
        return character.matches("[\\+\\-\\*/]");
    }
    
    private void dumpBuffer(StringBuilder buffer)
    {
        if(buffer.length() > 0)
        {
            expression.add(buffer.toString());
            buffer.setLength(0);//clears the StringBuilder.
        }
    }
    
    private boolean isValidExpression()
    {
        String token;
        int parenthesisCounter = 0;
        
        for(int i = 0; i < expression.size(); i++)
        {
            token = expression.get(i);
            if(!isOperand(token) && !isOperator(token) &&
                    !token.matches("[\\(\\)]"))
                return false;
            if(isOperand(token))
                if(!isOperandInfix(i))
                    return false;
            if(isOperator(token))
                if(!isOperatorInfix(i))
                    return false;
            if(token.equals("("))
                parenthesisCounter++;
            if(token.equals(")"))
                parenthesisCounter--;
            if(parenthesisCounter < 0)
                return false;
        }
        return parenthesisCounter == 0 && expression.size() > 0;
    }
    
    private boolean isOperand(String operand)
    {
        return variableList.containsKey(operand) ||
                operand.matches("-?\\d+(\\.\\d+)?");
    }
     
    private boolean isOperandInfix(int index)
    {
        String leftToken;
        String rightToken;
        
        if(index > 0)
        {
            leftToken = expression.get(index - 1);
            if(leftToken.equals(")") || isOperand(leftToken))
                return false;
        }
        
        if(index < expression.size() - 1)
        {
            rightToken = expression.get(index + 1);
            if(rightToken.equals("(") || isOperand(rightToken))
                return false;
        }
        return true;
    }
     
    private boolean isOperatorInfix(int index)
    {
        String leftToken;
        String rightToken;
        
        if(index <= 0 || index >= expression.size() - 1)
            return false;
        leftToken = expression.get(index - 1);
        rightToken = expression.get(index + 1);
        return leftToken.equals(")") || isOperand(leftToken) &&
                rightToken.equals(")") || isOperand(rightToken);
    }
    
    private ArrayList<String> makePostfixExpression()
    {
        ArrayList<String> postfixExpression = new ArrayList<>();
        Stack<String> stack = new Stack<>();
        String token;
        
        for(int i = 0; i < expression.size(); i++)
        {
            token = expression.get(i);
            
            if(isOperand(token))
                postfixExpression.add(token);
            else if(token.equals("("))
                stack.push(token);
            else if(token.equals(")"))
            {
                while(!stack.peek().equals("("))
                    postfixExpression.add(stack.pop());
                stack.pop();
            }
            else//if(isOperator(token))
            {
                while(!stack.isEmpty() &&
                        !stack.peek().equals("(") &&
                        getOperatorPrecedence(stack.peek()) >=
                        getOperatorPrecedence(token)
                        )
                    postfixExpression.add(stack.pop());
                stack.push(token);
            }
        }
        while(!stack.isEmpty())
            postfixExpression.add(stack.pop());
        
        return postfixExpression;
    }
    
    private int getOperatorPrecedence(String operator)
    {
        if(operator.matches("[\\+-]"))
            return 1;
        else if(operator.matches("[\\*/]"))
            return 2;
        return 3;
    }
    
    private double evaluatePostfixExpression(ArrayList<String> expression)
    {
        Stack<String> stack = new Stack<>();
        String token;
        String temp;
        
        while(!expression.isEmpty())
        {
            token = expression.get(0);
            expression.remove(0);
            
            if(isOperand(token))
                stack.push(token);
            else//if(isOperator(token))
            {
                temp = stack.pop();
                stack.push(evaluateOperation(stack.pop(), token, temp));
            }
        }
        return evaluateOperand(stack.pop());
    }
    
    private String evaluateOperation(String operandA, String operator,
            String operandB)
    {
        double valueA;
        double valueB;
        
        valueA = evaluateOperand(operandA);
        valueB = evaluateOperand(operandB);
        switch(operator)
        {
            case "+": return Double.toString(valueA + valueB);
            case "-": return Double.toString(valueA - valueB);
            case "*": return Double.toString(valueA * valueB);
            case "/": return Double.toString(valueA / valueB);
        }
        return "NaN";
    }
    
    private double evaluateOperand(String operand)
    {
        if(variableList.containsKey(operand))
        {
            return (variableList.get(operand));
        }
        return Double.parseDouble(operand);
    }
}