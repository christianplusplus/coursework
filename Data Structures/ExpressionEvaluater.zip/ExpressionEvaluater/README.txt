The simplest way to operate the evaluator class is:

Scanner scan = new Scanner(System.in);
StatementEvaluator se = new StatementEvaluator();
while(true)
	System.out.print(se.parse(scan.nextLine()));

The parse method functions much like a command line. Commands include:

"clear" - deletes all stored variables
anything with an "=" sign - assigns a value to a variable. (This can even be another preexisting variable.)
anything else - will be evaluated as a mathematical expression.

The parse method returns either an empty string, a result, or an error message.

Alternatively, you can manipulate the class through public methods which can found in the javadocs.