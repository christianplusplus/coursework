﻿using EnterpriseLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

public class CS341Services : IService
{
    public string GetProductName(int id)
    {
        CS341Database d = new CS341Database();
        string value = d.GetProductName(id);
        return value;
    }

    public Product GetProduct(int id)
    {
        CS341Database d = new CS341Database();
        Product value = d.GetProduct(id);
        return value;
    }

    public int InsertProduct(String Name)
    {
        CS341Database d = new CS341Database();
        int value = d.InsertProduct(Name);
        return value;
    }
    
    public int InsertOrder(int ProductId, int Quantity)
    {
        CS341Database d = new CS341Database();
        int value = d.InsertOrder(ProductId, Quantity);
        return value;
    }
}
