﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using EnterpriseLibrary;

[ServiceContract]
public interface IService
{

	[OperationContract]
    string GetProductName(int id);

	[OperationContract]
	Product GetProduct(int id);

    [OperationContract]
    int InsertProduct(String Name);
    
    [OperationContract]
    int InsertOrder(int ProductId, int Quantity);
}

