﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnterpriseLibrary
{
    public class CS341Database
    {
        public string GetProductName(int id)
        {
            string name = "NotFound";
            string connectionStringToDatabase = ConfigurationManager.ConnectionStrings["MySqlDB"].ConnectionString;
            using (MySqlConnection conn = new MySqlConnection(connectionStringToDatabase))
            {
                conn.Open();
                using (MySqlCommand cmd = new MySqlCommand("select name From LabProduct where id=" + id.ToString(CultureInfo.InvariantCulture), conn))
                {
                    try
                    {
                        MySqlDataReader reader = cmd.ExecuteReader();
                        if (reader.Read())
                        {
                            name = reader.GetString("name");
                        }
                    }
                    catch (Exception ex)
                    {
                        // ignore errors
                    }
                }
                conn.Close();
            }
            return name;
        }

        public Product GetProduct(int id)
        {
            Product p = null;
            string connectionStringToDatabase = ConfigurationManager.ConnectionStrings["MySqlDB"].ConnectionString;
            MySqlConnection conn = new MySqlConnection(connectionStringToDatabase);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("select id, name From LabProduct where id=" + id.ToString(), conn);
            try
            {
                MySqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    p = new Product();
                    p.Id = reader.GetInt32("id");
                    p.Name = reader.GetString("name");
                }
            }
            catch (MySqlException ex)
            {
                System.Console.WriteLine("SQL Error" + ex.ToString());
            }
            conn.Close();
            return p;
        }

        public int InsertProduct(String Name)
        {
            int id = 0;
            string connectionStringToDatabase = ConfigurationManager.ConnectionStrings["MySqlDB"].ConnectionString;
            using (MySqlConnection conn = new MySqlConnection(connectionStringToDatabase))
            {
                conn.Open();
                using (MySqlCommand cmd = new MySqlCommand("insert into LabProduct (Name) values ('" + Name + "')", conn))
                {
                    try
                    {
                        cmd.ExecuteNonQuery();
                        using (MySqlCommand cmd2 = new MySqlCommand("SELECT LAST_INSERT_ID()", conn))
                        {


                            MySqlDataReader reader = cmd2.ExecuteReader();
                            if (reader.Read())
                            {
                                id = reader.GetInt32(0);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        // ignore errors
                    }
                }
                conn.Close();
            }
            return id;
        }
        
        public int InsertOrder(int ProductId, int Quantity)
        {
            int id = 0;
            string connectionStringToDatabase = ConfigurationManager.ConnectionStrings["MySqlDB"].ConnectionString;
            using (MySqlConnection conn = new MySqlConnection(connectionStringToDatabase))
            {
                conn.Open();
                using (MySqlCommand cmd = new MySqlCommand("insert into LabOrder (productId, quantity) values('" + ProductId + "', '" + Quantity + "')", conn))
                {
                    try
                    {
                        cmd.ExecuteNonQuery();
                        using (MySqlCommand cmd2 = new MySqlCommand("SELECT LAST_INSERT_ID()", conn))
                        {
                            MySqlDataReader reader = cmd2.ExecuteReader();
                            if (reader.Read())
                            {
                                id = reader.GetInt32(0);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        // ignore errors
                    }
                }
                conn.Close();
            }
            return id;
        }
    }
}