function insertPreview(){
	document.getElementById("preview").innerHTML = document.getElementById("textbox").value;
}