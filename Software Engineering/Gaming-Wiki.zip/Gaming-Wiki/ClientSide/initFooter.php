<?php

   echo "<div id='footer'>
			</div>
			"
?>
